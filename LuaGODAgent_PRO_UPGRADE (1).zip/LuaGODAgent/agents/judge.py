def choose_best(reviewed):
    """
    Elige la versión con mayor score.
    En caso de empate, prefiere la IA-3 (más completa).
    """
    # Ordenar: primero por score desc, luego por IA número desc
    sorted_versions = sorted(
        reviewed,
        key=lambda x: (x["score"], int(x["ia"].replace("IA-", ""))),
        reverse=True
    )

    best = sorted_versions[0]

    # Mostrar resumen de votación
    print("\n  📊 Resultados:")
    for v in reviewed:
        bar = "█" * v["score"] + "░" * (10 - v["score"])
        marker = " ← GANADORA" if v["ia"] == best["ia"] else ""
        print(f"     {v['ia']}  [{bar}] {v['score']}/10{marker}")

    return best
