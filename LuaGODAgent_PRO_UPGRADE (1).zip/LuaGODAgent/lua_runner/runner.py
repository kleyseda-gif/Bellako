"""
lua_runner/runner.py — Ejecuta código Lua localmente con subprocess.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

LUA_BIN = shutil.which("lua") or shutil.which("lua5.4") or shutil.which("lua5.3") or "lua"


class LuaRunner:
    def __init__(self, timeout: int = 5, safe_mode: bool = False):
        self.timeout = timeout
        self.safe_mode = safe_mode

    def run(self, code: str, args: list | None = None) -> dict:
        if self.safe_mode:
            code = self._sandbox(code)

        with tempfile.NamedTemporaryFile(suffix=".lua", mode="w", delete=False, encoding="utf-8") as f:
            f.write(code)
            path = f.name

        cmd = [LUA_BIN, path] + (args or [])
        t0 = time.time()
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=self.timeout)
            elapsed = int((time.time() - t0) * 1000)
            return {
                "output": proc.stdout,
                "error": proc.stderr,
                "exit_code": proc.returncode,
                "time_ms": elapsed,
                "timedout": False,
            }
        except subprocess.TimeoutExpired:
            return {
                "output": "",
                "error": f"Timeout: el script tardó más de {self.timeout}s",
                "exit_code": -1,
                "time_ms": self.timeout * 1000,
                "timedout": True,
            }
        except FileNotFoundError:
            return {
                "output": "",
                "error": "Lua no encontrado. Instala con: pkg install lua",
                "exit_code": -1,
                "time_ms": 0,
                "timedout": False,
            }
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass

    def validate_syntax(self, code: str) -> dict:
        luac = shutil.which("luac") or shutil.which("luac5.4") or shutil.which("luac5.3") or shutil.which("luac5.1")
        if luac:
            with tempfile.NamedTemporaryFile(suffix=".lua", mode="w", delete=False, encoding="utf-8") as f:
                f.write(code)
                path = f.name
            try:
                proc = subprocess.run([luac, "-p", path], capture_output=True, text=True, timeout=5)
                return {"valid": proc.returncode == 0, "error": proc.stderr.strip() or None}
            finally:
                try:
                    os.unlink(path)
                except OSError:
                    pass

        with tempfile.NamedTemporaryFile(suffix=".lua", mode="w", delete=False, encoding="utf-8") as f:
            f.write(code)
            path = f.name
        try:
            checker = (
                'local p=arg[1]\n'
                'local loader=loadfile or loadstring\n'
                'local fn,err=loader(p)\n'
                'if not fn then io.stderr:write(tostring(err)) os.exit(1) end\n'
            )
            proc = subprocess.run([LUA_BIN, "-e", checker, path], capture_output=True, text=True, timeout=5)
            return {"valid": proc.returncode == 0, "error": proc.stderr.strip() or None}
        except Exception as e:
            return {"valid": False, "error": str(e)}
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass

    def lua_available(self) -> bool:
        try:
            subprocess.run([LUA_BIN, "-v"], capture_output=True, timeout=3)
            return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def _sandbox(self, code: str) -> str:
        return (
            "local _io, _os = io, os\n"
            "io = {write=_io.write, read=_io.read}\n"
            "os = {time=_os.time, clock=_os.clock, date=_os.date}\n"
            + code
        )

    def hint_from_error(self, error: str) -> str:
        e = (error or "").lower()
        if "attempt to index" in e and "nil" in e:
            return "💡 Estás accediendo a un campo de un valor nil. Verifica que la variable esté inicializada."
        if "attempt to call" in e and "nil" in e:
            return "💡 Estás llamando algo que es nil. Revisa el nombre de la función o variable."
        if "attempt to perform arithmetic" in e:
            return "💡 Operación aritmética sobre un valor no numérico. Usa tonumber() para convertir."
        if "stack overflow" in e:
            return "💡 Recursión infinita. Verifica que tu función tenga un caso base."
        if "attempt to yield" in e:
            return "💡 coroutine.yield no puede usarse en ciertos callbacks de C."
        if "table index is nan" in e:
            return "💡 Estás usando NaN como índice de tabla. Revisa divisiones por cero."
        if "table index is nil" in e:
            return "💡 Estás usando nil como índice de tabla. El índice debe ser válido."
        if "<eof>" in e or "expected" in e:
            return "💡 Error de sintaxis. Revisa que cada bloque tenga su end correspondiente."
        return ""
