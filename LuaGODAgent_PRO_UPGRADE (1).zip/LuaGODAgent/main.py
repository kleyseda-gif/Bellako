"""
main.py — CLI principal de LuaGOD Agent v5
Más estable, más claro y más cómodo para Termux.
"""
from __future__ import annotations

import os
import sys
import textwrap
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

# ── Cargar .env ────────────────────────────────────────────────
try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except Exception:
    env_path = BASE_DIR / ".env"
    if env_path.exists():
        for raw in env_path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = raw.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())

C = {
    "red":     "\033[91m",
    "green":   "\033[92m",
    "yellow":  "\033[93m",
    "blue":    "\033[94m",
    "magenta": "\033[95m",
    "cyan":    "\033[96m",
    "white":   "\033[97m",
    "bold":    "\033[1m",
    "dim":     "\033[2m",
    "reset":   "\033[0m",
}


def c(color: str, text: object) -> str:
    return C.get(color, "") + str(text) + C["reset"]


BANNER = f"""
{C['cyan']}╔══════════════════════════════════════════════╗
║  {C['yellow']}{C['bold']}🔥  LuaGOD Agent v5 — más rápido, más sólido  🔥{C['reset']}{C['cyan']}  ║
║  {C['dim']}Groq · OpenRouter · Gemini · Fallback Auto{C['reset']}{C['cyan']}       ║
╚══════════════════════════════════════════════╝{C['reset']}
{c('dim', 'Escribe /ayuda para ver todos los comandos')}
"""

HELP_TEXT = f"""
{c('bold', '══ COMANDOS DISPONIBLES ══')}
  {c('cyan', '── ARCHIVOS ──')}
  {c('yellow', '/leer [archivo.lua]')}     Leer y analizar archivo desde workspace o Descargas
  {c('yellow', '/guardar [nombre]')}       Guardar último código con nombre
  {c('yellow', '/cargar [nombre]')}        Cargar snippet guardado
  {c('yellow', '/lista')}                  Ver snippets guardados
  {c('yellow', '/exportar')}               Exportar snippets buenos a .lua

  {c('cyan', '── EJECUCIÓN ──')}
  {c('yellow', '/ejecutar [args]')}        Ejecutar último código con Lua local
  {c('yellow', '/validar')}                Validar sintaxis del último código

  {c('cyan', '── APRENDIZAJE ──')}
  {c('yellow', '/aprender [tema]')}        Tutorial sobre un tema Lua
  {c('yellow', '/version [target]')}       Cambiar target: lua51/lua52/lua53/lua54/luau/delta/fluxus/arceus

  {c('cyan', '── MEMORIA ──')}
  {c('yellow', '/fav')}                    Marcar último como favorito
  {c('yellow', '/favoritos')}              Ver snippets favoritos
  {c('yellow', '/buscar [term]')}          Buscar en historial
  {c('yellow', '/memoria')}                Ver últimas 5 entradas
  {c('yellow', '/estado')}                 Ver estado del agente

  {c('cyan', '── GENERAL ──')}
  {c('yellow', '/limpiar')}                Limpiar pantalla
  {c('yellow', '/ayuda')}                  Esta ayuda
  {c('yellow', 'exit')}                    Salir

  {c('dim', '💡 Tip: Para archivos grandes usa /leer en vez de pegar el código')}
"""

_last_code = ""
_lua_target = os.getenv("LUA_TARGET", "luau")


def check_deps() -> None:
    missing = []
    try:
        import requests  # noqa: F401
    except ImportError:
        missing.append("requests")
    if missing:
        print(c("yellow", f"⚠ Dependencias faltantes: {', '.join(missing)}"))
        print(c("dim", f"  Instala con: pip install {' '.join(missing)}"))


def check_apis() -> None:
    keys = {
        "GROQ_API_KEY": os.getenv("GROQ_API_KEY", ""),
        "OPENROUTER_API_KEY": os.getenv("OPENROUTER_API_KEY", ""),
        "GEMINI_API_KEY": os.getenv("GEMINI_API_KEY", ""),
    }
    configured = [k for k, v in keys.items() if v and v != "pega_tu_key_aqui"]
    if not configured:
        print(c("red", "⚠ No hay API keys configuradas."))
        print(c("dim", "  Copia .env.example a .env y agrega tus keys."))
    else:
        print(c("green", f"✓ APIs configuradas: {', '.join(configured)}"))


def _import_runner():
    from lua_runner.runner import LuaRunner
    return LuaRunner


def _import_memory():
    from memory.memory import (
        get_by_name,
        get_favorites,
        load_all,
        save_named,
        search,
        export_lua,
        toggle_favorite,
        count_entries,
    )
    return {
        "get_by_name": get_by_name,
        "get_favorites": get_favorites,
        "load_all": load_all,
        "save_named": save_named,
        "search": search,
        "export_lua": export_lua,
        "toggle_favorite": toggle_favorite,
        "count_entries": count_entries,
    }


def _clean_query(s: str) -> str:
    return " ".join(s.replace("\t", " ").split()).strip()


def _friendly_action(raw: str) -> str:
    s = raw.strip().lower()
    mapping = {
        "1": "analiza",
        "2": "arregla",
        "3": "explica",
        "4": "mejora",
        "analizar": "analiza",
        "analiza": "analiza",
        "arreglar": "arregla",
        "arregla": "arregla",
        "corregir": "arregla",
        "explicar": "explica",
        "explica": "explica",
        "mejorar": "mejora",
        "mejora": "mejora",
        "debug": "arregla",
        "fix": "arregla",
        "review": "analiza",
        "análisis": "analiza",
    }
    return mapping.get(s, s or "analiza")


def _resolve_file(path_str: str) -> Path | None:
    path_str = path_str.strip().strip('"').strip("'")
    if not path_str:
        return None

    candidates = []
    raw = Path(path_str).expanduser()
    candidates.append(raw)

    workspace = BASE_DIR / "workspace"
    candidates.extend([
        workspace / path_str,
        workspace / f"{path_str}.lua",
        workspace / f"{path_str}.luau",
        BASE_DIR / path_str,
        BASE_DIR / f"{path_str}.lua",
        Path("/sdcard/Download") / path_str,
        Path("/sdcard/Download") / f"{path_str}.lua",
        Path("/storage/emulated/0/Download") / path_str,
        Path("/storage/emulated/0/Download") / f"{path_str}.lua",
        Path.home() / "storage" / "downloads" / path_str,
        Path.home() / "storage" / "downloads" / f"{path_str}.lua",
    ])

    for candidate in candidates:
        try:
            if candidate.is_file():
                return candidate
        except OSError:
            continue
    return None


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def _preview_lines(content: str, limit: int = 30) -> str:
    lines = content.splitlines()
    preview = lines[:limit]
    out = "\n".join(preview)
    if len(lines) > limit:
        out += f"\n{c('dim', f'... ({len(lines) - limit} líneas más)')}"
    return out


def _compact_file_prompt(path: Path, content: str, action: str) -> str:
    lines = content.splitlines()
    total = len(lines)
    head = "\n".join(lines[:220])
    tail = "\n".join(lines[-40:]) if total > 260 else ""
    body = head if total <= 260 else f"{head}\n\n-- TRUNCADO --\n\n{tail}"
    return textwrap.dedent(f"""
    {action} este código Lua/Luau.
    Archivo: {path.name}
    Líneas totales: {total}

    Prioriza:
    1) detectar errores o puntos frágiles,
    2) explicar el problema si existe,
    3) devolver una versión mejorada si aplica.

    Código:
    {body}
    """).strip()


def _print_result(result: dict) -> None:
    code = result.get("code", "") or ""
    score = int(result.get("score", 0) or 0)
    bar = c("green", "█" * score) + c("dim", "░" * (10 - score))

    print("\n" + c("cyan", "═" * 50))
    print(c("bold", "🔥 RESULTADO:\n"))
    if code:
        print(code)
    else:
        print(c("dim", "(sin código de salida)"))
    print(c("cyan", "\n" + "═" * 50))
    print(f"📊 Score: [{bar}] {score}/10  |  /ejecutar para correr  |  /guardar para guardar")


def cmd_estado() -> None:
    mem = _import_memory()
    entries = mem["load_all"]()
    favs = mem["get_favorites"]()
    print(c("bold", "\n📌 Estado del agente\n"))
    print(f"Target actual: {c('yellow', _lua_target)}")
    print(f"Entradas en memoria: {len(entries)}")
    print(f"Favoritos: {len(favs)}")
    print(f"Último código cargado: {c('green', 'sí' if _last_code else 'no')}")


def cmd_ejecutar(args_str: str = "") -> None:
    global _last_code
    if not _last_code:
        print(c("yellow", "No hay código para ejecutar. Genera o carga algo primero."))
        return

    LuaRunner = _import_runner()
    runner = LuaRunner(timeout=12, safe_mode=False)
    if not runner.lua_available():
        print(c("red", "Lua no encontrado. Instala con: pkg install lua"))
        return

    args = args_str.split() if args_str.strip() else []
    print(c("dim", "─" * 40))
    result = runner.run(_last_code, args)
    if result.get("output"):
        print(c("green", "📤 Output:"))
        print(result["output"])
    if result.get("error"):
        print(c("red", "❌ Error:"))
        print(result["error"])
        hint = runner.hint_from_error(result["error"])
        if hint:
            print(c("yellow", hint))
    print(c("dim", f"⏱ {result.get('time_ms', 0)}ms | exit: {result.get('exit_code', -1)}"))


def cmd_validar() -> None:
    global _last_code
    if not _last_code:
        print(c("yellow", "No hay código para validar."))
        return
    LuaRunner = _import_runner()
    runner = LuaRunner(timeout=8)
    result = runner.validate_syntax(_last_code)
    if result["valid"]:
        print(c("green", "✓ Sintaxis válida"))
    else:
        print(c("red", "✗ Sintaxis con errores"))
        if result.get("error"):
            print(c("yellow", result["error"]))


def cmd_guardar(name: str = "") -> None:
    global _last_code
    if not _last_code:
        print(c("yellow", "No hay código para guardar."))
        return
    mem = _import_memory()
    entries = mem["load_all"]()
    if not name:
        name = f"snippet_{len(entries) + 1}"
    mem["save_named"](name, _last_code)
    print(c("green", f"✓ Guardado como '{name}'"))


def cmd_cargar(name: str = "") -> None:
    global _last_code
    if not name:
        print(c("yellow", "Uso: /cargar [nombre]"))
        return
    mem = _import_memory()
    entry = mem["get_by_name"](name)
    if entry:
        _last_code = entry.get("code", "")
        print(c("cyan", f"📂 Cargado: {name}"))
        print(c("dim", "─" * 40))
        print(_last_code)
    else:
        print(c("red", f"No encontrado: '{name}'"))


def cmd_lista() -> None:
    mem = _import_memory()
    entries = mem["load_all"]()
    if not entries:
        print(c("dim", "Sin entradas guardadas."))
        return
    print(c("bold", f"\n📚 {len(entries)} entradas:\n"))
    start = max(1, len(entries) - 19)
    for i, e in enumerate(entries[-20:], start):
        fav = "⭐" if e.get("favorite") else "  "
        name = e.get("name") or e.get("prompt", "")[:45]
        score = int(e.get("score", 0) or 0)
        bar = "█" * score + "░" * (10 - score)
        print(f"  {fav} {c('dim', str(i).rjust(3))}. [{bar}] {name}")


def cmd_fav() -> None:
    mem = _import_memory()
    entries = mem["load_all"]()
    if not entries:
        print(c("dim", "Sin historial todavía."))
        return
    state = mem["toggle_favorite"](len(entries))
    icon = "⭐" if state else "☆"
    print(c("yellow", f"{icon} Favorito {'marcado' if state else 'desmarcado'}"))


def cmd_favoritos() -> None:
    mem = _import_memory()
    favs = mem["get_favorites"]()
    if not favs:
        print(c("dim", "Sin favoritos aún. Usa /fav para marcar."))
        return
    print(c("bold", f"\n⭐ {len(favs)} favoritos:\n"))
    for e in favs:
        name = e.get("name") or e.get("prompt", "")[:50]
        print(f"  • {name}")


def cmd_buscar(term: str = "") -> None:
    term = _clean_query(term)
    if not term:
        print(c("yellow", "Uso: /buscar [término]"))
        return
    mem = _import_memory()
    results = mem["search"](term)
    if not results:
        print(c("dim", f"Sin resultados para '{term}'"))
        return
    print(c("bold", f"\n🔍 {len(results)} resultados para '{term}':\n"))
    for e in results[-10:]:
        print(f"  • {e.get('prompt','')[:60]}")


def cmd_aprender(topic: str = "") -> None:
    global _last_code
    topic = _clean_query(topic)
    if not topic:
        print(c("yellow", "Uso: /aprender [tema]  (ej: /aprender metatables)"))
        return
    from agent.api import call_ai
    system = (
        "Eres LuaGOD, experto en Lua y Luau. "
        "Genera un tutorial claro y útil sobre el tema pedido. "
        "Formato: concepto → ejemplo básico → ejemplo intermedio → ejemplo avanzado → ejercicio. "
        "Responde en español e incluye código funcional en bloques ```lua```.")
    user = f"Tutorial completo sobre: {topic} en Lua/Luau"
    print(c("cyan", f"\n📖 Generando tutorial: {topic}..."))
    result = call_ai(system, user)
    print("\n" + result)
    if "```lua" in result:
        start = result.find("```lua") + 6
        end = result.find("```", start)
        if end != -1:
            _last_code = result[start:end].strip()


def cmd_version(target: str = "") -> None:
    global _lua_target
    valid = ["lua51", "lua52", "lua53", "lua54", "luau", "delta", "fluxus", "arceus"]
    target = _clean_query(target).lower()
    if not target or target not in valid:
        print(c("cyan", f"Target actual: {c('yellow', _lua_target)}"))
        print(c("dim", f"Opciones: {', '.join(valid)}"))
        return
    _lua_target = target
    os.environ["LUA_TARGET"] = target
    print(c("green", f"✓ Target cambiado a: {target}"))


def cmd_exportar() -> None:
    mem = _import_memory()
    path = mem["export_lua"]()
    print(c("green", f"✓ Exportado a: {path}"))


def cmd_memoria() -> None:
    mem = _import_memory()
    entries = mem["load_all"]()
    if not entries:
        print(c("dim", "Sin historial."))
        return
    print(c("bold", f"\n📚 Últimas {min(5, len(entries))} entradas:\n"))
    for e in entries[-5:]:
        label = e.get('name') or e.get('prompt', '')
        print(f"  • {label[:70]}")


def cmd_leer(path_str: str = "") -> None:
    global _last_code
    if not path_str:
        print(c("yellow", "Uso: /leer [archivo.lua]"))
        print(c("dim", "  Ej: /leer miScript.lua"))
        print(c("dim", "  Ej: /leer /sdcard/Download/Cobalt.lua"))
        return

    filepath = _resolve_file(path_str)
    if not filepath:
        print(c("red", f"❌ Archivo no encontrado: {path_str}"))
        print(c("dim", "  Buscado en workspace/, Descargas y ruta actual."))
        return

    try:
        content = _read_text(filepath)
    except Exception as e:
        print(c("red", f"❌ Error leyendo archivo: {e}"))
        return

    lines = content.splitlines()
    line_count = len(lines)

    print(c("cyan", f"\n📂 Archivo: {filepath.name}"))
    print(c("dim", f"   {line_count} líneas | {len(content)} caracteres"))

    if line_count > 200:
        print(c("yellow", f"\n⚠  Archivo grande ({line_count} líneas)"))
        print(c("dim", "   Se enviará una versión compacta para no trabar Termux."))
        print(c("dim", "   1) analizar  2) arreglar  3) explicar  4) mejorar"))
        try:
            accion = input(c("cyan", "   Acción (1-4 o escribe): ")).strip()
        except (KeyboardInterrupt, EOFError):
            return
        accion = _friendly_action(accion)
        prompt_final = _compact_file_prompt(filepath, content, accion)
    else:
        print(c("dim", "─" * 40))
        print(c("dim", _preview_lines(content, 30)))
        print(c("dim", "─" * 40))
        try:
            accion = input(c("cyan", "¿Qué hago con este código? (analizar/arreglar/explicar/mejorar): ")).strip()
        except (KeyboardInterrupt, EOFError):
            return
        accion = _friendly_action(accion)
        prompt_final = f"{accion} este código Lua:\n\n{content}"

    _last_code = content
    print(c("dim", "\n⚙  Procesando..."))

    try:
        from agents.core import run_agent
        result = run_agent(prompt_final)
    except Exception as e:
        print(c("red", f"Error: {e}"))
        return

    _last_code = result.get("code", content) or content
    _print_result(result)


def _run_prompt(prompt: str) -> None:
    global _last_code
    from agents.core import run_agent

    MAX_PROMPT_CHARS = 3000
    MAX_PROMPT_LINES = 150

    prompt_lines = prompt.count("\n") + 1
    prompt_chars = len(prompt)

    if prompt_chars > MAX_PROMPT_CHARS or prompt_lines > MAX_PROMPT_LINES:
        print(c("yellow", "\n⚠ Texto grande detectado:"))
        print(c("dim", f"   {prompt_lines} líneas | {prompt_chars} caracteres"))
        print(c("dim", "   Pegar código grande puede trabar Termux."))
        print(c("cyan", "\n💡 Tip: Guarda el código en un archivo y usa /leer nombre_archivo.lua"))
        try:
            confirm = input(c("dim", "¿Continuar de todas formas? (s/n): ")).strip().lower()
        except (KeyboardInterrupt, EOFError):
            return
        if confirm not in ("s", "si", "sí", "y", "yes"):
            print(c("dim", "Cancelado. Usa /leer para archivos grandes."))
            return
        if prompt_chars > MAX_PROMPT_CHARS:
            prompt = prompt[:MAX_PROMPT_CHARS]
            print(c("yellow", f"⚠ Truncado a {MAX_PROMPT_CHARS} caracteres para no saturar la API."))

    print(c("dim", "\n⚙ Procesando..."))
    try:
        result = run_agent(prompt)
    except Exception as e:
        print(c("red", f"Error: {e}"))
        return

    _last_code = result.get("code", "") or ""
    _print_result(result)


def main() -> None:
    global _last_code, _lua_target

    print(BANNER)
    check_deps()
    check_apis()
    print()

    while True:
        try:
            prompt = input(f"\n{c('cyan', '🔥 LuaGOD')} {c('dim', f'[{_lua_target}]')} {c('bold', '›')} ").strip()
        except (KeyboardInterrupt, EOFError):
            print(c("dim", "\n\n👋 Hasta luego!"))
            break

        if not prompt:
            continue

        cmd = prompt.lower().strip()

        if cmd in ("exit", "salir", "quit"):
            print(c("dim", "👋 Hasta luego!"))
            break
        if cmd.startswith("/leer"):
            cmd_leer(prompt[5:].strip())
            continue
        if cmd.startswith("/ejecutar"):
            cmd_ejecutar(prompt[9:].strip())
            continue
        if cmd.startswith("/guardar"):
            cmd_guardar(prompt[8:].strip())
            continue
        if cmd.startswith("/cargar"):
            cmd_cargar(prompt[7:].strip())
            continue
        if cmd == "/lista":
            cmd_lista()
            continue
        if cmd == "/fav":
            cmd_fav()
            continue
        if cmd == "/favoritos":
            cmd_favoritos()
            continue
        if cmd.startswith("/buscar"):
            cmd_buscar(prompt[7:].strip())
            continue
        if cmd.startswith("/aprender"):
            cmd_aprender(prompt[9:].strip())
            continue
        if cmd.startswith("/version"):
            cmd_version(prompt[8:].strip())
            continue
        if cmd == "/exportar":
            cmd_exportar()
            continue
        if cmd == "/memoria":
            cmd_memoria()
            continue
        if cmd == "/estado":
            cmd_estado()
            continue
        if cmd == "/validar":
            cmd_validar()
            continue
        if cmd in ("/limpiar", "/clear"):
            os.system("clear")
            print(BANNER)
            continue
        if cmd in ("/ayuda", "/help"):
            print(HELP_TEXT)
            continue

        _run_prompt(prompt)


if __name__ == "__main__":
    main()
