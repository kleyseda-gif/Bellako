"""
agents/reviewer.py — Scoring de calidad de código Lua basado en patrones reales.
"""
from __future__ import annotations

import re


def review(version: dict, prompt: str = "") -> dict:
    code = version.get("code", "") or ""
    score = 5

    lines = [l for l in code.splitlines() if l.strip()]
    code_no_comments = "\n".join(l for l in code.splitlines() if not l.strip().startswith("--"))

    if "function" in code:
        score += 1
    if "return" in code:
        score += 1
    if re.search(r"local\s+\w+\s*=", code):
        score += 1
    if "pcall" in code:
        score += 2
    if "xpcall" in code:
        score += 1
    if "assert" in code:
        score += 1
    if "-- " in code:
        score += 1
    if re.search(r"--\[\[", code):
        score += 1
    if "setmetatable" in code:
        score += 2
    if "__index" in code:
        score += 1
    if re.search(r"function\s+\w+:\w+", code):
        score += 1
    if "string.format" in code:
        score += 1
    if "table.concat" in code:
        score += 1
    if "ipairs" in code:
        score += 1
    if "task.spawn" in code or "task.wait" in code:
        score += 1

    prompt_lower = prompt.lower()
    is_executor_prompt = any(w in prompt_lower for w in ["executor", "delta", "fluxus", "hookfunction", "getconnections", "remote", "spy", "hook"])
    if is_executor_prompt:
        if "newcclosure" in code:
            score += 1
        if "getrawmetatable" in code:
            score += 1
        if "cloneref" in code:
            score += 1
        if "checkcaller" in code:
            score += 1
        if re.search(r"\w+\s+or\s+\w+", code):
            score += 1

    global_assigns = re.findall(r"^(\w+)\s*=\s*[^=]", code_no_comments, re.MULTILINE)
    lua_keywords = {"if", "then", "else", "end", "for", "while", "do", "repeat", "until",
                    "function", "local", "return", "break", "true", "false", "nil", "and", "or", "not"}
    bad_globals = [g for g in global_assigns if g not in lua_keywords and len(g) > 1]
    if bad_globals:
        score -= len(bad_globals)

    if re.search(r"\s=\s*nil\b", code_no_comments):
        score -= 1
    if len([l for l in lines if not l.strip().startswith("--")]) < 3:
        score -= 2
    if re.search(r"for\b.*\n.*\.\.", code):
        score -= 1
    if re.search(r"pairs\s*\(\s*nil\s*\)", code):
        score -= 2
    if len([l for l in lines if not l.strip().startswith("--")]) >= 20:
        score += 1
    if len([l for l in lines if not l.strip().startswith("--")]) >= 50:
        score += 1

    score = max(0, min(10, score))
    return {
        "ia": version.get("ia", "IA-?"),
        "code": code,
        "score": score,
        "intent": version.get("intent", "generic"),
        "target": version.get("target", "luau"),
    }
