"""
knowledge/external_repos.py — Conocimiento extraído de repos open source.
Fuentes: Hydroxide (Upbolt), Synapse X Docs, richie0866/remote-spy,
         luau/Executor-API-Docs
"""

# ══════════════════════════════════════════════════════════════════
# HYDROXIDE — Lua runtime introspection tool (Upbolt/Hydroxide)
# El remote spy más completo y estudiado de la comunidad
# ══════════════════════════════════════════════════════════════════
HYDROXIDE_KB = """
## HYDROXIDE — NORMALIZACIÓN DE NOMBRES ENTRE EXECUTORES

-- Hydroxide resuelve el problema de que cada executor usa nombres distintos
-- para las mismas funciones. Crea aliases unificados al inicio:

local globalMethods = {
    checkCaller       = checkcaller,
    newCClosure       = newcclosure,
    hookFunction      = hookfunction or detour_function,
    getGc             = getgc or get_gc_objects,
    getInfo           = debug.getinfo or getinfo,
    getSenv           = getsenv,
    getMenv           = getmenv or getsenv,
    getContext        = getthreadcontext or get_thread_context
                        or (syn and syn.get_thread_identity),
    getConnections    = get_signal_cons or getconnections,
    getScriptClosure  = getscriptclosure or get_script_function,
    getNamecallMethod = getnamecallmethod or get_namecall_method,
    getCallingScript  = getcallingscript or get_calling_script,
    getLoadedModules  = getloadedmodules or get_loaded_modules,
    getConstants      = debug.getconstants or getconstants or getconsts,
    getUpvalues       = debug.getupvalues or getupvalues or getupvals,
    getProtos         = debug.getprotos or getprotos,
    getStack          = debug.getstack or getstack,
    getConstant       = debug.getconstant or getconstant or getconst,
    getUpvalue        = debug.getupvalue or getupvalue or getupval,
    getProto          = debug.getproto or getproto,
    getMetatable      = getrawmetatable or debug.getmetatable,
    getHui            = get_hidden_gui or gethui,
    setClipboard      = setclipboard or writeclipboard,
    setContext        = setthreadcontext or set_thread_context
                        or (syn and syn.set_thread_identity),
    setUpvalue        = debug.setupvalue or setupvalue or setupval,
    setStack          = debug.setstack or setstack,
    setReadOnly       = setreadonly or (make_writeable and function(t, ro)
                            if ro then make_readonly(t) else make_writeable(t) end
                        end),
    isLClosure        = islclosure or is_l_closure
                        or (iscclosure and function(f) return not iscclosure(f) end),
    isReadOnly        = isreadonly or is_readonly,
    -- isXClosure: detectar si es closure del executor (varía por executor)
    isXClosure        = is_synapse_function or issentinelclosure
                        or is_protosmasher_closure or is_sirhurt_closure
                        or iselectronfunction or istempleclosure or checkclosure,
    hookMetaMethod    = hookmetamethod or (hookfunction and function(obj, method, hook)
                            return hookfunction(getMetatable(obj)[method], hook)
                        end),
    readFile  = readfile,
    writeFile = writefile,
    makeFolder = makefolder,
    isFolder  = isfolder,
    isFile    = isfile,
}

-- Patrón de uso: en lugar de llamar hookfunction directamente,
-- usar oh.Methods.hookFunction para compatibilidad cross-executor

## HYDROXIDE — SISTEMA DE COLORES POR TIPO

-- Hydroxide usa colores consistentes para visualizar tipos Lua:
local TypeColors = {
    ["nil"]      = Color3.fromRGB(244, 135, 113),  -- rojo suave
    table        = Color3.fromRGB(225, 225, 225),  -- blanco
    string       = Color3.fromRGB(225, 150, 85),   -- naranja
    number       = Color3.fromRGB(170, 225, 127),  -- verde
    boolean      = Color3.fromRGB(127, 200, 255),  -- azul
    userdata     = Color3.fromRGB(225, 225, 225),
    ["function"] = Color3.fromRGB(225, 225, 225),
    ["thread"]   = Color3.fromRGB(225, 225, 225),
    unnamed_function = Color3.fromRGB(175, 175, 175),  -- gris
}

-- Iconos por tipo (rbxassetid):
local TypeIcons = {
    ["nil"]      = "rbxassetid://4800232219",
    table        = "rbxassetid://4666594276",
    string       = "rbxassetid://4666593882",
    number       = "rbxassetid://4666593882",
    boolean      = "rbxassetid://4666593882",
    userdata     = "rbxassetid://4666594723",
    ["function"] = "rbxassetid://4666593447",
    ["thread"]   = "rbxassetid://4666593447",
}

## HYDROXIDE — SISTEMA DE IMPORT CON CACHÉ LOCAL

-- Hydroxide descarga módulos de GitHub y los cachea en disco
-- para no re-descargar en cada ejecución (ahorra tiempo y requests)

local importCache = {}

local function import(asset)
    if importCache[asset] then return unpack(importCache[asset]) end

    local content
    if asset:find("rbxassetid://") then
        -- Asset de Roblox
        return game:GetObjects(asset)[1]
    else
        -- Módulo de GitHub
        local file = "hydroxide/user/" .. user .. "/" .. asset .. ".lua"
        local ok, cached = pcall(readfile, file)
        if ok and cached then
            content = cached
        else
            content = game:HttpGetAsync(
                "https://raw.githubusercontent.com/" .. user ..
                "/Hydroxide/" .. branch .. "/" .. asset .. ".lua"
            )
            pcall(writefile, file, content)
        end
        local result = { loadstring(content, asset .. ".lua")() }
        importCache[asset] = result
        return unpack(result)
    end
end

## HYDROXIDE — UPVALUE SCANNER

-- Hydroxide puede escanear upvalues de cualquier función Lua:
-- getUpvalues(func) → tabla de upvalues
-- getUpvalue(func, index) → upvalue específico
-- setUpvalue(func, index, value) → modificar upvalue

-- Caso especial: si la función es una tabla (closure wrapeada),
-- Hydroxide accede a .Data para obtener la función real:
local function getUpvaluesSafe(closure)
    if type(closure) == "table" then
        return debug.getupvalues(closure.Data)
    end
    return debug.getupvalues(closure)
end

-- Uso educativo: ver el estado interno de una función
local function inspectClosure(fn)
    local info = {
        name      = debug.info(fn, "n"),
        source    = debug.info(fn, "s"),
        line      = debug.info(fn, "l"),
        upvalues  = debug.getupvalues(fn),
        constants = debug.getconstants(fn),
        protos    = debug.getprotos(fn),
    }
    return info
end

## HYDROXIDE — SCRIPT CONTEXT ERROR HOOK

-- Hydroxide hookea ScriptContext.Error para suprimir errores del executor
-- que podrían aparecer en el output del juego y delatar su presencia:

for _, conn in getconnections(game:GetService("ScriptContext").Error) do
    local mt = getrawmetatable(conn)
    if mt then
        setreadonly(mt, false)
        local old = mt.__index
        mt.__index = newcclosure(function(t, k)
            if k == "Connected" then return true end  -- siempre parecer conectado
            return old(t, k)
        end)
        setreadonly(mt, true)
        conn:Disable()  -- deshabilitar sin desconectar (evita errores)
    end
end

## HYDROXIDE — SISTEMA DE CLEANUP

-- Hydroxide registra todos sus hooks y eventos para poder limpiarlos:
local oh = {
    Events = {},   -- RBXScriptConnections
    Hooks  = {},   -- {original → hook} o {original → {Closure, Original}}
}

-- Al salir:
function oh.Exit()
    for _, event in oh.Events do event:Disconnect() end
    for original, hook in oh.Hooks do
        if type(hook) == "function" then
            hookFunction(hook, original)  -- restaurar: hookear el hook con el original
        elseif type(hook) == "table" then
            hookFunction(hook.Closure.Data, hook.Original)
        end
    end
    -- Destruir UI
    local ui = importCache["rbxassetid://11389137937"]
    if ui then unpack(ui):Destroy() end
end
"""

# ══════════════════════════════════════════════════════════════════
# SYNAPSE X — API COMPLETA DE EXECUTOR
# ══════════════════════════════════════════════════════════════════
SYNAPSE_X_KB = """
## SYNAPSE X — API COMPLETA (referencia estándar de la industria)

### Environment Functions
getgenv()           -- entorno global del executor (compartido entre scripts)
getrenv()           -- entorno global de Roblox (LocalScript state)
getreg()            -- registro Lua completo
getgc()             -- copia de la lista GC de Lua
getinstances()      -- todas las instancias del juego
getnilinstances()   -- instancias con Parent=nil
getscripts()        -- todos los scripts del juego
getloadedmodules()  -- ModuleScripts cargados

### Signal Functions
getconnections(signal)  -- lista de Connection objects
-- Cada Connection tiene:
--   .Function  → función conectada
--   .State     → estado de la conexión
--   :Enable()  → habilitar
--   :Disable() → deshabilitar
--   :Fire(...) → disparar manualmente

firesignal(signal, ...)          -- disparar todas las conexiones
fireclickdetector(cd, distance)  -- disparar ClickDetector
firetouchinterest(part, transmitter, toggle)  -- disparar TouchInterest

### Script Environment Functions
getsenv(script)     -- entorno de un script específico
getmenv()           -- entorno del módulo actual
getscriptclosure(script)  -- closure del script

### Hooking Functions
hookfunction(original, hook)     -- hookear función, retorna original
hookmetamethod(obj, method, hook) -- hookear metamétodo
newcclosure(func)                -- convertir a C closure
iscclosure(func)                 -- es C closure?
islclosure(func)                 -- es Lua closure?
checkcaller()                    -- el caller es el executor?
getcallingscript()               -- script que llamó la función

### Reflection Functions
getrawmetatable(obj)             -- metatable sin __metatable
setrawmetatable(obj, mt)         -- setear metatable sin restricción
getnamecallmethod()              -- método en __namecall actual
debug.getconstants(func)         -- constantes de la función
debug.getupvalues(func)          -- upvalues de la función
debug.getprotos(func)            -- prototipos (funciones anidadas)
debug.setconstant(func, idx, v)  -- modificar constante
debug.setupvalue(func, idx, v)   -- modificar upvalue
debug.getstack(level)            -- stack en nivel dado
debug.setstack(level, idx, v)    -- modificar stack

### File Functions
readfile(path)           -- leer archivo
writefile(path, content) -- escribir archivo
appendfile(path, content)-- agregar al final
isfile(path)             -- existe el archivo?
isfolder(path)           -- existe la carpeta?
makefolder(path)         -- crear carpeta
delfile(path)            -- eliminar archivo
delfolder(path)          -- eliminar carpeta
listfiles(path)          -- listar archivos
loadfile(path)           -- cargar y ejecutar archivo Lua
getcustomasset(path)     -- obtener rbxasset:// de archivo local

### Misc Functions
setclipboard(text)       -- copiar al portapapeles
queue_on_teleport(code)  -- ejecutar código después de teleport
identifyexecutor()       -- nombre y versión del executor
getexecutorname()        -- solo nombre
messagebox(text, title, flags)  -- cuadro de diálogo
setthreadidentity(n)     -- cambiar identidad del thread (1-8)
getthreadidentity()      -- obtener identidad actual
getfunctionhash(func)    -- hash único de la función

### Drawing Library
Drawing.new("Line")      -- línea
Drawing.new("Text")      -- texto
Drawing.new("Image")     -- imagen
Drawing.new("Circle")    -- círculo
Drawing.new("Square")    -- cuadrado
Drawing.new("Quad")      -- cuadrilátero
Drawing.new("Triangle")  -- triángulo
-- Propiedades comunes: Visible, ZIndex, Transparency, Color, Thickness
-- Métodos: :Remove(), :Destroy()

### WebSocket
local ws = WebSocket.connect("wss://url")
ws.OnMessage:Connect(function(msg) end)
ws.OnClose:Connect(function() end)
ws:Send("mensaje")
ws:Close()

### Crypt Library
crypt.base64encode(data)
crypt.base64decode(data)
crypt.hash(data, algorithm)  -- md5, sha1, sha256, sha384, sha512
crypt.encrypt(data, key, iv, algorithm)
crypt.decrypt(data, key, iv, algorithm)
crypt.generatekey()
crypt.generatebytes(size)

### Thread Identity Levels
-- 1: Plugin (más bajo)
-- 2: LocalScript
-- 3: Script
-- 4: CoreScript
-- 5: Studio Plugin
-- 6: Roblox Game
-- 7: Roblox CoreScript
-- 8: Roblox (más alto, acceso total)
-- Cobalt usa setthreadidentity(8) para operaciones que requieren acceso total

## COMPATIBILIDAD CROSS-EXECUTOR — TABLA COMPLETA

-- Función          Delta   Fluxus  Arceus  Krnl    Synapse  Hydrogen
-- hookfunction     ✓       ✓       ✓       ✓       ✓        ✓
-- hookmetamethod   ✓       ✓       ✓       ✓       ✓        ✓
-- getconnections   ✓       ✓       ✓       ✓       ✓        ✓
-- getrawmetatable  ✓       ✓       ✓       ✓       ✓        ✓
-- newcclosure      ✓       ✓       ✓       ✓       ✓        ✓
-- cloneref         ✓       ✓       ✓       ✓       ✓        ✓
-- getnilinstances  ✓       ✓       ✓       ✓       ✓        ✗
-- run_on_actor     ✓       ✗       ✗       ✗       ✗        ✗
-- oth              ✗       ✗       ✗       ✗       ✗        ✗
-- setstackhidden   ✓       ✗       ✗       ✗       ✗        ✗
-- getfunctionhash  ✓       ✓       ✗       ✓       ✓        ✗
-- filtergc         ✓       ✗       ✗       ✗       ✗        ✗

## PATRONES CROSS-EXECUTOR RECOMENDADOS

-- Siempre verificar antes de usar:
local function safeHook(original, hook)
    if hookfunction then return hookfunction(original, hook) end
    if detour_function then return detour_function(original, hook) end
    warn("hookfunction no disponible en este executor")
    return original
end

-- Patrón de detección de executor:
local executor = "unknown"
if identifyexecutor then
    executor = identifyexecutor()
elseif getexecutorname then
    executor = getexecutorname()
elseif syn then
    executor = "Synapse X"
end

-- Normalizar nombre (Hydroxide pattern):
executor = executor:lower():split(" ")[1]

-- Verificar capacidades:
local caps = {
    hasActors    = run_on_actor ~= nil,
    hasOth       = oth ~= nil,
    hasFilterGc  = filtergc ~= nil,
    hasStackHide = setstackhidden ~= nil,
    hasFuncHash  = getfunctionhash ~= nil,
}
"""

# ══════════════════════════════════════════════════════════════════
# RICHIE0866/REMOTE-SPY — Outgoing remote spy
# ══════════════════════════════════════════════════════════════════
RICHIE_REMOTE_SPY_KB = """
## REMOTE SPY OUTGOING — PATRÓN SIMPLIFICADO

-- richie0866/remote-spy se enfoca solo en outgoing (cliente→servidor)
-- Patrón más simple que Cobalt, bueno para aprender el concepto base:

local namecallHook
namecallHook = hookmetamethod(game, "__namecall", newcclosure(function(self, ...)
    local method = getnamecallmethod()

    -- Solo interceptar métodos de remote
    if method == "FireServer" or method == "InvokeServer"
    or method == "Fire" or method == "Invoke" then
        -- Verificar que es un remote válido
        if typeof(self) == "Instance" and (
            self:IsA("RemoteEvent") or self:IsA("RemoteFunction")
            or self:IsA("BindableEvent") or self:IsA("BindableFunction")
        ) then
            local args = {...}
            -- Loggear
            print(string.format("[%s] %s:%s(%s)",
                self.ClassName,
                self:GetFullName(),
                method,
                serializeArgs(args)
            ))
        end
    end

    return namecallHook(self, ...)
end))

-- Serialización simple de argumentos:
local function serializeArgs(args)
    local parts = {}
    for _, v in ipairs(args) do
        local t = typeof(v)
        if t == "string" then
            parts[#parts+1] = string.format("%q", v)
        elseif t == "number" or t == "boolean" then
            parts[#parts+1] = tostring(v)
        elseif t == "Instance" then
            parts[#parts+1] = v:GetFullName()
        elseif t == "table" then
            parts[#parts+1] = "{...}"
        else
            parts[#parts+1] = t .. "(" .. tostring(v) .. ")"
        end
    end
    return table.concat(parts, ", ")
end
"""


def get_external_kb(focus: str = "all") -> str:
    """Retorna conocimiento de repos externos según el foco."""
    if focus == "hydroxide":
        return HYDROXIDE_KB
    elif focus == "synapse":
        return SYNAPSE_X_KB
    elif focus == "remotespy":
        return RICHIE_REMOTE_SPY_KB
    return HYDROXIDE_KB + "\n" + SYNAPSE_X_KB + "\n" + RICHIE_REMOTE_SPY_KB
