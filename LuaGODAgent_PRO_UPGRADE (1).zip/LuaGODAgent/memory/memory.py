"""
memory/memory.py — Memoria persistente con búsqueda, favoritos y exportación.
Más robusta para archivos corruptos y grandes.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
MEMORY_FILE = BASE_DIR / "memory.jsonl"


def is_valid_lua_prompt(prompt: str) -> bool:
    p = (prompt or "").strip().lower()
    if len(p) < 5:
        return False

    shell_patterns = [
        "cat ", "ls ", "cd ", "rm ", "mkdir", "grep ", "echo ",
        "sudo ", "pip ", "pkg ", "apt ", "chmod", "python ",
        "/root/", "/home/", "/tmp/", ":\\", ".exe", ".sh",
    ]
    if any(p.startswith(sp) or sp in p for sp in shell_patterns):
        return False

    if p.count("/") >= 2 and " " not in p[:20]:
        return False

    return True


def _entry_hash(code: str, prompt: str = "") -> str:
    raw = (code or "") + "||" + (prompt or "")
    return hashlib.md5(raw.encode("utf-8", errors="ignore")).hexdigest()[:8]


def _load_jsonl() -> list[dict]:
    if not MEMORY_FILE.exists():
        return []
    entries: list[dict] = []
    with MEMORY_FILE.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    entries.append(obj)
            except json.JSONDecodeError:
                continue
    return entries


def load_all() -> list:
    return _load_jsonl()


def count_entries() -> int:
    return len(load_all())


def _save_all(entries: list[dict]) -> None:
    MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp_fd, tmp_path = tempfile.mkstemp(prefix="memory_", suffix=".jsonl", dir=str(MEMORY_FILE.parent))
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            for e in entries:
                f.write(json.dumps(e, ensure_ascii=False) + "\n")
        os.replace(tmp_path, MEMORY_FILE)
    finally:
        try:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
        except OSError:
            pass


def save(prompt: str, code: str, score: int = 0, intent: str = "generic", lua_target: str = "luau"):
    if not is_valid_lua_prompt(prompt):
        return

    entry = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "prompt": prompt,
        "score": int(score),
        "code": code,
        "intent": intent,
        "lua_target": lua_target,
        "favorite": False,
        "hash": _entry_hash(code, prompt),
    }

    existing = load_all()
    if any(e.get("hash") == entry["hash"] for e in existing):
        return
    existing.append(entry)
    _save_all(existing)


def search(keyword: str) -> list:
    kw = (keyword or "").strip().lower()
    if not kw:
        return []
    results = []
    for e in load_all():
        prompt = str(e.get("prompt", "")).lower()
        code = str(e.get("code", "")).lower()
        name = str(e.get("name", "")).lower()
        if kw in prompt or kw in code or kw in name:
            results.append(e)
    return results


def toggle_favorite(index: int) -> bool:
    entries = load_all()
    if 1 <= index <= len(entries):
        entries[index - 1]["favorite"] = not entries[index - 1].get("favorite", False)
        _save_all(entries)
        return bool(entries[index - 1]["favorite"])
    return False


def get_favorites() -> list:
    return [e for e in load_all() if e.get("favorite")]


def get_by_name(name: str) -> dict | None:
    target = (name or "").strip().lower()
    if not target:
        return None
    for e in load_all():
        if str(e.get("name", "")).strip().lower() == target:
            return e
    return None


def save_named(name: str, code: str, prompt: str = ""):
    name = (name or "").strip()
    if not name:
        return
    entries = load_all()
    for e in entries:
        if str(e.get("name", "")).strip().lower() == name.lower():
            e["code"] = code
            e["prompt"] = prompt or e.get("prompt", "")
            e["timestamp"] = datetime.now().isoformat(timespec="seconds")
            e["hash"] = _entry_hash(code, prompt or e.get("prompt", ""))
            _save_all(entries)
            return
    entry = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "name": name,
        "prompt": prompt,
        "code": code,
        "score": 10,
        "intent": "saved",
        "lua_target": "luau",
        "favorite": True,
        "hash": _entry_hash(code, prompt),
    }
    entries.append(entry)
    _save_all(entries)


def export_lua(path: str = "luagod_snippets.lua") -> str:
    entries = [e for e in load_all() if int(e.get("score", 0) or 0) >= 7]
    lines = ["-- LuaGOD Snippets Export", f"-- Generado: {datetime.now().isoformat(timespec='seconds')}", ""]
    for e in entries:
        name = e.get("name") or e.get("prompt", "snippet")[:40]
        lines.append(f"-- ══ {name} ══")
        lines.append(str(e.get("code", "")))
        lines.append("")
    content = "\n".join(lines)
    out_path = Path(path)
    if not out_path.is_absolute():
        out_path = BASE_DIR / path
    out_path.write_text(content, encoding="utf-8")
    return str(out_path)
