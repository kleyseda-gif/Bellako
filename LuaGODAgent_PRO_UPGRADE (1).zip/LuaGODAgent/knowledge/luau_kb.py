"""
knowledge/luau_kb.py — Base de conocimiento Lua/Luau completa.
Cubre: Lua 5.1, 5.2, 5.3, 5.4, LuaJIT, Luau (Roblox), executores Android.
"""

# ══════════════════════════════════════════════════════════════════
# A) LUA CORE
# ══════════════════════════════════════════════════════════════════
LUA_CORE = """
## TIPOS DE DATOS
- nil: ausencia de valor. Elimina una variable al asignarla.
- boolean: true / false. Solo nil y false son falsy; 0 y "" son TRUTHY.
- number: Lua 5.2- solo float. Lua 5.3+ distingue integer (64-bit) y float.
  - math.type(1)    → "integer"
  - math.type(1.0)  → "float"
  - math.type("x")  → false (no es number)
- string: inmutable, 8-bit clean, indexada desde 1.
  - Multilínea: [[texto]] o [=[texto]=]
  - Hex: 0xFF · Científico: 1e10 · Binario (Lua 5.3+): 0b1010 NO existe, usar 0x
- table: único tipo de estructura. Array + hash en uno.
  - Índices 1-based por convención (ipairs, #, table.*)
  - t[1] ~= t["1"] — claves distintas
  - # solo es confiable en secuencias sin huecos
- function: first-class, closures, varargs con ...
- userdata: datos C opacos (ej: file handles)
- thread: coroutine

## OPERADORES
Aritméticos:  +  -  *  /  //  %  ^  (- unario)
  - /  siempre retorna float en Lua 5.3+
  - // floor division: 7//2 = 3, -7//2 = -4 (hacia -inf)
  - ^  potencia, siempre float
Relacionales: ==  ~=  <  >  <=  >=
  - == en tablas compara REFERENCIA, no contenido
  - nil == nil → true; nil == false → false
Lógicos: and  or  not
  - and/or retornan uno de sus operandos (no boolean)
  - x = x or default  ← patrón común para defaults
  - a and b or c  ← ternario (falla si b es false/nil, usar función)
Concatenación: ..  (convierte number a string automáticamente)
Longitud: #  (secuencias sin huecos; comportamiento indefinido con huecos)
Bitwise (Lua 5.3+): &  |  ~  <<  >>  ~x (NOT unario)

## SCOPE Y VARIABLES
- Global implícita: x = 1  (evitar, contamina _G)
- Local explícita: local x = 1  (SIEMPRE preferir)
- Upvalue: variable local capturada por una closure
- Bloque do...end crea scope nuevo
- Variables locales son más rápidas (acceso por índice vs hash en _G)

## COERCIÓN AUTOMÁTICA
- string → number en operaciones aritméticas: "10" + 5 = 15
- number → string en concatenación: 10 .. "px" = "10px"
- NO hay coerción en comparaciones: "1" == 1 → false

## CONTROL DE FLUJO
if cond then ... elseif cond then ... else ... end
while cond do ... end
repeat ... until cond          -- scope del until incluye el bloque
for i = start, stop, step do ... end   -- step default 1, puede ser negativo
for k, v in pairs(t) do ... end        -- todas las claves
for i, v in ipairs(t) do ... end       -- secuencia 1..n, para en nil
goto label / ::label::                 -- Lua 5.2+ (útil para continue)

## FUNCIONES
local function f(a, b, ...) end   -- declaración local
local f = function(a, b) end      -- equivalente
function t:method(a) end          -- azúcar para t.method = function(self, a)
-- Múltiples retornos:
local a, b = f()   -- si f retorna 2 valores
-- Varargs:
local function sum(...) local t={...} local s=0 for _,v in ipairs(t) do s=s+v end return s end
-- select('#', ...) cuenta argumentos incluyendo nil
"""

# ══════════════════════════════════════════════════════════════════
# B) FUNCIONES BUILT-IN
# ══════════════════════════════════════════════════════════════════
LUA_FUNCTIONS = """
## STRING
string.len(s)           -- #s, longitud en bytes
string.sub(s, i, j)     -- substring; índices negativos desde el final
string.rep(s, n, sep)   -- repetir n veces con separador (sep en 5.2+)
string.reverse(s)
string.upper(s) / string.lower(s)
string.byte(s, i, j)    -- códigos ASCII
string.char(...)         -- construir string desde códigos
string.format(fmt, ...) -- como printf: %d %f %s %q %x
string.find(s, pat, init, plain)  -- retorna start,end[,captures]
string.match(s, pat, init)        -- retorna captures o nil
string.gmatch(s, pat)             -- iterador de todas las coincidencias
string.gsub(s, pat, repl, n)      -- reemplazar; repl puede ser string/tabla/función
-- Métodos de objeto (s:method() == string.method(s, ...)):
("hola"):upper()  → "HOLA"

## MATH
math.abs(x)   math.ceil(x)   math.floor(x)   math.sqrt(x)
math.max(...)  math.min(...)
math.random()           -- [0,1)
math.random(n)          -- [1,n]
math.random(m,n)        -- [m,n]
math.randomseed(seed)   -- llamar con os.time() al inicio
math.sin/cos/tan/asin/acos/atan(y[,x])  -- atan2 en 5.3+ es math.atan(y,x)
math.huge   -- infinito positivo
math.pi
math.maxinteger / math.mininteger  -- Lua 5.3+
math.type(x)    -- "integer" | "float" | false
math.tointeger(x)  -- convierte float a int si es exacto, sino nil

## TABLE
table.insert(t, [pos,] val)   -- append o insertar en pos
table.remove(t, [pos])        -- eliminar y retornar; default último
table.sort(t, [comp])         -- in-place; comp(a,b) debe ser orden estricto
table.concat(t, [sep, i, j])  -- join de strings
table.move(a1, f, e, t[, a2]) -- Lua 5.3+: mover elementos
table.unpack(t, [i, j])       -- Lua 5.2+; en 5.1 es unpack(t)
table.pack(...)                -- Lua 5.2+; retorna tabla con campo 'n'

## IO / OS
io.write(...)     -- sin newline automático
io.read("l")      -- línea sin newline (default)
io.read("L")      -- línea con newline
io.read("n")      -- número
io.read("a")      -- todo el archivo
os.time()         -- epoch seconds
os.clock()        -- CPU time usado
os.date(fmt, t)   -- formato de fecha; "*t" retorna tabla
os.exit([code])

## GLOBALES CLAVE
print(...)                    -- tostring en cada arg, separados por tab
tostring(v)                   -- respeta __tostring
tonumber(s, [base])           -- base 2-36; nil si falla
type(v)                       -- "nil"|"boolean"|"number"|"string"|"table"|"function"|"userdata"|"thread"
pairs(t)                      -- itera todo (usa __pairs en 5.2+)
ipairs(t)                     -- itera secuencia 1..n
next(t, [key])                -- siguiente clave tras key (nil = primera)
select(n, ...)                -- args desde n; select('#',...) = count
rawget(t, k)                  -- sin __index
rawset(t, k, v)               -- sin __newindex
rawequal(a, b)                -- sin __eq
rawlen(t)                     -- sin __len (Lua 5.2+)
load(chunk, [name, mode, env]) -- compila string/función a función
dofile(filename)
require(modname)              -- carga módulo, cachea en package.loaded
assert(v, [msg])              -- error si v es falsy
error(msg, [level])           -- level 0=sin pos, 1=aquí, 2=caller
pcall(f, ...)                 -- retorna ok, result...
xpcall(f, handler, ...)       -- como pcall pero con handler de error
setmetatable(t, mt)           -- retorna t
getmetatable(t)               -- respeta __metatable
collectgarbage(opt, [arg])    -- "collect","count","stop","restart","step"
"""

# ══════════════════════════════════════════════════════════════════
# C) METATABLES Y OOP
# ══════════════════════════════════════════════════════════════════
LUA_METATABLES = """
## METAMÉTODOS COMPLETOS
__index(t, k)       -- acceso t[k] cuando k no existe; puede ser tabla o función
__newindex(t, k, v) -- asignación t[k]=v cuando k no existe
__add(a,b)  __sub  __mul  __div  __mod  __pow  __unm(a)
__idiv(a,b)         -- // Lua 5.3+
__band __bor __bxor __bnot __shl __shr  -- bitwise Lua 5.3+
__concat(a,b)       -- ..
__len(t)            -- #t
__eq(a,b)           -- == (solo si mismo metatable en Lua 5.1/5.2)
__lt(a,b)  __le(a,b)
__call(t, ...)      -- t(...)
__tostring(t)       -- tostring(t)
__gc(t)             -- finalizer (Lua 5.2+ para tablas)
__close(t)          -- to-be-closed: local x <close> = t  (Lua 5.4)
__metatable         -- protege: getmetatable retorna este valor

## CLASE BASE (patrón estándar)
local Animal = {}
Animal.__index = Animal

function Animal.new(name, sound)
    return setmetatable({name=name, sound=sound, hp=100}, Animal)
end

function Animal:speak()
    print(self.name .. " dice: " .. self.sound)
end

function Animal:takeDamage(n)
    self.hp = math.max(0, self.hp - n)
    return self.hp
end

## HERENCIA SIMPLE
local Dog = setmetatable({}, {__index = Animal})
Dog.__index = Dog

function Dog.new(name)
    local self = Animal.new(name, "Woof")
    return setmetatable(self, Dog)
end

function Dog:fetch(item)
    print(self.name .. " trae: " .. item)
end

local d = Dog.new("Rex")
d:speak()    -- heredado de Animal
d:fetch("pelota")

## HELPER class() PARA OOP LIMPIO
local function class(base)
    local cls = {}
    cls.__index = cls
    if base then
        setmetatable(cls, {__index = base})
    end
    function cls.new(...)
        local inst = setmetatable({}, cls)
        if inst.init then inst:init(...) end
        return inst
    end
    return cls
end

-- Uso:
local Entity = class()
function Entity:init(name, hp) self.name, self.hp = name, hp or 100 end
function Entity:status() print(self.name, self.hp) end

local Player = class(Entity)
function Player:init(name, level)
    Entity.init(self, name, 100 + level*10)
    self.level = level
end

## PROXY CON METATABLES (solo lectura)
local function readonly(t)
    return setmetatable({}, {
        __index    = t,
        __newindex = function(_, k, _)
            error("tabla de solo lectura: " .. tostring(k), 2)
        end,
        __metatable = false,
    })
end

## MIXIN
local function mixin(target, ...)
    for _, source in ipairs({...}) do
        for k, v in pairs(source) do
            if target[k] == nil then target[k] = v end
        end
    end
    return target
end
"""

# ══════════════════════════════════════════════════════════════════
# D) COROUTINES
# ══════════════════════════════════════════════════════════════════
LUA_COROUTINES = """
## API COMPLETA
coroutine.create(f)         -- crea coroutine, retorna thread
coroutine.resume(co, ...)   -- reanuda; retorna ok, valores de yield/return
coroutine.yield(...)        -- suspende; retorna valores pasados al siguiente resume
coroutine.wrap(f)           -- retorna función que resume automáticamente
coroutine.status(co)        -- "suspended"|"running"|"dead"|"normal"
coroutine.isyieldable()     -- true si puede hacer yield ahora
coroutine.running()         -- retorna co actual y bool (main thread)

## PRODUCER-CONSUMER
local function producer()
    local items = {"a", "b", "c"}
    for _, v in ipairs(items) do
        coroutine.yield(v)
    end
end

local co = coroutine.create(producer)
while true do
    local ok, val = coroutine.resume(co)
    if not ok or val == nil then break end
    print("Recibido:", val)
end

## ITERADOR CON YIELD
local function range(from, to, step)
    step = step or 1
    return coroutine.wrap(function()
        for i = from, to, step do
            coroutine.yield(i)
        end
    end)
end

for n in range(1, 10, 2) do print(n) end  -- 1 3 5 7 9

## ASYNC/AWAIT SIMULADO
local function async(f)
    local co = coroutine.create(f)
    local function step(...)
        local ok, result = coroutine.resume(co, ...)
        if not ok then error(result, 2) end
        return result
    end
    return step
end

local function await(value)
    return coroutine.yield(value)
end

## PIPELINE DE TRANSFORMACIÓN
local function map(gen, f)
    return coroutine.wrap(function()
        for v in gen do coroutine.yield(f(v)) end
    end)
end

local function filter(gen, pred)
    return coroutine.wrap(function()
        for v in gen do if pred(v) then coroutine.yield(v) end end
    end)
end
"""

# ══════════════════════════════════════════════════════════════════
# E) CLOSURES AVANZADAS
# ══════════════════════════════════════════════════════════════════
LUA_CLOSURES = """
## FÁBRICA DE FUNCIONES
local function multiplier(factor)
    return function(x) return x * factor end
end
local double = multiplier(2)
local triple = multiplier(3)
print(double(5))  -- 10

## MEMOIZACIÓN
local function memoize(f)
    local cache = {}
    return function(...)
        local key = table.concat({...}, ",")
        if cache[key] == nil then
            cache[key] = f(...)
        end
        return cache[key]
    end
end

local fib = memoize(function(n)
    if n <= 1 then return n end
    return fib(n-1) + fib(n-2)  -- fib debe ser upvalue
end)

## CURRYING
local function curry(f, arity)
    arity = arity or 2
    local function curried(args)
        if #args >= arity then
            return f(table.unpack(args))
        end
        return function(...)
            local newargs = {table.unpack(args)}
            for _, v in ipairs({...}) do newargs[#newargs+1] = v end
            return curried(newargs)
        end
    end
    return curried({})
end

## MAP / FILTER / REDUCE
local function map(t, f)
    local r = {}
    for i, v in ipairs(t) do r[i] = f(v) end
    return r
end

local function filter(t, pred)
    local r = {}
    for _, v in ipairs(t) do
        if pred(v) then r[#r+1] = v end
    end
    return r
end

local function reduce(t, f, init)
    local acc = init
    for _, v in ipairs(t) do acc = f(acc, v) end
    return acc
end

-- Ejemplo:
local nums = {1,2,3,4,5,6}
local evens = filter(nums, function(x) return x%2==0 end)
local doubled = map(evens, function(x) return x*2 end)
local sum = reduce(doubled, function(a,b) return a+b end, 0)
print(sum)  -- 24
"""

# ══════════════════════════════════════════════════════════════════
# F) PATRONES LUA (no regex estándar)
# ══════════════════════════════════════════════════════════════════
LUA_PATTERNS = """
## CLASES DE CARACTERES
.   cualquier caracter
%a  letra (isalpha)
%d  dígito
%l  minúscula
%u  mayúscula
%s  espacio/tab/newline/etc
%p  puntuación
%w  alfanumérico (%a + %d)
%c  caracter de control
%x  hexadecimal
%z  caracter nulo \\0
[set]   conjunto: [aeiou] [a-z0-9] [^abc] (negado)
Mayúscula = complemento: %A = no-letra, %D = no-dígito

## CUANTIFICADORES
*   0 o más (greedy)
+   1 o más (greedy)
-   0 o más (lazy/non-greedy)
?   0 o 1

## ANCLAS Y ESPECIALES
^   ancla inicio de string (solo al inicio del patrón)
$   ancla final de string
%b()  balanceado: %b{} %b[] %b<>
(capture)  grupo de captura
()  captura de posición (retorna número)

## EJEMPLOS
-- Extraer número de string:
local n = ("precio: 42"):match("%d+")  -- "42"

-- Iterar palabras:
for word in ("hola mundo lua"):gmatch("%a+") do print(word) end

-- Reemplazar con función:
local result = ("2+3=5"):gsub("%d+", function(n) return tonumber(n)*2 end)
-- "4+6=10"

-- Validar email simple:
local function isEmail(s)
    return s:match("^[%w%.]+@[%w%.]+%.[%a]+$") ~= nil
end

-- Captura múltiple:
local y, m, d = ("2024-01-15"):match("(%d+)-(%d+)-(%d+)")

-- Escapar caracter especial con %:
("1.2.3"):match("1%.2%.3")  -- el . literal

## DIFERENCIAS CON REGEX
- No hay | para alternativas (usar múltiples match)
- No hay grupos no-capturantes (?:...)
- No hay lookahead/lookbehind
- %b para balanceo es único de Lua
"""

# ══════════════════════════════════════════════════════════════════
# G) PERFORMANCE
# ══════════════════════════════════════════════════════════════════
PERFORMANCE_TIPS = """
## REGLAS DE ORO
1. LOCAL > GLOBAL: acceso local es ~30% más rápido
   local sin, cos = math.sin, math.cos  -- cachear upvalues

2. Evitar creación de tablas en hot paths:
   -- MAL: crea tabla cada frame
   for i=1,1000 do local t = {x=i, y=i} end
   -- BIEN: reusar tabla (object pool)

3. table.concat es más rápido que .. en bucles:
   local parts = {}
   for i=1,n do parts[i] = tostring(i) end
   local result = table.concat(parts, ",")

4. rawget/rawset evitan metamétodos (más rápido si no los necesitas)

5. # en secuencias es O(log n) en implementaciones estándar

6. Integer math > float math en Lua 5.3+:
   local x = 10 // 1  -- integer
   local y = 10 / 1   -- float (más lento)

7. Bitwise para flags (Lua 5.3+):
   local FLAGS = {VISIBLE=1, SOLID=2, ACTIVE=4}
   local state = FLAGS.VISIBLE | FLAGS.ACTIVE
   if state & FLAGS.VISIBLE ~= 0 then ... end

8. Weak tables para caché sin memory leak:
   local cache = setmetatable({}, {__mode="v"})  -- valores débiles

9. Pre-allocar tablas en Luau:
   local t = table.create(100, 0)  -- 100 slots inicializados a 0

10. En Roblox: task.wait() > wait() (más preciso, no throttled)
    RunService.Heartbeat > wait() para lógica por frame
    Heartbeat: física/movimiento
    RenderStepped: cámara/visual (solo cliente)
    Stepped: antes de física

## PROFILING EN LUAU
debug.profilebegin("MiOperacion")
-- código a medir
debug.profileend()
-- Ver en Microprofiler: Ctrl+F6 en Roblox Studio
"""

# ══════════════════════════════════════════════════════════════════
# H) DEBUG
# ══════════════════════════════════════════════════════════════════
DEBUG_TOOLS = """
## DEBUG LIBRARY
debug.traceback([thread,] [msg, [level]])  -- stack trace como string
debug.getinfo(f, "nSlu")   -- n=name, S=source, l=line, u=upvalues
debug.getlocal(level, n)   -- nombre y valor de local n en nivel level
debug.setlocal(level, n, v)
debug.getupvalue(f, n)     -- upvalue n de función f
debug.setupvalue(f, n, v)
debug.sethook(f, "clr", count)  -- c=call, l=line, r=return
debug.getmetatable(obj)    -- BYPASA __metatable (a diferencia de getmetatable)
debug.setmetatable(obj, mt)

## PATRONES DE ERROR
-- error con nivel:
local function validate(x)
    if type(x) ~= "number" then
        error("esperaba number, got " .. type(x), 2)  -- apunta al caller
    end
end

-- xpcall con traceback:
local function msgh(err)
    return debug.traceback(err, 2)
end
local ok, err = xpcall(risky_function, msgh)

-- assert como guard:
local function divide(a, b)
    assert(b ~= 0, "división por cero")
    return a / b
end

## EN ROBLOX/LUAU
warn("mensaje")          -- amarillo en output, no interrumpe
print("debug:", var)     -- siempre usar tostring para tablas
error("msg", 2)          -- nivel 2 = apunta al caller del caller
-- Script Analysis: Ctrl+Shift+A en Studio
-- Breakpoints: click en número de línea
"""

# ══════════════════════════════════════════════════════════════════
# I) ERRORES COMUNES
# ══════════════════════════════════════════════════════════════════
COMMON_ERRORS = """
## ERRORES FRECUENTES Y SOLUCIONES

1. attempt to index a nil value
   CAUSA: variable no inicializada o función que retorna nil
   FIX: verificar con if x ~= nil before indexing, o usar x = x or {}

2. attempt to call a nil value
   CAUSA: nombre de función mal escrito, o módulo no cargado
   FIX: print(type(miFuncion)) para verificar

3. attempt to perform arithmetic on a nil/string value
   CAUSA: tonumber() retornó nil, o variable no inicializada
   FIX: local n = tonumber(s); assert(n, "no es número: " .. s)

4. stack overflow
   CAUSA: recursión infinita (falta caso base)
   FIX: agregar condición de parada; considerar iteración

5. attempt to yield across metamethod/C-call boundary
   CAUSA: coroutine.yield dentro de pcall, xpcall, o callback C
   FIX: reestructurar para no hacer yield dentro de pcall

6. cannot resume non-suspended coroutine
   CAUSA: resumir coroutine muerta o ya en ejecución
   FIX: verificar coroutine.status(co) == "suspended" antes de resume

7. table index is NaN
   CAUSA: 0/0 o math.huge - math.huge como índice
   FIX: validar antes: if x ~= x then ... end  (NaN ~= NaN)

8. table index is nil
   CAUSA: usar nil como clave de tabla
   FIX: verificar que la clave no sea nil antes de asignar

9. invalid order function for sorting
   CAUSA: comparador no es orden estricto (debe ser a < b, no a <= b)
   FIX: function(a,b) return a.val < b.val end  (estrictamente menor)

10. # en tabla con huecos (undefined behavior)
    CAUSA: t[1]=1; t[3]=3 → #t puede ser 1 o 3
    FIX: usar contador explícito o table.pack/select('#',...)

11. Shadowing silencioso:
    local x = 10
    do local x = 20 end  -- x exterior sigue siendo 10
    -- Usar nombres distintos para evitar confusión

12. Closure captura referencia, no valor:
    local funcs = {}
    for i = 1, 3 do
        funcs[i] = function() print(i) end  -- MAL: todas imprimen 4
    end
    -- FIX:
    for i = 1, 3 do
        local j = i  -- nueva variable local por iteración
        funcs[i] = function() print(j) end
    end

13. require cachea el módulo — modificar package.loaded[name] para recargar

14. Comparar tipos distintos siempre es false (no error):
    1 == "1"  → false (no error, pero silencioso)

15. pairs(nil) → error. Siempre verificar que la tabla existe.

16. C stack overflow (distinto de Lua stack overflow):
    CAUSA: demasiadas llamadas C anidadas (ej: metamétodos que llaman metamétodos)
    FIX: romper la cadena de metamétodos

17. Forget return en función que debe retornar valor:
    local function getHP(player)
        if player then
            return player.hp
        end
        -- falta: return 0  ← retorna nil silenciosamente
    end

18. Concatenar number sin conversión en __tostring:
    local t = setmetatable({val=42}, {__tostring=function(self)
        return "Val: " .. self.val  -- OK, number se convierte
    end})

19. require con error de sintaxis en el módulo:
    -- El error real está oculto. Usar pcall(require, "modulo") para ver el error real.

20. setfenv no existe en Lua 5.2+ (solo 5.1/LuaJIT):
    -- En 5.2+: usar load(chunk, name, "t", env) con entorno explícito
"""

# ══════════════════════════════════════════════════════════════════
# J) LUAU / ROBLOX
# ══════════════════════════════════════════════════════════════════
LUAU_SPECIFIC = """
## SISTEMA DE TIPOS LUAU
type Point = {x: number, y: number}
export type Config = {name: string, value: number?}  -- ? = opcional
type Callback = (string, number) -> boolean
type Union = string | number | boolean
type Generic<T> = {value: T, transform: (T) -> T}

-- typeof() en runtime (como type() pero reconoce tipos Roblox)
typeof(Vector3.new())  → "Vector3"
typeof(workspace)      → "Instance"

## SERVICIOS ROBLOX ESENCIALES
local Players          = game:GetService("Players")
local Workspace        = game:GetService("Workspace")  -- o workspace
local RS               = game:GetService("ReplicatedStorage")
local SS               = game:GetService("ServerStorage")
local SSS              = game:GetService("ServerScriptService")
local TweenService     = game:GetService("TweenService")
local RunService       = game:GetService("RunService")
local UIS              = game:GetService("UserInputService")
local HttpService      = game:GetService("HttpService")
local DataStoreService = game:GetService("DataStoreService")
local CollectionService= game:GetService("CollectionService")
local PathfindingService=game:GetService("PathfindingService")
local MemoryStoreService=game:GetService("MemoryStoreService")
local MarketplaceService=game:GetService("MarketplaceService")

## INSTANCE API
inst:IsA("BasePart")
inst:FindFirstChild("Name", recursive)
inst:FindFirstChildOfClass("Part")
inst:FindFirstChildWhichIsA("BasePart", true)
inst:WaitForChild("Name", timeout)
inst:GetChildren()          -- array de hijos directos
inst:GetDescendants()       -- todos los descendientes
inst:GetFullName()          -- "Workspace.Model.Part"
inst:Clone()
inst:Destroy()
inst.Parent = workspace
inst.Changed:Connect(function(prop) end)
inst:GetPropertyChangedSignal("Position"):Connect(f)
inst:SetAttribute("key", value)
inst:GetAttribute("key")

## CFRAME COMPLETO
CFrame.new(x, y, z)
CFrame.new(pos, lookAt)           -- mira hacia lookAt
CFrame.Angles(rx, ry, rz)         -- radianes
CFrame.fromEulerAnglesXYZ(x,y,z)
CFrame.lookAt(at, lookAt, up)     -- Luau moderno
cf.Position, cf.LookVector, cf.RightVector, cf.UpVector
cf:ToObjectSpace(other)
cf:ToWorldSpace(other)
cf:Lerp(goal, alpha)              -- interpolación
cf:components()                   -- 12 números: x,y,z, r00..r22

## VECTOR3
Vector3.new(x, y, z)
v.Magnitude, v.Unit
v:Dot(other)    -- producto punto
v:Cross(other)  -- producto cruz
v:Lerp(other, t)
v:FuzzyEq(other, epsilon)

## RAYCASTING MODERNO
local params = RaycastParams.new()
params.FilterType = Enum.RaycastFilterType.Exclude
params.FilterDescendantsInstances = {character}
local result = workspace:Raycast(origin, direction * distance, params)
if result then
    local hit      = result.Instance
    local hitPos   = result.Position
    local normal   = result.Normal
    local material = result.Material
end

## TWEEN SERVICE
local info = TweenInfo.new(
    1,                          -- duración
    Enum.EasingStyle.Quad,
    Enum.EasingDirection.Out,
    0,                          -- repeticiones (-1 = infinito)
    false,                      -- reversa
    0                           -- delay
)
local tween = TweenService:Create(part, info, {Position = Vector3.new(0,10,0)})
tween:Play()
tween.Completed:Connect(function(state) end)

## DATASTORE
local DS = DataStoreService:GetDataStore("PlayerData")
-- Guardar:
local ok, err = pcall(function()
    DS:SetAsync("player_" .. userId, data)
end)
-- Cargar:
local ok, data = pcall(function()
    return DS:GetAsync("player_" .. userId)
end)
-- UpdateAsync (atómico, recomendado):
DS:UpdateAsync(key, function(old)
    old = old or {coins=0}
    old.coins += 10
    return old
end)

## HUMANOID
humanoid.Health, .MaxHealth, .WalkSpeed, .JumpHeight
humanoid:TakeDamage(amount)
humanoid.Died:Connect(f)
humanoid.HealthChanged:Connect(function(hp) end)
humanoid:GetState()  -- Enum.HumanoidStateType
humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
humanoid:MoveTo(position)
humanoid.MoveToFinished:Connect(function(reached) end)

## TASK LIBRARY (Luau moderno, reemplaza wait/spawn/delay)
task.wait(seconds)      -- más preciso que wait()
task.spawn(f, ...)      -- ejecuta en nuevo thread inmediatamente
task.defer(f, ...)      -- ejecuta al final del frame actual
task.delay(t, f, ...)   -- ejecuta después de t segundos
task.cancel(thread)     -- cancela thread creado con task.spawn/delay
"""

# ══════════════════════════════════════════════════════════════════
# K) EXECUTOR APIs (educativo)
# ══════════════════════════════════════════════════════════════════
LUAU_EXECUTOR_APIS = """
## APIs COMUNES EN EXECUTORES LUAU (uso educativo)
-- Estas APIs son específicas de executores como Delta Mobile, Fluxus, Arceus X, etc.
-- NO están disponibles en Roblox Studio ni en Lua estándar.

getgenv()           -- tabla global del executor
getrenv()           -- tabla global del juego (game._G equivalente)
getsenv(script)     -- entorno de un script específico
getfenv(func)       -- entorno de una función (como Lua 5.1 getfenv)
setfenv(func, env)  -- cambiar entorno de función

getrawmetatable(obj)         -- obtiene metatable ignorando __metatable
setrawmetatable(obj, mt)     -- setea metatable ignorando protección
hookfunction(orig, hook)     -- reemplaza función, retorna original
hookmetamethod(obj, method, hook)  -- hookea metamétodo
newcclosure(func)            -- convierte Lua closure a C closure
iscclosure(func)             -- true si es C closure
islclosure(func)             -- true si es Lua closure
checkcaller()                -- true si el caller es el executor
getcallingscript()           -- script que llamó la función actual

-- Filesystem (si el executor lo soporta):
writefile(path, content)
readfile(path)
listfiles(path)
makefolder(path)
isfolder(path) / isfile(path)
deletefile(path)

-- HTTP:
request({Url="https://...", Method="GET", Headers={}, Body=""})
httpget(url)  -- versión simplificada

-- Señales:
firesignal(signal, ...)
fireproximityprompt(prompt)
firetouchinterest(part, otherPart, touching)

## NOTA IMPORTANTE
Estas APIs varían entre executores. Siempre verificar disponibilidad:
if getgenv then
    -- código específico de executor
end
"""

# ══════════════════════════════════════════════════════════════════
# L) PATRONES DE DISEÑO EN LUA
# ══════════════════════════════════════════════════════════════════
DESIGN_PATTERNS = """
## SINGLETON
local Config = (function()
    local instance
    return {
        get = function()
            if not instance then
                instance = {debug=false, version="1.0"}
            end
            return instance
        end
    }
end)()

## EVENT EMITTER (Observer)
local EventEmitter = {}
EventEmitter.__index = EventEmitter

function EventEmitter.new()
    return setmetatable({_listeners={}}, EventEmitter)
end

function EventEmitter:on(event, fn)
    self._listeners[event] = self._listeners[event] or {}
    table.insert(self._listeners[event], fn)
end

function EventEmitter:emit(event, ...)
    for _, fn in ipairs(self._listeners[event] or {}) do fn(...) end
end

function EventEmitter:off(event, fn)
    local list = self._listeners[event] or {}
    for i, f in ipairs(list) do
        if f == fn then table.remove(list, i) return end
    end
end

## STATE MACHINE
local StateMachine = {}
StateMachine.__index = StateMachine

function StateMachine.new(initial)
    return setmetatable({state=initial, transitions={}}, StateMachine)
end

function StateMachine:addTransition(from, event, to, action)
    self.transitions[from] = self.transitions[from] or {}
    self.transitions[from][event] = {to=to, action=action}
end

function StateMachine:trigger(event)
    local t = (self.transitions[self.state] or {})[event]
    if t then
        if t.action then t.action(self.state, t.to) end
        self.state = t.to
        return true
    end
    return false
end

## DEEP COPY
local function deepcopy(orig)
    local copy
    if type(orig) == "table" then
        copy = {}
        for k, v in pairs(orig) do
            copy[deepcopy(k)] = deepcopy(v)
        end
        setmetatable(copy, deepcopy(getmetatable(orig)))
    else
        copy = orig
    end
    return copy
end

## SERIALIZACIÓN DE TABLA A STRING
local function serialize(val, indent)
    indent = indent or ""
    local t = type(val)
    if t == "string" then return string.format("%q", val)
    elseif t == "number" or t == "boolean" then return tostring(val)
    elseif t == "table" then
        local parts = {}
        local ni = indent .. "  "
        for k, v in pairs(val) do
            local key = type(k)=="string" and k or "["..tostring(k).."]"
            parts[#parts+1] = ni .. key .. " = " .. serialize(v, ni)
        end
        return "{\n" .. table.concat(parts, ",\n") .. "\n" .. indent .. "}"
    end
    return "nil"
end

## PROMISE SIMPLE CON COROUTINES
local Promise = {}
Promise.__index = Promise

function Promise.new(executor)
    local self = setmetatable({_cbs={}, _val=nil, _done=false}, Promise)
    local function resolve(val)
        self._val, self._done = val, true
        for _, cb in ipairs(self._cbs) do cb(val) end
    end
    executor(resolve)
    return self
end

function Promise:andThen(cb)
    if self._done then cb(self._val)
    else self._cbs[#self._cbs+1] = cb end
    return self
end

## OBJECT POOL
local function createPool(factory, reset)
    local pool = {}
    return {
        get = function()
            if #pool > 0 then
                local obj = table.remove(pool)
                if reset then reset(obj) end
                return obj
            end
            return factory()
        end,
        release = function(obj)
            pool[#pool+1] = obj
        end,
    }
end

## LOGGER
local Logger = {}
Logger.__index = Logger
local LEVELS = {DEBUG=1, INFO=2, WARN=3, ERROR=4}

function Logger.new(name, minLevel)
    return setmetatable({name=name, minLevel=LEVELS[minLevel or "DEBUG"]}, Logger)
end

function Logger:log(level, msg, ...)
    if LEVELS[level] >= self.minLevel then
        local formatted = #({...}) > 0 and string.format(msg, ...) or msg
        print(string.format("[%s][%s] %s", os.date("%H:%M:%S"), level, formatted))
    end
end

for level in pairs(LEVELS) do
    Logger[level:lower()] = function(self, msg, ...)
        self:log(level, msg, ...)
    end
end
"""

# ══════════════════════════════════════════════════════════════════
# FUNCIÓN PRINCIPAL: construir contexto para el prompt
# ══════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════
# M) SCRIPTING EDUCATIVO — TÉCNICAS COMUNES EN LUAU/EXECUTORES
#    Propósito: aprender cómo funcionan internamente estas mecánicas.
#    Todo el código es genérico, no apunta a ningún juego específico.
# ══════════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════════
# N) ANÁLISIS COBALT — TÉCNICAS INTERNAS DE EXECUTORES (educativo)
#    Basado en: ANALISIS_COBALT_SOLO.lua
#    Propósito: entender cómo funcionan los runtimes de executores
#    como Cobalt por dentro. Todo uso educativo.
# ══════════════════════════════════════════════════════════════════
COBALT_ANALYSIS = """
## COBALT — ARQUITECTURA GENERAL
-- Cobalt es un runtime monitor / executor Luau para Roblox.
-- Su arquitectura central gira en torno a 3 pilares:
--   1. WAX: sistema de bundling de módulos
--   2. wax.shared: tabla de estado global compartida entre módulos
--   3. cloneref: aislamiento de servicios del juego

-- Firma de Initialize (punto de entrada de cada módulo WAX):
local function Initialize(wax, script, require)
    -- wax       : tabla global del bundle (wax.shared, wax.script, etc.)
    -- script    : referencia al ModuleScript actual (como en Roblox)
    -- require   : función require interna del bundle (no la de Roblox)
    wax.shared.CobaltStartTime = tick()
    for _, Service in pairs({"ContentProvider","CoreGui","HttpService","Players"}) do
        wax.shared[Service] = cloneref(game:GetService(Service))
    end
end

-- wax.shared es el equivalente a _G pero AISLADO del juego:
-- - Persiste entre módulos del mismo bundle
-- - No es accesible desde scripts del juego
-- - Se inicializa una vez y se pasa a todos los módulos via wax

## cloneref() — POR QUÉ COBALT CLONA REFERENCIAS DE SERVICIOS

### El problema que resuelve:
Roblox expone servicios como singletons: game:GetService("RunService")
siempre retorna el MISMO objeto. Si el juego o un anti-cheat hookea
ese objeto (via __index/__newindex en su metatable), cualquier acceso
al servicio pasa por el hook.

cloneref() crea una referencia alternativa al mismo objeto C++ subyacente
pero con una identidad Lua diferente — los hooks en el original no afectan
al clon, y rawequal(original, clon) == false.

### Implementación conceptual (Lua puro para entender el principio):
-- En Lua estándar no existe cloneref, pero el concepto es:
local function conceptualCloneref(service)
    -- Crear proxy que apunta al mismo objeto pero con metatable limpia
    local proxy = newproxy(true)  -- userdata con metatable
    local mt = getmetatable(proxy)
    mt.__index    = service       -- delegar al original
    mt.__newindex = service
    mt.__tostring = function() return tostring(service) end
    return proxy
    -- Resultado: proxy.Property == service.Property
    -- pero rawequal(proxy, service) == false
    -- y hooks en getmetatable(service).__index NO afectan a proxy
end

### Por qué Cobalt clona estos servicios específicos:
-- ContentProvider : para cargar assets sin que el juego lo detecte
-- CoreGui         : para crear UI invisible al juego (ESP, menús)
-- HttpService     : para requests sin pasar por hooks del juego
-- RunService      : para Heartbeat/Stepped sin ser detectado
-- LogService      : para suprimir o interceptar logs

### Patrón completo que usa Cobalt:
local Services = {}
local serviceNames = {
    "ContentProvider", "CoreGui", "HttpService",
    "RunService", "LogService"
}
for _, name in ipairs(serviceNames) do
    -- cloneref es una función del executor, no de Roblox estándar
    Services[name] = cloneref(game:GetService(name))
end
-- Ahora Services.RunService.Heartbeat no está hookeado por el juego


## GenerateGUID() — TOKENS DE VERIFICACIÓN

HttpService:GenerateGUID(wrapInCurlyBraces)
-- Genera un UUID v4 aleatorio: "550e8400-e29b-41d4-a716-446655440000"
-- wrapInCurlyBraces=false → sin llaves (default true)

### Usos en executores:
-- 1. Identificar sesión única del executor
-- 2. Crear nombres únicos para objetos (evitar colisiones con el juego)
-- 3. Tokens de autenticación entre módulos internos
-- 4. Nombres de RemoteEvents temporales

local token = game:GetService("HttpService"):GenerateGUID(false)
-- Crear instancia con nombre único que no colisiona:
local folder = Instance.new("Folder")
folder.Name   = "_cobalt_" .. token:sub(1, 8)
folder.Parent = game:GetService("CoreGui")


## WAX BUNDLER — CÓMO FUNCIONA EL SISTEMA DE MÓDULOS

### Qué es WAX:
WAX es un bundler para scripts Luau de executores. Toma múltiples
módulos .lua y los empaqueta en un solo script con un sistema de
require() interno. Similar a webpack/rollup pero para Luau.

### Estructura interna de un bundle WAX:
-- El bundle genera algo así:
local __BUNDLE__ = {}  -- tabla que actúa como package.loaded

local function __REQUIRE__(id)
    if __BUNDLE__[id] then
        return __BUNDLE__[id]
    end
    error("módulo no encontrado: " .. tostring(id))
end

-- Cada módulo se registra así:
__BUNDLE__["FileLog"] = (function()
    -- contenido del módulo FileLog aquí
    local M = {}
    function M.write(path, content)
        -- lógica de escritura
    end
    return M
end)()

__BUNDLE__["Connect"] = (function()
    -- contenido del módulo Connect aquí
    local M = {}
    function M.new(url)
        -- lógica de conexión HTTP
    end
    return M
end)()

-- Punto de entrada:
local FileLog = __REQUIRE__("FileLog")
local Connect = __REQUIRE__("Connect")

### Cómo RECUPERAR módulos de un bundle WAX en runtime:
-- Si tienes acceso al entorno del script (via getsenv):
local env = getsenv(targetScript)
-- El bundler expone __BUNDLE__ o similar en el entorno
local bundle = rawget(env, "__BUNDLE__") or rawget(env, "BUNDLED_DATA")
if bundle then
    for moduleName, moduleContent in pairs(bundle) do
        print("Módulo encontrado:", moduleName, type(moduleContent))
    end
end

-- Alternativa: buscar en el upvalue del script principal
local function findUpvalue(func, name)
    local i = 1
    while true do
        local n, v = debug.getupvalue(func, i)
        if not n then break end
        if n == name then return v end
        i = i + 1
    end
end


## MÓDULO FileLog — ANÁLISIS

### Qué hace FileLog en Cobalt:
-- Registra operaciones del executor en archivos locales.
-- Patrón típico de implementación:

local FileLog = {}
FileLog.__index = FileLog

function FileLog.new(filename)
    return setmetatable({
        path     = filename or "cobalt_log.txt",
        buffer   = {},
        maxLines = 500,
    }, FileLog)
end

function FileLog:write(level, message)
    local entry = string.format("[%s][%s] %s",
        os.date("%H:%M:%S"),
        level,
        tostring(message)
    )
    self.buffer[#self.buffer + 1] = entry

    -- Flush si el executor tiene writefile:
    if writefile then
        writefile(self.path, table.concat(self.buffer, "\n"))
    end
end

function FileLog:info(msg)  self:write("INFO",  msg) end
function FileLog:warn(msg)  self:write("WARN",  msg) end
function FileLog:error(msg) self:write("ERROR", msg) end

-- Uso:
local log = FileLog.new("cobalt.log")
log:info("Cobalt iniciado")
log:warn("Servicio hookeado detectado")


## MÓDULO Connect — ANÁLISIS

### Qué hace Connect en Cobalt:
-- Maneja comunicación HTTP del executor (verificación, updates, C2).
-- Patrón típico:

local Connect = {}
Connect.__index = Connect

function Connect.new(baseUrl, token)
    return setmetatable({
        base    = baseUrl,
        token   = token,
        timeout = 10,
    }, Connect)
end

function Connect:request(endpoint, method, body)
    method = method or "GET"
    local url = self.base .. endpoint

    -- En executor con request():
    local ok, result = pcall(function()
        return request({
            Url     = url,
            Method  = method,
            Headers = {
                ["Authorization"] = "Bearer " .. self.token,
                ["Content-Type"]  = "application/json",
                ["X-Executor"]    = "Cobalt",
            },
            Body = body and game:GetService("HttpService"):JSONEncode(body) or nil,
        })
    end)

    if not ok then return nil, result end
    if result.StatusCode ~= 200 then
        return nil, "HTTP " .. result.StatusCode
    end

    local decoded = pcall(function()
        return game:GetService("HttpService"):JSONDecode(result.Body)
    end)
    return decoded
end

-- Verificación de licencia (patrón común en executores):
function Connect:verify(hwid)
    return self:request("/verify", "POST", {hwid = hwid})
end


## INTERCEPTACIÓN DE RED — CÓMO COBALT MONITOREA REQUESTS

### Hookeando HttpService para interceptar todas las requests del juego:
-- Esto permite ver qué URLs contacta el juego (anti-cheat, telemetría, etc.)

local HttpService = cloneref(game:GetService("HttpService"))
local originalRequest = HttpService.RequestAsync

-- Hook via metatable del servicio clonado:
local mt = getrawmetatable(HttpService)
local oldIndex = mt.__index

mt.__index = newcclosure(function(self, key)
    if key == "RequestAsync" then
        return function(self2, options)
            -- Interceptar y loggear
            print("[NetSpy] URL:", options.Url, "| Method:", options.Method)
            -- Llamar original
            return originalRequest(self2, options)
        end
    end
    return oldIndex(self, key)
end)


## DETECCIÓN DE ANTI-CHEAT — TÉCNICAS QUE USA COBALT

### 1. Detectar hooks en servicios (el juego hookeó algo):
local function isHooked(service, methodName)
    local mt = getrawmetatable(service)
    if not mt then return false end
    -- Si __index es una función (no tabla), probablemente está hookeado
    local idx = rawget(mt, "__index")
    return type(idx) == "function"
end

### 2. Detectar si hay scripts de anti-cheat activos:
local function findAntiCheat()
    local suspects = {}
    for _, script in ipairs(game:GetDescendants()) do
        if script:IsA("LocalScript") or script:IsA("ModuleScript") then
            local name = script.Name:lower()
            if name:find("anticheat") or name:find("security")
            or name:find("detect") or name:find("protect") then
                suspects[#suspects+1] = script:GetFullName()
            end
        end
    end
    return suspects
end

### 3. Verificar si checkcaller() está activo (el juego lo usa):
-- Si el juego usa checkcaller() en sus funciones críticas,
-- llamarlas desde el executor retorna false y el juego lo sabe.
-- Solución: newcclosure() hace que checkcaller() retorne true.

local function safeCall(func, ...)
    local wrapped = newcclosure(function(...) return func(...) end)
    return pcall(wrapped, ...)
end

## WAX BUNDLER — ARQUITECTURA INTERNA COMPLETA

-- WAX (latte-soft/wax) es un bundler Lua 5.1+/Luau.
-- Toma un proyecto multi-módulo y lo colapsa en UN solo script.
-- Usa semántica de require() de Roblox: require(script.ModuleName)

-- ESTRUCTURA DEL BUNDLE GENERADO:
local __MODULES__ = {}   -- registro de todos los módulos
local __LOADED__  = {}   -- caché (equivalente a package.loaded)

local function __REQUIRE__(id)
    if __LOADED__[id] ~= nil then
        return __LOADED__[id]
    end
    local factory = __MODULES__[id]
    if not factory then
        error("módulo no encontrado: " .. tostring(id), 2)
    end
    -- Ejecutar factory UNA sola vez, cachear resultado
    local result = factory()
    __LOADED__[id] = result
    return result
end

-- Cada módulo se registra como factory function:
__MODULES__["Cobalt.FileLog"] = function()
    local M = {}
    -- ... contenido del módulo ...
    return M
end

__MODULES__["Cobalt.Connect"] = function()
    local M = {}
    return M
end

-- wax pasa 3 argumentos a cada módulo:
-- wax    : tabla global del bundle
-- script : referencia virtual al ModuleScript
-- require: función __REQUIRE__ del bundle

-- CÓMO RECUPERAR MÓDULOS DE UN BUNDLE WAX EN RUNTIME:
-- Método 1: via getsenv (si tienes acceso al script)
local env = getsenv(targetScript)
local modules = rawget(env, "__MODULES__")
    or rawget(env, "BUNDLED_MODULES")
    or rawget(env, "WAX_MODULES")
if modules then
    for name, factory in pairs(modules) do
        print("Módulo:", name, type(factory))
    end
end

-- Método 2: via debug.getupvalue en la función principal
local function findUpvalue(func, name)
    local i = 1
    while true do
        local n, v = debug.getupvalue(func, i)
        if not n then break end
        if n == name then return v, i end
        i = i + 1
    end
    return nil
end

-- Método 3: via getgc() buscar tablas con claves de módulos
local function findBundleTable()
    for _, obj in ipairs(getgc(true)) do
        if type(obj) == "table" then
            local keys = {}
            for k in pairs(obj) do keys[#keys+1] = k end
            -- Bundle WAX tiene claves con formato "Module.SubModule"
            if #keys > 3 and type(keys[1]) == "string"
               and keys[1]:find("%.") then
                return obj
            end
        end
    end
end

## COBALT — MÓDULO FileLog COMPLETO

local FileLog = {}
FileLog.__index = FileLog

function FileLog.new(config)
    config = config or {}
    return setmetatable({
        path     = config.path     or "cobalt/cobalt.log",
        maxLines = config.maxLines or 1000,
        buffer   = {},
        enabled  = config.enabled  ~= false,
    }, FileLog)
end

function FileLog:_write(level, msg, ...)
    if not self.enabled then return end
    local text = (select('#', ...) > 0)
        and string.format(tostring(msg), ...)
        or  tostring(msg)
    local entry = string.format("[%s][%s] %s",
        os.date("%Y-%m-%d %H:%M:%S"), level, text)
    self.buffer[#self.buffer + 1] = entry
    -- Rotar si supera maxLines
    if #self.buffer > self.maxLines then
        table.remove(self.buffer, 1)
    end
    -- Flush a disco si writefile disponible
    if writefile then
        pcall(writefile, self.path,
            table.concat(self.buffer, "\n"))
    end
    return entry
end

FileLog.debug = function(self, m, ...) return self:_write("DEBUG", m, ...) end
FileLog.info  = function(self, m, ...) return self:_write("INFO",  m, ...) end
FileLog.warn  = function(self, m, ...) return self:_write("WARN",  m, ...) end
FileLog.error = function(self, m, ...) return self:_write("ERROR", m, ...) end

function FileLog:read()
    if readfile then
        local ok, data = pcall(readfile, self.path)
        return ok and data or table.concat(self.buffer, "\n")
    end
    return table.concat(self.buffer, "\n")
end

function FileLog:clear()
    self.buffer = {}
    if writefile then pcall(writefile, self.path, "") end
end

## COBALT — MÓDULO Connect COMPLETO

local Connect = {}
Connect.__index = Connect

-- HttpService cacheado via cloneref para evitar hooks del juego
local _Http = cloneref and cloneref(game:GetService("HttpService"))
           or game:GetService("HttpService")

function Connect.new(config)
    config = config or {}
    return setmetatable({
        base    = config.base    or "",
        token   = config.token   or "",
        timeout = config.timeout or 15,
        retries = config.retries or 3,
        log     = config.log,  -- FileLog opcional
    }, Connect)
end

function Connect:_request(endpoint, method, body, headers)
    local url = self.base .. endpoint
    local reqHeaders = {
        ["Content-Type"]  = "application/json",
        ["Authorization"] = self.token ~= "" and ("Bearer " .. self.token) or nil,
        ["X-Cobalt"]      = "1",
    }
    -- Merge headers adicionales
    if headers then
        for k, v in pairs(headers) do reqHeaders[k] = v end
    end

    local payload = {
        Url     = url,
        Method  = method or "GET",
        Headers = reqHeaders,
        Body    = body and _Http:JSONEncode(body) or nil,
    }

    for attempt = 1, self.retries do
        local ok, res = pcall(request or http_request or
            function() error("no HTTP function available") end,
            payload)

        if ok and res and res.StatusCode then
            if res.StatusCode == 200 then
                local decoded
                pcall(function()
                    decoded = _Http:JSONDecode(res.Body)
                end)
                return decoded or res.Body, nil
            elseif res.StatusCode == 429 then
                -- Rate limit: esperar y reintentar
                task.wait(2 ^ attempt)
            else
                return nil, "HTTP " .. res.StatusCode
            end
        else
            if attempt == self.retries then
                return nil, tostring(res)
            end
            task.wait(1)
        end
    end
    return nil, "max retries exceeded"
end

function Connect:get(endpoint, headers)
    return self:_request(endpoint, "GET", nil, headers)
end

function Connect:post(endpoint, body, headers)
    return self:_request(endpoint, "POST", body, headers)
end

-- Verificación de licencia por HWID (patrón Cobalt):
function Connect:verify(hwid, version)
    return self:post("/verify", {
        hwid    = hwid,
        version = version or "unknown",
        time    = os.time(),
    })
end

-- Obtener configuración remota:
function Connect:getConfig(key)
    return self:get("/config/" .. tostring(key))
end

## COBALT — SISTEMA DE INICIALIZACIÓN COMPLETO

-- Patrón completo que usa Cobalt al cargar:
local Cobalt = {}

function Cobalt.init()
    -- 1. Registrar tiempo de inicio
    local startTime = tick()

    -- 2. Clonar servicios críticos (aislamiento de hooks del juego)
    local services = {}
    local serviceList = {
        "ContentProvider", "CoreGui",    "HttpService",
        "Players",         "RunService", "LogService",
        "TweenService",    "UserInputService",
    }
    for _, name in ipairs(serviceList) do
        local ok, svc = pcall(game.GetService, game, name)
        if ok then
            services[name] = (cloneref and cloneref(svc)) or svc
        end
    end

    -- 3. Inicializar logger
    local log = FileLog.new({path = "cobalt/runtime.log"})
    log:info("Cobalt iniciando — tick: %.3f", startTime)

    -- 4. Generar token de sesión único
    local sessionToken = services.HttpService:GenerateGUID(false)
    log:info("Session token: %s", sessionToken:sub(1, 8) .. "...")

    -- 5. Crear carpeta de trabajo si no existe
    if not isfolder("cobalt") then
        pcall(makefolder, "cobalt")
    end

    -- 6. Retornar contexto compartido (wax.shared)
    return {
        services     = services,
        log          = log,
        sessionToken = sessionToken,
        startTime    = startTime,
        version      = "1.0.0",
    }
end

## COBALT — NETWORK MONITOR (interceptación de red)

-- Cobalt monitorea requests del juego hookeando __namecall
-- en el metatable de HttpService clonado.

local function setupNetworkMonitor(sharedServices, log)
    local Http = sharedServices.HttpService
    local mt   = getrawmetatable(Http)
    if not mt then
        log:warn("No se pudo obtener metatable de HttpService")
        return
    end

    local oldNamecall = mt.__namecall
    -- makereadonly(mt, false)  -- si el executor lo requiere

    mt.__namecall = newcclosure(function(self, ...)
        local method = getnamecallmethod()
        local args   = {...}

        if method == "RequestAsync" or method == "GetAsync"
        or method == "PostAsync" then
            local url = type(args[1]) == "table"
                and args[1].Url or tostring(args[1])
            log:info("[NetMon] %s → %s", method, url)
        end

        return oldNamecall(self, ...)
    end)

    log:info("Network monitor activo")
end

## COBALT — DETECCIÓN DE ENTORNO Y COMPATIBILIDAD

local function detectEnvironment()
    local env = {
        executor  = "unknown",
        version   = "unknown",
        platform  = "unknown",
        hasDrawing = false,
        hasRequest = false,
        hasFs      = false,
    }

    -- Identificar executor
    if identifyexecutor then
        env.executor, env.version = identifyexecutor()
    elseif getexecutorname then
        env.executor = getexecutorname()
    end

    -- Detectar plataforma
    local UIS = game:GetService("UserInputService")
    if UIS.TouchEnabled and not UIS.KeyboardEnabled then
        env.platform = "mobile"
    elseif UIS.KeyboardEnabled then
        env.platform = "pc"
    end

    -- Capacidades disponibles
    env.hasDrawing = Drawing ~= nil
    env.hasRequest = (request or http_request or http.request) ~= nil
    env.hasFs      = writefile ~= nil

    return env
end

-- Uso en Cobalt.init():
-- local env = detectEnvironment()
-- if env.executor:lower():find("cobalt") then ... end
"""

COBALT_SOURCE_0 = """
## EXECUTORSUPPORT — VERIFICACIÓN REAL DE CAPACIDADES

-- test(name, callback, checkType, essential)
-- checkType=true  → solo verifica typeof == "function"
-- checkType=false → ejecuta callback como test real
-- essential=false → fallo no bloquea funcionalidad core

local BrokenFeatures = {
    ["Volcano"]  = { "oth", "run_on_actor" },
    ["Seliware"] = { "run_on_actor" },
}

-- hookfunction: verifica que realmente cambia retorno Y devuelve original
test("hookfunction", function()
    local function Original(a, b) return a + b end
    local ref = hookfunction(Original, function(a, b) return a * b end)
    assert(Original(2, 3) == 6)  -- hookeada: 2*3
    assert(ref(2, 3) == 5)       -- original: 2+3
end)

-- newcclosure: verifica que debug.info retorna "[C]"
test("newcclosure", function()
    local cc = newcclosure(function() return true end)
    assert(cc() == true)
    assert(debug.info(cc, "s") == "[C]")
end)

-- setstackhidden: oculta función del traceback (non-essential)
-- Cobalt lo usa en detours para que el juego no vea sus funciones en el stack
test("setstackhidden", function()
    local f = loadstring("local StackCheck = ...\nlocal function CallerFunction()\n  return StackCheck[1]()\nend\nreturn CallerFunction")(
        {function() return debug.info(2, "f") end}
    )
    setstackhidden(f, true)
    assert(f() ~= f)  -- la función no aparece en debug.info
end, false, false)

-- oth (One-Thread Hooks): hook en thread SEPARADO
-- Diferencia crítica vs hookfunction: el hook corre en su propio coroutine
-- → el juego no puede detectar al executor en el callstack
-- oth.is_hook_thread()       → true si estás dentro del hook
-- oth.get_original_thread()  → thread que disparó el hook original
test("oth", function()
    assert(oth ~= nil)
    assert(hookfunction ~= oth.hook)      -- NO es alias
    assert(restorefunction ~= oth.unhook) -- NO es alias
    -- Test real: hookea VIM.SendGravityEvent y verifica thread separado
    local VIM = Instance.new("VirtualInputManager")
    local Origin = coroutine.running()
    local Working = nil
    local Old
    Old = oth.hook(VIM.SendGravityEvent, function(...)
        if Working == nil then
            Working = (Origin ~= coroutine.running()
                and oth.is_hook_thread()
                and oth.get_original_thread() == Origin)
            return
        end
        return Old(...)
    end)
    pcall(VIM.SendGravityEvent, VIM, 0, 0, 0)
    repeat task.wait() until Working ~= nil
    oth.unhook(VIM.SendGravityEvent, Old)
    VIM:Destroy()
    assert(Working)
end, false, false)

-- getcallbackvalue: obtiene el callback de OnInvoke/OnClientInvoke
test("getcallbackvalue", function()
    local bf = Instance.new("BindableFunction")
    local ran = false
    bf.OnInvoke = function(v) ran = true; return v * 2 end
    local fn = getcallbackvalue(bf, "OnInvoke")
    bf:Destroy()
    assert(typeof(fn) == "function")
    assert(fn(5) == 10)
    assert(ran)
end)

-- getconnections: retorna tabla de conexiones de un signal
-- Cada conexión tiene: .Function, .Thread, .ForeignState, .Enabled
-- Métodos: :Disable(), :Enable(), :Fire(...), :Disconnect()
test("getconnections", function()
    local ev = Instance.new("BindableEvent")
    local fn1 = function() end
    local fn2 = function() end
    ev.Event:Connect(fn1)
    ev.Event:Once(fn2)
    task.spawn(function() ev.Event:Wait() end)
    local conns = getconnections(ev.Event)
    assert(#conns == 3)  -- Connect + Once + Wait
    ev:Destroy()
end)

-- ForeignState: conexión creada desde otro script/executor
-- Cobalt lo usa para NO loggear sus propias conexiones:
for _, conn in getconnections(signal) do
    if conn.ForeignState then continue end  -- skip executor connections
    -- procesar solo conexiones del juego
end

## HOOKING.LUA — PRIORIDAD DE MÉTODOS

Hooking.HookFunction = function(Original, Replacement)
    -- 1. oth (thread separado, más seguro, no detectable)
    if ExecutorSupport["oth"].IsWorking
    and iscclosure(Original) and islclosure(Replacement) then
        return oth.hook(Original, Replacement)
    end
    -- Siempre convertir a C closure (algunos executores lo requieren)
    if islclosure(Replacement) then
        Replacement = newcclosure(Replacement)
    end
    if not ExecutorSupport["hookfunction"].IsWorking then
        return Original  -- fallback silencioso, no crashea
    end
    return hookfunction(Original, Replacement)
end

Hooking.HookMetaMethod = function(object, method, hook)
    local mt = getrawmetatable(object)
    local original = rawget(mt, method)
    -- 1. oth
    if ExecutorSupport["oth"].IsWorking then return oth.hook(original, hook) end
    if islclosure(hook) then hook = newcclosure(hook) end
    -- 2. hookmetamethod
    if ExecutorSupport["hookmetamethod"].IsWorking then
        return hookmetamethod(object, method, hook)
    end
    -- 3. setreadonly + rawset (modo alternativo)
    if AlternativeEnabled or ExecutorSupport["getrawmetatable"].IsWorking then
        setreadonly(mt, false)
        rawset(mt, method, hook)
        setreadonly(mt, true)
        return original
    end
    -- 4. xpcall trick: obtener metamétodo sin hookmetamethod
    -- Dispara el metamétodo intencionalmente y captura la función via debug.info
    if method == "__namecall" then
        local _, fn = xpcall(function() object:Mustard() end,
                             function() return debug.info(2, "f") end)
        return fn
    elseif method == "__newindex" then
        local _, fn = xpcall(function() object[tostring(math.random())] = true end,
                             function() return debug.info(2, "f") end)
        return fn
    end
end

## AWP EXECUTOR — BUG DE newcclosure

-- AWP tiene un bug donde newcclosure no funciona correctamente.
-- Workaround: setfenv deoptimiza la función, forzando al executor
-- a tratarla de forma diferente internamente.
local newcclosure_awp = function(f, name)
    local env = getfenv(f)
    local x = setmetatable({ __F = f }, { __index = env, __newindex = env })
    local nf = function(...) return __F(...) end
    setfenv(nf, x)  -- deoptimiza → __F se resuelve via __index de x
    return newcclosure(nf, name)
end

## ACTOR VM — COMUNICACIÓN CROSS-VM

-- Actors corren en VMs Lua separadas. Los hooks del main thread NO aplican.
-- Solución de Cobalt: inyectar código en cada Actor via run_on_actor.

local ChannelID, Channel = create_comm_channel()
-- Channel es un BindableEvent especial que cruza VMs

-- Serializar función para cruzar VM (funciones no cruzan directamente):
local function FunctionToMetadata(fn)
    local meta = {
        Address  = tostring(fn),
        Name     = debug.info(fn, "n"),
        Source   = debug.info(fn, "s"),
        IsC      = iscclosure(fn),
    }
    if not iscclosure(fn) then
        meta.Upvalues  = debug.getupvalues(fn)
        meta.Constants = debug.getconstants(fn)
        meta.Protos    = debug.getprotos(fn)
        if getfunctionhash then
            meta.FunctionHash = getfunctionhash(fn)
        end
    end
    meta.Validation = CobaltVerificationToken  -- para verificar origen
    meta.__Function = true
    return meta
end

-- Tablas cíclicas entre VMs: se resuelven con IDs únicos
-- Actor → Main: Fire("ActorCall", instance, type, FixTable(info), cyclicRefs)
-- Main reconstruye la tabla con ReconstructTable(rawInfo, cyclicRefs)

-- Fix para Seliware: sus Actor BindableEvents están en CoreGui
-- Por eso Cobalt usa setthreadidentity(8) antes de Fire:
local identity = getthreadidentity()
setthreadidentity(8)
Channel.Fire(Channel, "ActorCall", instance, type, FixTable(info))
setthreadidentity(identity)

## FFLAG FIX — ACTORS EN MAIN THREAD

-- Si el juego usa Actors pero el executor no soporta run_on_actor:
-- Cobalt puede forzar que los Actors corran en el main thread via FFlag.
-- Esto hace que los hooks del main thread SÍ apliquen en los Actors.
if CheckFFlagValue("DebugRunParallelLuaOnMainThread", false)
and not ExecutorSupport["run_on_actor"].IsWorking then
    -- Verificar si el juego realmente usa Actors
    local usesActors = false
    for _, inst in game:QueryDescendants("Actor") do
        usesActors = true; break
    end
    if usesActors then
        setfflag("DebugRunParallelLuaOnMainThread", "true")
        -- Requiere rejoin para aplicar
    end
end
"""

# ══════════════════════════════════════════════════════════════════
# COBALT FUENTE REAL — PARTE 1: ExecutorSupport + Hooking
# ══════════════════════════════════════════════════════════════════
COBALT_SOURCE_1 = """
## EXECUTORSUPPORT — SISTEMA DE VERIFICACIÓN DE CAPACIDADES

-- Cobalt verifica cada función del executor ANTES de usarla.
-- Patrón: test(name, callback, checkType, essential)
-- checkType=true → solo verifica existencia (typeof == function)
-- checkType=false → ejecuta el callback como test real
-- essential=true → fallo bloquea funcionalidad core

local ExecutorSupport = { FailedChecks = { Essential = {}, NonEssential = {} } }

local function test(name, Callback, CheckType, Essential)
    if Essential == nil then Essential = true end

    local TestFunction = not CheckType and Callback or function()
        assert(typeof(Callback) == "function", name .. " is not a function.")
    end

    local Success, Result = pcall(TestFunction)
    ExecutorSupport[name] = { IsWorking = Success, Details = Result, Essential = Essential }

    if not Success then
        local list = Essential and "Essential" or "NonEssential"
        table.insert(ExecutorSupport.FailedChecks[list], name)
    end
end

-- Tests reales que hace Cobalt (con lógica de verificación):

-- hookfunction: verifica que realmente cambia el valor de retorno
test("hookfunction", function()
    local function Original(a, b) return a + b end
    local ref = hookfunction(Original, function(a, b) return a * b end)
    assert(Original(2, 3) == 6, "hook no cambió el retorno")  -- 2*3
    assert(ref(2, 3) == 5, "no retornó la función original")  -- 2+3
end)

-- newcclosure: verifica que debug.info retorna "[C]"
test("newcclosure", function()
    local cc = newcclosure(function() return true end)
    assert(cc() == true, "closure no funciona")
    assert(debug.info(cc, "s") == "[C]", "no es C closure")
end)

-- setstackhidden: oculta función del stack trace (non-essential)
test("setstackhidden", function()
    -- Cobalt lo usa para ocultar sus detours del stack
    -- Evita que el juego detecte funciones del executor en el traceback
    local hidden = function() return debug.info(2, "f") end
    setstackhidden(hidden, true)
    assert(hidden() ~= hidden, "no se ocultó del stack")
end, false, false)  -- false, false = no checkType, non-essential

-- oth (One-Thread Hooks): librería especial de algunos executores
-- Diferencia clave vs hookfunction: corre en thread SEPARADO
-- Esto evita que el juego detecte que está en el mismo callstack
test("oth", function()
    assert(oth ~= nil, "oth library not found")
    assert(hookfunction ~= oth.hook, "oth.hook no debe ser alias de hookfunction")
    assert(restorefunction ~= oth.unhook, "oth.unhook no debe ser alias de restorefunction")
    -- oth.is_hook_thread() → true si estás dentro del hook thread
    -- oth.get_original_thread() → retorna el thread que disparó el hook
end, false, false)

-- BrokenFeatures: executores con funciones rotas conocidas
local BrokenFeatures = {
    ["Volcano"] = { "oth", "run_on_actor" },
    ["Seliware"] = { "run_on_actor" },
}
-- Si el executor está en BrokenFeatures, el test falla automáticamente
-- sin ejecutar el callback (evita crashes)

-- Uso del ExecutorSupport en el código:
if ExecutorSupport["oth"].IsWorking then
    -- usar oth.hook (más seguro, thread separado)
elseif ExecutorSupport["hookfunction"].IsWorking then
    -- usar hookfunction normal
else
    -- fallback: rawset en metatable
end

## HOOKING.LUA — SISTEMA DE HOOKS UNIFICADO

-- Cobalt abstrae todos los métodos de hook en un módulo Hooking
-- para que el resto del código no tenga que preocuparse por compatibilidad

local Hooking = {}

Hooking.HookFunction = function(Original, Replacement)
    -- Prioridad 1: oth (thread separado, más seguro)
    if ExecutorSupport["oth"].IsWorking and iscclosure(Original) and islclosure(Replacement) then
        return oth.hook(Original, Replacement)
    end

    -- Siempre convertir a C closure antes de hookear
    -- Razón: algunos executores solo pueden hookear C closures
    if islclosure(Replacement) then
        Replacement = newcclosure(Replacement)
    end

    if not ExecutorSupport["hookfunction"].IsWorking then
        return Original  -- fallback silencioso
    end

    return hookfunction(Original, Replacement)
end

Hooking.HookMetaMethod = function(object, method, hook)
    local Metatable = getrawmetatable(object)
    local originalMethod = rawget(Metatable, method)

    -- Prioridad 1: oth
    if ExecutorSupport["oth"].IsWorking then
        return oth.hook(originalMethod, hook)
    end

    if islclosure(hook) then hook = newcclosure(hook) end

    -- Prioridad 2: hookmetamethod (si existe)
    if ExecutorSupport["hookmetamethod"].IsWorking then
        return hookmetamethod(object, method, hook)
    end

    -- Prioridad 3: setreadonly + rawset (alternativo)
    if ExecutorSupport["getrawmetatable"].IsWorking then
        setreadonly(Metatable, false)
        rawset(Metatable, method, hook)
        setreadonly(Metatable, true)
        return originalMethod
    end

    -- Prioridad 4: xpcall trick para obtener la función del metamétodo
    -- (cuando no hay hookmetamethod ni getrawmetatable)
    if method == "__namecall" then
        local _, Metamethod = xpcall(function()
            object:Mustard()  -- método inexistente → dispara __namecall
        end, function(err)
            return debug.info(2, "f")  -- captura la función del metamétodo
        end)
        return Metamethod
    end
end

## AWP EXECUTOR — CASO ESPECIAL newcclosure

-- El executor AWP tiene un bug: newcclosure no funciona correctamente
-- Cobalt lo detecta y usa un workaround con setfenv:

local newcclosure_fixed = ExecutorName == "AWP"
    and function(f, name)
        local env = getfenv(f)
        -- Crear tabla proxy que delega al entorno original
        local x = setmetatable({ __F = f }, {
            __index = env,
            __newindex = env,
        })
        local nf = function(...)
            return __F(...)  -- __F viene del entorno x via __index
        end
        setfenv(nf, x)  -- deoptimiza el entorno (necesario para el workaround)
        return newcclosure(nf, name)
    end
    or newcclosure

-- Por qué funciona: setfenv deoptimiza la función, haciendo que
-- el executor la trate diferente internamente

## ACTOR SUPPORT — HOOKS EN VMs PARALELAS

-- Roblox Actors corren en VMs Lua separadas
-- Los hooks del thread principal NO aplican en el VM del Actor
-- Cobalt resuelve esto con run_on_actor + create_comm_channel

-- Verificar si el juego usa Actors:
local GameUsesActors = false
for _, inst in game:QueryDescendants("Actor") do
    GameUsesActors = true
    break
end

-- Si el juego usa Actors Y el executor no soporta run_on_actor:
-- Cobalt ofrece un fix via setfflag("DebugRunParallelLuaOnMainThread", "true")
-- Esto fuerza a Roblox a correr los Actors en el thread principal
-- (requiere rejoin para aplicar)

-- Canal de comunicación Actor ↔ Main thread:
local CommunicationChannelID, Channel = create_comm_channel()
-- Channel es un BindableEvent especial que cruza VMs
-- Cobalt lo usa para sincronizar logs de Actors al UI principal

-- Serialización de datos entre VMs (los valores no cruzan directamente):
-- Funciones → se convierten a metadata (address, name, source, upvalues)
-- Instancias → se clonan con cloneref
-- Tablas cíclicas → se resuelven con IDs únicos (GenerateGUID)
"""

COBALT_SOURCE_2 = """
## REMOTE SPY — ARQUITECTURA DUAL

-- Cobalt intercepta remotes por DOS vías simultáneas:
-- 1. __namecall hook → :FireServer(), :InvokeServer(), :Fire(), :Invoke()
-- 2. hookfunction    → Event.FireServer(Event, ...) (llamada directa)

-- Truco: crear instancia temporal solo para capturar la función,
-- luego destruirla. La referencia a la función sigue siendo válida.
local FunctionsToHook
do
    local rf = Instance.new("RemoteFunction")
    local re = Instance.new("RemoteEvent")
    FunctionsToHook = { rf.InvokeServer, re.FireServer }
    rf:Destroy(); re:Destroy()
end

-- INCOMING via getconnections():
-- ForeignState=true → conexión del executor, ignorar
local function CreateConnectionFunction(Instance, Method)
    local fn = function(...)
        for _, conn in getconnections(Instance[Method]) do
            if conn.ForeignState then continue end
            local Origin = nil
            if conn.Thread and getscriptfromthread then
                Origin = getscriptfromthread(conn.Thread)
            end
            if not Origin and conn.Function then
                local s = rawget(getfenv(conn.Function), "script")
                if typeof(s) == "Instance" then Origin = s end
            end
            LogRemote(Instance, Method, conn.Function, {
                Arguments  = table.pack(...),
                Origin     = Origin,
                Function   = conn.Function,
                IsExecutor = conn.Function and isexecutorclosure(conn.Function) or false,
            })
        end
    end
    LogConnectionFunctions[fn] = true
    return fn
end

-- INCOMING via callback detour (RemoteFunction/BindableFunction):
local function CreateCallbackDetour(Instance, Method, Callback)
    local Detour = function(...)
        local Origin = getscriptfromthread and getscriptfromthread(coroutine.running())
        if not Origin then
            local s = rawget(getfenv(Callback), "script")
            if typeof(s) == "Instance" then Origin = s end
        end
        local caller = debug.info(2, "f")
        local IsExecutor = typeof(caller) == "function"
            and isexecutorclosure(caller) or isexecutorclosure(Callback)
        if LogRemote(Instance, Method, Callback, {
            Arguments=table.pack(...), Origin=Origin,
            Function=Callback, IsExecutor=IsExecutor,
        }) then return end
        return Callback(...)
    end
    if ExecutorSupport["setstackhidden"].IsWorking then
        setstackhidden(Detour, true)
    end
    return Detour
end

-- __newindex hook: intercepta asignación de nuevos callbacks post-inicio
NewIndexHook = Hooking.HookMetaMethod(game, "__newindex", function(...)
    local self, key, value = ...
    if typeof(self) == "Instance" and ClassesToHook[self.ClassName] then
        local Method = ClassesToHook[self.ClassName]
        local callable = typeof(value) == "function"
            or (getrawmetatable(value) and typeof(getrawmetatable(value).__call) == "function")
        if key == Method and callable then
            return NewIndexHook(self, key, CreateCallbackDetour(self, Method, value))
        end
    end
    return NewIndexHook(...)
end)

-- Signal __index hook: bloquear conexiones en remotes ya bloqueados
local SignalMetatable = getrawmetatable(Instance.new("Part").Touched)
Hooks[SignalMetatable.__index] = Hooking.HookFunction(SignalMetatable.__index,
function(...)
    local self, key = ...
    if not Unloaded and ConnectionKeys[key] then
        local Inst = SignalMapping[self]
        local Connect = Hooks[SignalMetatable.__index](...)
        if not Inst then return Connect end
        local Method = ClassesToHook[Inst.ClassName]
        return newcclosure(function(...)
            local Result = table.pack(Connect(...))
            local Log = Logs.Incoming[Inst]
            if Log and Log.Blocked then
                for _, conn in getconnections(Inst[Method]) do
                    if not conn.ForeignState then conn:Disable() end
                end
            end
            return table.unpack(Result, 1, Result.n)
        end, debug.info(Connect, "n"))
    end
    return Hooks[SignalMetatable.__index](...)
end)

## GETCALLINGFUNCTION — SUBIR EL STACK

-- BaseLevel=2 con oth, BaseLevel=4 sin oth (oth añade frames extra)
local function getcallingfunction()
    local base = ExecutorSupport["oth"].IsWorking and 2 or 4
    for i = base, 10 do
        local fn, src = debug.info(i, "fs")
        if not fn or not src then break end
        if src ~= "[C]" then return fn end
    end
    return debug.info(base, "f")
end

## LOG ANTI-SPAM + PLUGIN INTERCEPTORS

function Log:Call(RawInfo)
    local now = tick()
    table.insert(self.SpamHistory, now)
    for i = #self.SpamHistory, 1, -1 do
        if now - self.SpamHistory[i] > 1 then table.remove(self.SpamHistory, i) end
    end
    if #self.SpamHistory > 15 then
        if not self.Ignored then self:Ignore() end
        return
    end
    local Info = DeepClone(RawInfo)
    Info.CreationTime = tick()
    -- Plugin interceptors: retornar false cancela el log
    if PluginManager and PluginManager.HasInterceptors then
        for _, cb in PluginManager.Registry.Interceptors.Global[self.Type] or {} do
            local ok, res = pcall(cb, Info, self.Instance, self.Type)
            if ok and res == false then return end
        end
    end
    self.Calls[#self.Calls + 1] = Info
    if not Info.IsExecutor then table.insert(self.GameCalls, #self.Calls) end
    Communicator.Fire(Communicator, self.Instance, self.Type, #self.Calls)
end

## CODEGEN — GENERAR CÓDIGO PARA REPRODUCIR REMOTES

-- Outgoing:   Event:FireServer(arg1, arg2)
-- Incoming Connection:
--   for _, conn in getconnections(Event.OnClientEvent) do
--       local old; old = hookfunction(conn.Function, function(...) return old(...) end)
--   end
-- Incoming Callback:
--   local cb = getcallbackvalue(Event, "OnClientInvoke")
--   Event.OnClientInvoke = function(...) return cb(...) end
-- RF return value: hookmetamethod + hookfunction para capturar retorno

-- GetFullPath casos especiales:
-- LocalPlayer → game:GetService("Players").LocalPlayer
-- nil parent  → GetNil("Name", "DebugId") con función helper
-- duplicados  → :GetChildren()[index]
-- modos: Index, WaitForChild, FindFirstChild (configurable)

## LUAENCODE — SERIALIZACIÓN COMPLETA

-- NaN: string.pack(">n", value) para detectar variantes
-- Tablas cíclicas: (function(t) t.path = t.other return t end)({...})
-- Funciones: comentario con name, line, upvalues, hash
-- Todos los tipos Roblox: CFrame, Vector3, Color3, TweenInfo, Enum, etc.

## UNLOAD — LIMPIEZA COMPLETA

function Cobalt.Unload()
    for _, plugin in PluginManager.Registry.Plugins do
        for _, cb in plugin.UnloadCallbacks or {} do task.spawn(pcall, cb) end
    end
    for _, conn in Connections do conn:Disconnect() end
    if ExecutorSupport["oth"].IsWorking then
        pcall(oth.unhook, gameMetatable.__namecall)
        pcall(oth.unhook, gameMetatable.__newindex)
    elseif ExecutorSupport["restorefunction"].IsWorking and not AlternativeEnabled then
        pcall(restorefunction, gameMetatable.__namecall)
        pcall(restorefunction, gameMetatable.__newindex)
    else
        Hooking.HookMetaMethod(game, "__namecall", NamecallHook)
        Hooking.HookMetaMethod(game, "__newindex", NewIndexHook)
    end
    for fn, original in Hooks do
        if ExecutorSupport["oth"].IsWorking then task.spawn(pcall, oth.unhook, fn)
        elseif ExecutorSupport["restorefunction"].IsWorking then task.spawn(pcall, restorefunction, fn)
        else pcall(Hooking.HookFunction, fn, original) end
    end
    getgenv().CobaltInitialized = false
    getgenv().Cobalt = nil
    ScreenGui:Destroy()
    Communicator:Destroy()
end

## WAX RUNTIME — SISTEMA DE MÓDULOS

-- ClosureBindings[refId] = function() ... end
-- ObjectTree: árbol DOM virtual de ModuleScripts
-- ImportGlobals(refId) → retorna wax, script, require para cada módulo
-- wax.shared: tabla global compartida, table.freeze previene modificación
-- require() interno: cachea en StoredModuleValues, resuelve rutas relativas
-- LineOffsets[refId] → línea de inicio en el bundle para errores legibles
-- Defer(LoadScript, ref): ejecuta scripts con task.defer

## ADONIS BYPASS

-- Detectar: buscar threads con source ".Core.Anti" en getreg()
-- Bypass: coroutine.close(thread) + hookear funciones de detección
wax.shared.Hooks[DetectionFunc] = Hooking.HookFunction(DetectionFunc,
    function() coroutine.yield(); return task.wait(9e9) end)
-- filtergc("table", {Keys={"Detected","RLocked"}}) si disponible

## PLUGIN API

-- Cobalt.Spy:InterceptExecutedCalls(type, cb) → cancelar logs (retornar false)
-- Cobalt.Spy:AppendLog(inst, type, data)      → inyectar logs
-- Cobalt.CodeGen:InterceptGeneration(type, cb) → modificar código generado
-- Cobalt.UI.RemoteInfo:CreateTab(name, icon)  → añadir tabs
-- Cobalt.UI.ContextMenu:AddOption(...)        → añadir opciones al menú
-- Cobalt.UI:CreateModal(title, icon)          → ventana modal resizable
-- Cobalt.Settings (proxy)                     → leer/escribir settings
-- Cobalt:BindToUnload(cb)                     → cleanup al descargar
-- Game = "*" | "placeId" | {id1, id2}        → filtrar por juego
"""

COBALT_SOURCE_3 = """
## FILEHELPER — SISTEMA DE ARCHIVOS ROBUSTO

-- FileHelper abstrae writefile/readfile con rutas relativas y creación recursiva.
-- Normaliza separadores: \\ → / en todas las plataformas

local FileHelper = {}
FileHelper.__index = FileHelper

function FileHelper.new(basePath)
    local self = setmetatable({
        BasePath = FileHelper.NormalizePath(basePath)
    }, FileHelper)
    self:EnsureDirectory()  -- crea la carpeta si no existe
    return self
end

-- Crear directorios recursivamente (makefolder no crea padres automáticamente)
function FileHelper:EnsureDirectory()
    local parts = self.BasePath:split("/")
    for idx = 1, #parts do
        local path = table.concat(parts, "/", 1, idx)
        if not isfolder(path) then makefolder(path) end
    end
end

function FileHelper.NormalizePath(path)
    if type(path) ~= "string" then return "" end
    return path:gsub("\\", "/")  -- normalizar separadores
end

function FileHelper:GetPath(relativePath)
    local norm = self.NormalizePath(relativePath or "")
    if norm == "" then return self.BasePath end
    local sep = self.BasePath:sub(-1) == "/" and "" or "/"
    return self.BasePath .. sep .. norm
end

function FileHelper:GetRelativePath(path)
    path = self.NormalizePath(path)
    local base = self.NormalizePath(self.BasePath)
    if base:sub(-1) ~= "/" then base = base .. "/" end
    local s, e = path:find(base, 1, true)
    return s and path:sub(e + 1) or path
end

function FileHelper:EnsureFile(relativePath, default)
    if not isfile(self:GetPath(relativePath)) then
        writefile(self:GetPath(relativePath), default)
    end
end

function FileHelper:ReadFile(rel)   return readfile(self:GetPath(rel)) end
function FileHelper:WriteFile(rel, data) writefile(self:GetPath(rel), data) end
function FileHelper:DeleteFile(rel)
    if isfile(self:GetPath(rel)) then delfile(self:GetPath(rel)) end
end
function FileHelper:DeleteDirectory(rel)
    if isfolder(self:GetPath(rel)) then delfolder(self:GetPath(rel)) end
end
function FileHelper:ListFiles(rel)
    local files = {}
    for _, f in listfiles(self:GetPath(rel or "")) do
        table.insert(files, self:GetRelativePath(f))
    end
    return files
end
function FileHelper:GetFileName(rel)
    return self.NormalizePath(rel):match("[^/]+$")
end

-- Uso en Cobalt:
local PluginFiles = FileHelper.new("Cobalt/Plugins")
local Settings    = FileHelper.new("Cobalt")
Settings:EnsureFile("Settings.json", "{}")

## SAVEMANAGER — PERSISTENCIA CON SINCRONIZACIÓN DE ACTORS

local SaveManager = { State = {} }
local FileHelper  = FileHelperUtil.new("Cobalt")
FileHelper:EnsureFile("Settings.json", "{}")

-- Cargar settings al inicio
local ok, err = pcall(function()
    SaveManager.State = HttpService:JSONDecode(FileHelper:ReadFile("Settings.json"))
end)
if not ok then warn("Failed to load settings: " .. err) end

function SaveManager:SetState(key, value)
    self.State[key] = value
    -- Guardar a disco (pcall por si writefile falla)
    pcall(FileHelper.WriteFile, FileHelper, "Settings.json",
        HttpService:JSONEncode(self.State))
end

function SaveManager:GetState(key, default)
    if self.State[key] ~= nil then return self.State[key] end
    return default
end

-- Sincronización con Actor VMs:
-- Cuando el UI cambia un setting, lo envía al Actor:
ActorCommunicator:Fire("MainSettingsSync", key, value)
-- El Actor lo recibe y actualiza su wax.shared.Settings[key].Value

## FILELOG — LOGGER CON FORMATO ROBLOX

-- Formato: 2024-12-04T15:28:31.131Z,0.131060,ThreadId,LEVEL message
-- Igual al formato de logs de Roblox para consistencia

local Logger = {}
Logger.__index = Logger
Logger.LOG_LEVELS = { ERROR=1, WARNING=2, INFO=3, DEBUG=4 }

local startTime = tick()

-- Nombre de archivo único por servidor (basado en JobId):
function Logger:GenerateFileName()
    local jobNum = game.JobId:gsub("%D", "")  -- solo dígitos del JobId
    local ts = os.date("!%Y%m%d%H%M%S")
    -- Operación aritmética para ofuscar el JobId ligeramente
    return string.format("%s/%s_%s.log",
        self.logFileDirectory, jobNum * 1.7 // 1.8, ts)
end

function Logger.new(logFilePath, logLevel, overwrite)
    local self = setmetatable({
        logFilePath      = logFilePath,
        logFileDirectory = logFilePath:match("(.+)/"),
        logLevel         = logLevel or Logger.LOG_LEVELS.INFO,
        overwrite        = overwrite or false,
    }, Logger)
    -- Crear directorio recursivamente
    local folder = logFilePath:match("(.*[\\/])(.*)")
    if folder and not isfolder(folder) then
        -- crear recursivamente
        local current = ""
        for part in folder:gmatch("[^\\/]+") do
            current = current .. part
            if not isfolder(current) then makefolder(current) end
            current = current .. "/"
        end
    end
    if self.overwrite then pcall(writefile, self.logFilePath, "") end
    self:Info("Logger", "Logger initialized")
    return self
end

function Logger:Log(level, threadId, message)
    if level > self.logLevel then return end  -- filtrar por nivel
    local ts = string.format("%s%.3fZ",
        os.date("!%Y-%m-%dT%H:%M:%S"), tick() % 1)
    local elapsed = string.format("%.6f", tick() - startTime)
    local levelStr = ({[1]="ERROR",[2]="WARNING",[3]="INFO",[4]="DEBUG"})[level]
    local line = string.format("%s,%s,%s,%s %s\n",
        ts, elapsed, threadId, levelStr, message)
    pcall(appendfile, self.logFilePath, line)
end

function Logger:Info(tid, msg)    self:Log(3, tid, msg) end
function Logger:Warning(tid, msg) self:Log(2, tid, msg) end
function Logger:Error(tid, msg)   self:Log(1, tid, msg) end
function Logger:Debug(tid, msg)   self:Log(4, tid, msg) end

## PAGINATION — SISTEMA COMPLETO CON ELLIPSIS

local Pagination = {}
Pagination.__index = Pagination

function Pagination.new(opts)
    return setmetatable({
        TotalItems   = opts.TotalItems,
        ItemsPerPage = opts.ItemsPerPage,
        CurrentPage  = opts.CurrentPage or 1,
        SiblingCount = opts.SiblingCount or 2,
    }, Pagination)
end

function Pagination:GetIndexRanges(page)
    page = page or self.CurrentPage
    local total = math.ceil(self.TotalItems / self.ItemsPerPage)
    if total == 0 then return 1, 0 end
    assert(page <= total, "page out of range")
    local start = ((page - 1) * self.ItemsPerPage) + 1
    return start, start + self.ItemsPerPage - 1
end

-- GetVisualInfo: genera array de números y "ellipsis" para la UI
-- Ejemplo con 20 páginas, página 10, sibling=2:
-- {1, "ellipsis", 8, 9, 10, 11, 12, "ellipsis", 20}
function Pagination:GetVisualInfo(page)
    page = page or self.CurrentPage
    local total = math.ceil(self.TotalItems / self.ItemsPerPage)
    if total == 0 then return {} end
    local maxBtns = 5 + self.SiblingCount * 2
    -- Si caben todos los botones, mostrarlos todos
    if total <= maxBtns then
        local r = {}
        for i = 1, total do r[i] = i end
        return r
    end
    local left  = math.max(page - self.SiblingCount, 1)
    local right = math.min(page + self.SiblingCount, total)
    local fakeLeft  = left > 2
    local fakeRight = right < total - 1
    local itemCount = maxBtns - 2
    local result = table.create(maxBtns, "none")
    if not fakeLeft and fakeRight then
        for i = 1, itemCount do result[i] = i end
        result[itemCount+1] = "ellipsis"
        result[itemCount+2] = total
    elseif fakeLeft and not fakeRight then
        result[1] = 1; result[2] = "ellipsis"
        local idx = 3
        for i = total - itemCount + 1, total do result[idx] = i; idx += 1 end
    elseif fakeLeft and fakeRight then
        result[1] = 1; result[2] = "ellipsis"
        local idx = 3
        for i = left, right do result[idx] = i; idx += 1 end
        result[idx] = "ellipsis"; result[idx+1] = total
    end
    return result
end

## SONNER — SISTEMA DE NOTIFICACIONES (PORT DE SONNER.JS)

-- Port de https://sonner.emilkowal.ski/ para Luau
-- Cola de notificaciones con animaciones y apilamiento visual

local Sonner = {
    Queue       = {},   -- notificaciones activas
    PendingQueue = {},  -- cola de espera
    Processing  = false,
}

-- Apilamiento visual: cada nueva notif empuja las anteriores hacia arriba
-- y las escala hacia abajo (efecto de profundidad)
local function InternalToast(image, text, time, removeCallback)
    local Notif = CreateNotificationObject(image, text)
    table.insert(Sonner.Queue, Notif)

    local ScaleMultiplier = 0.9
    for i, obj in Sonner.Queue do
        if obj == Notif then continue end
        -- Escalar hacia abajo las notifs anteriores
        TweenService:Create(obj.UIScale, TweenInfo, {
            Scale = obj.UIScale.Scale * ScaleMultiplier
        }):Play()
        -- Mover hacia arriba
        TweenService:Create(obj, TweenInfo, {
            Position = obj.Position - UDim2.fromOffset(0, obj.AbsoluteSize.Y * 0.35)
        }):Play()
        -- Ocultar si hay más de 3
        if (#Sonner.Queue - i + 1) >= 4 then
            Animations.FadeOut(obj)
            task.delay(0.5, function() obj:Destroy() end)
        end
    end

    -- Animar entrada desde abajo
    TweenService:Create(Notif, TweenInfo, {
        Position = UDim2.new(0.5, 0, 1, -20)
    }):Play()
    Animations.FadeIn(Notif)

    -- Auto-remover después de `time` segundos
    task.delay(time or 4.5, function()
        if not table.find(Sonner.Queue, Notif) then return end
        table.remove(Sonner.Queue, table.find(Sonner.Queue, Notif))
        Animations.FadeOut(Notif, 0.35)
        TweenService:Create(Notif, TweenInfo, {
            Position = UDim2.new(0.5, 0, 1, 50)
        }):Play()
        task.wait(0.5)
        Notif:Destroy()
    end)
end

-- Cola para evitar solapamiento de animaciones
local function ProcessQueue()
    if Sonner.Processing then return end
    Sonner.Processing = true
    while #Sonner.PendingQueue > 0 do
        local req = table.remove(Sonner.PendingQueue, 1)
        InternalToast(req.image, req.text, req.time, req.removeCallback)
        task.wait(0.5)  -- esperar entre notificaciones
    end
    Sonner.Processing = false
end

-- Sonner.promise: notificación con estado loading → success/error
-- Muestra spinner animado mientras la función corre
function Sonner.promise(func, opts)
    local loadingText = opts.loadingText or "Loading..."
    local successText = opts.successText or "Success!"
    local errorText   = opts.errorText   or "Error!"

    InternalToast("loader-circle", loadingText, opts.time, function(notif, time)
        -- Animar spinner en RenderStepped
        local spinThread = task.spawn(function()
            repeat
                RunService.RenderStepped:Wait()
                local icon = notif:FindFirstChild("ImageLabel")
                if icon then icon.Rotation = (icon.Rotation + 1) % 360 end
            until false
        end)

        local ok, result = pcall(func, function(text)
            notif.Frame.TextLabel.Text = text  -- actualizar texto en tiempo real
        end)

        coroutine.close(spinThread)

        -- Cambiar icono según resultado
        if ok then
            Icons.SetIcon(notif.ImageLabel, "check")
            notif.Frame.TextLabel.Text = typeof(successText) == "function"
                and successText(result) or successText
        else
            Icons.SetIcon(notif.ImageLabel, "circle-alert")
            notif.Frame.TextLabel.Text = typeof(errorText) == "function"
                and errorText(result) or errorText
        end

        task.delay(time, function()
            -- remover notificación
        end)
    end)
end

-- API pública:
-- Sonner.info(text, time)
-- Sonner.success(text, time)
-- Sonner.warning(text, time)
-- Sonner.error(text, time)
-- Sonner.toast(text, time)       -- sin icono
-- Sonner.promise(func, opts)     -- con estado loading/success/error
-- Sonner.rawtoast({image, text, time})

## SYNTAX HIGHLIGHTER — COLOREADO DE CÓDIGO LUAU

-- Tokenizador simple que colorea código Luau con RichText
-- Colores basados en el tema de Roblox Studio

local Colors = {
    Keyword  = "#f86d7c",  -- and, break, if, then, end, local, return...
    String   = "#adf195",  -- "texto"
    Number   = "#ffc600",  -- 42, 3.14
    Boolean  = "#ffc600",  -- true, false
    Nil      = "#ffc600",  -- nil
    BuiltIn  = "#84d6f7",  -- print, pairs, game, workspace...
    Comment  = "#666666",  -- -- comentario
    LocalMethod   = "#fdfbac",  -- func()
    LocalProperty = "#61a1f1",  -- obj.property
    Text     = "#ffffff",  -- todo lo demás
}

-- Algoritmo de tokenización:
-- 1. Detectar strings (", ') y comentarios (--)
-- 2. Detectar puntuación como separadores de tokens
-- 3. Para cada token, determinar color según contexto:
--    - token seguido de "(" → LocalMethod
--    - token precedido de "." → LocalProperty
--    - token en LuaKeywords → Keyword
--    - token en RobloxGlobals o getgenv()[token] → BuiltIn
--    - tonumber(token) → Number

-- GetArgumentColor: color para argumentos en el panel de Cobalt
local ArgumentColors = {
    boolean = "#ffc600",
    number  = "#ffc600",
    Vector2 = "#ffc600",
    Vector3 = "#ffc600",
    CFrame  = "#ffc600",
    string  = "#adf195",
    EnumItem = "#84d6f7",
    ["nil"] = "#ffc600",
}
function Highlighter.GetArgumentColor(arg)
    return ArgumentColors[typeof(arg)] or "#ffffff"
end

## ANIMATIONS — FADE IN/OUT RECURSIVO

-- Cobalt anima transparencia de forma recursiva en todos los descendientes
-- Soporta: TextButton, TextLabel, TextBox, Frame, ScrollingFrame,
--          ImageLabel, ImageButton, UIStroke, CanvasGroup

local function GetTransparencyProperty(obj)
    if obj:IsA("TextButton") or obj:IsA("TextLabel") or obj:IsA("TextBox") then
        return {"TextTransparency"}
    elseif obj:IsA("CanvasGroup") then
        return {"GroupTransparency"}  -- CanvasGroup usa GroupTransparency
    elseif obj:IsA("Frame") then
        return {"BackgroundTransparency"}
    elseif obj:IsA("ImageLabel") or obj:IsA("ImageButton") then
        return {"ImageTransparency", "BackgroundTransparency"}
    elseif obj:IsA("UIStroke") then
        return {"Transparency"}
    end
    return nil
end

-- FadeOut/FadeIn: anima hacia 1/0 con TweenService
-- Si es CanvasGroup, NO anima descendientes (GroupTransparency los cubre todos)
-- SetFadeExpectation: permite override del valor target por objeto

## RESIZE — SISTEMA DE REDIMENSIONADO

-- Cobalt implementa resize con 8 handles: 4 lados + 4 esquinas
-- Soporta modo Mirrored (redimensiona desde el centro) y normal
-- MinimumSize y MaximumSize en UDim2 o Vector2
-- LockedPosition: la ventana no se mueve al redimensionar (para modales)

-- Modo Mirrored (ventanas centradas):
-- Al arrastrar el borde derecho, el izquierdo se mueve simétricamente
-- Delta se multiplica por 2 para mantener el centro fijo

-- Modo normal (ventanas con posición libre):
-- Calcula el nuevo centro basado en el borde que se mueve
-- Actualiza Position y Size simultáneamente

-- DPI Scale: todos los deltas se dividen por GetDPIScale()
-- para que el resize funcione correctamente con UIScale

## DRAG — SISTEMA DE ARRASTRE

function Drag.Setup(Frame, DragFrame, Callback)
    DragFrame.InputBegan:Connect(function(Input)
        if not IsClickInput(Input) then return end
        Drag.Dragging    = true
        Drag.Frame       = Frame
        Drag.FramePosition = Frame.Position
        Drag.StartPosition = Input.Position
        Drag.FrameSize   = Frame.Size
        Drag.Callback    = Callback or DefaultCallback

        Input.Changed:Connect(function()
            if Input.UserInputState == Enum.UserInputState.End then
                Drag.Dragging = false
                Drag.Frame    = nil
                Drag.Callback = nil
            end
        end)
    end)
end

-- DefaultCallback: mueve el frame según el delta del mouse
-- Delta se divide por DPIScale para consistencia con UIScale
local function DefaultCallback(_, Input)
    local Delta = (Input.Position - Drag.StartPosition)
    if GetDPIScale then Delta = Delta / GetDPIScale() end
    Drag.Frame.Position = UDim2.new(
        Drag.FramePosition.X.Scale,
        Drag.FramePosition.X.Offset + Delta.X,
        Drag.FramePosition.Y.Scale,
        Drag.FramePosition.Y.Offset + Delta.Y
    )
end

## INTERFACE — FACTORY DE UI CON DEFAULTS

-- Interface.New aplica propiedades default por ClassName
-- y permite anidar instancias como tablas en Properties

local DefaultProperties = {
    Frame          = { BorderSizePixel = 0 },
    TextLabel      = { BackgroundTransparency=1, BorderSizePixel=0,
                       FontFace=DefaultFont, RichText=true,
                       TextColor3=Color3.new(1,1,1) },
    TextButton     = { AutoButtonColor=false, BorderSizePixel=0,
                       FontFace=DefaultFont, RichText=true,
                       TextColor3=Color3.new(1,1,1) },
    UIListLayout   = { SortOrder=Enum.SortOrder.LayoutOrder },
}

function Interface.New(ClassName, Properties)
    local obj = Instance.new(ClassName)
    -- Aplicar defaults primero
    for k, v in DefaultProperties[ClassName] or {} do
        if not (Properties and Properties[k] ~= nil) then
            obj[k] = v
        end
    end
    -- Aplicar propiedades del usuario
    for k, v in Properties or {} do
        if typeof(v) == "table" then
            -- Tabla anidada = instancia hija
            local child = Interface.New(k, v)
            child.Parent = obj
        elseif typeof(k) ~= "string" and typeof(v) == "Instance" then
            v:Clone().Parent = obj
        else
            obj[k] = v
        end
    end
    return obj
end

-- DefaultFont: Inter cargado via getcustomasset
-- Fallback a FontId 12187365364 si getcustomasset no disponible
-- AssetManager.GetCustomFont descarga el TTF, crea .font JSON y lo carga

## SESSION EXPORTER — EXPORTAR A HTML

-- Cobalt puede exportar toda la sesión de spy a un archivo HTML interactivo
-- con timeline, heatmap, filtros y panel de detalles

-- StringMapper: deduplicación de strings para reducir tamaño del JSON
-- Cada string único recibe un ID numérico
-- El HTML recibe events[] (con IDs) + dictionary{} (ID→string)

-- Procesamiento:
-- 1. FetchAllLogs(): recopilar todos los calls de todos los logs
-- 2. SortCalls(): ordenar por CreationTime
-- 3. ProcessCalls(): serializar cada call con StringMapper
-- 4. ExportSessionToHTML(): reemplazar placeholders en template HTML

-- El HTML incluye:
-- - Timeline virtual scroll (renderiza solo filas visibles)
-- - Heatmap canvas con zoom
-- - Panel de detalles con syntax highlighting
-- - Filtros por tipo, actor, tiempo, args, hash, source
-- - Ctrl+F para buscar
-- - Copiar código, path, args con un click

## SIGNAL — IMPLEMENTACIÓN PROPIA DE EVENTOS

-- Cobalt implementa su propio sistema de señales para uso interno
-- (no depende de BindableEvent para comunicación interna)

local Signal = {}
Signal.__index = Signal

function Signal:Connect(callback)
    local conn = {
        Connected = true, Enabled = true, Callback = callback,
        Disconnect = function(self) self.Connected = false end,
        Enable     = function(self) self.Enabled = true end,
        Disable    = function(self) self.Enabled = false end,
    }
    table.insert(self.Connections, conn)
    return conn
end

function Signal:Once(callback)
    local conn
    conn = self:Connect(function(...)
        conn:Disconnect()
        callback(...)
    end)
    return conn
end

function Signal:Fire(...)
    for _, conn in self.Connections do
        if conn.Connected and conn.Enabled then
            task.spawn(conn.Callback, ...)
        end
    end
end

function Signal:Wait()
    local data, done = {}, false
    self:Once(function(...) data = {...}; done = true end)
    repeat task.wait() until done
    return table.unpack(data)
end
"""

LUAU_EDUCATIONAL_SCRIPTS = """
## ESP (Extra Sensory Perception) — CÓMO FUNCIONA
-- Principio: crear BillboardGui sobre cada personaje para verlos a través de paredes.
-- Técnica estándar de aprendizaje de UI 3D en Roblox.

local function createESP(character, color)
    -- Limpiar ESP anterior si existe
    local existing = character:FindFirstChild("_ESP")
    if existing then existing:Destroy() end

    local root = character:FindFirstChild("HumanoidRootPart")
    if not root then return end

    local bb = Instance.new("BillboardGui")
    bb.Name          = "_ESP"
    bb.Adornee       = root
    bb.Size          = UDim2.new(0, 100, 0, 40)
    bb.StudsOffset   = Vector3.new(0, 3, 0)
    bb.AlwaysOnTop   = true   -- <-- esto es lo que "atraviesa paredes"
    bb.Parent        = character

    local label = Instance.new("TextLabel", bb)
    label.Size            = UDim2.new(1, 0, 1, 0)
    label.BackgroundTransparency = 1
    label.TextColor3      = color or Color3.fromRGB(255, 80, 80)
    label.TextStrokeTransparency = 0
    label.Font            = Enum.Font.GothamBold
    label.TextScaled      = true
    label.Text            = character.Name

    return bb
end

-- Aplicar a todos los jugadores (excepto el local):
local Players = game:GetService("Players")
local localPlayer = Players.LocalPlayer

local function onCharacterAdded(player, char)
    if player == localPlayer then return end
    char:WaitForChild("HumanoidRootPart", 5)
    createESP(char, Color3.fromRGB(255, 50, 50))
end

for _, player in ipairs(Players:GetPlayers()) do
    if player ~= localPlayer and player.Character then
        onCharacterAdded(player, player.Character)
    end
    player.CharacterAdded:Connect(function(char)
        onCharacterAdded(player, char)
    end)
end

Players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function(char)
        onCharacterAdded(player, char)
    end)
end)

-- LIMPIAR todo:
local function removeAllESP()
    for _, player in ipairs(Players:GetPlayers()) do
        if player.Character then
            local esp = player.Character:FindFirstChild("_ESP")
            if esp then esp:Destroy() end
        end
    end
end

--------------------------------------------------------------------------------

## REMOTE SPY — CÓMO FUNCIONA (educativo)
-- Principio: hookear __namecall para interceptar llamadas a RemoteEvent/Function.
-- Enseña cómo los executores observan la comunicación cliente-servidor.

-- NOTA: requiere executor con getrawmetatable y hookmetamethod.
-- En Studio esto NO funciona; es específico de entorno executor.

--[[
local mt = getrawmetatable(game)
local oldNamecall = mt.__namecall

-- makereadonly(mt, false)  -- algunos executores requieren esto

mt.__namecall = newcclosure(function(self, ...)
    local method = getnamecallmethod()
    local args   = {...}

    -- Solo interceptar RemoteEvent:FireServer y RemoteFunction:InvokeServer
    if (method == "FireServer" or method == "InvokeServer") then
        local name = self:GetFullName()
        print(string.format("[RemoteSpy] %s:%s(%s)",
            name, method,
            table.concat(
                (function()
                    local strs = {}
                    for _, v in ipairs(args) do
                        strs[#strs+1] = tostring(v)
                    end
                    return strs
                end)(),
                ", "
            )
        ))
    end

    return oldNamecall(self, ...)
end)
--]]
-- El patrón clave: guardar la función original y llamarla al final (no romper el juego).

--------------------------------------------------------------------------------

## AIMBOT — MATEMÁTICAS PURAS (educativo)
-- Principio: calcular el ángulo de la cámara para apuntar a un punto en el mundo.
-- Esto es geometría 3D básica, no depende de ningún executor.

local function getAnglesToTarget(targetPosition)
    local camera   = workspace.CurrentCamera
    local camCF    = camera.CFrame
    -- Vector desde la cámara al objetivo en espacio local de la cámara
    local localPos = camCF:PointToObjectSpace(targetPosition)
    -- Ángulos esféricos
    local pitch = math.atan2(-localPos.Y, math.sqrt(localPos.X^2 + localPos.Z^2))
    local yaw   = math.atan2(-localPos.X, -localPos.Z)
    return pitch, yaw
end

-- Para apuntar suavemente (lerp de CFrame):
local function softAim(targetCF, alpha)
    alpha = math.clamp(alpha or 0.15, 0, 1)
    workspace.CurrentCamera.CFrame = workspace.CurrentCamera.CFrame:Lerp(targetCF, alpha)
end

-- Encontrar el jugador más cercano al centro de pantalla (FOV check):
local function getNearestTarget(fovRadius)
    fovRadius = fovRadius or 150  -- píxeles
    local camera    = workspace.CurrentCamera
    local center    = Vector2.new(camera.ViewportSize.X/2, camera.ViewportSize.Y/2)
    local Players   = game:GetService("Players")
    local localChar = Players.LocalPlayer.Character

    local best, bestDist = nil, fovRadius

    for _, player in ipairs(Players:GetPlayers()) do
        if player.Character and player.Character ~= localChar then
            local root = player.Character:FindFirstChild("HumanoidRootPart")
            local hum  = player.Character:FindFirstChildOfClass("Humanoid")
            if root and hum and hum.Health > 0 then
                -- Proyectar posición 3D a pantalla 2D
                local screenPos, onScreen = camera:WorldToViewportPoint(root.Position)
                if onScreen then
                    local dist2D = (Vector2.new(screenPos.X, screenPos.Y) - center).Magnitude
                    if dist2D < bestDist then
                        bestDist = dist2D
                        best     = player
                    end
                end
            end
        end
    end
    return best
end

--------------------------------------------------------------------------------

## SPEED / JUMP HACK — MODIFICAR HUMANOID (educativo)
-- Principio: las propiedades del Humanoid son accesibles desde el cliente.
-- El servidor puede o no validarlas dependiendo del juego.

local Players  = game:GetService("Players")
local localHum = Players.LocalPlayer.Character
                 and Players.LocalPlayer.Character:FindFirstChildOfClass("Humanoid")

local ORIGINAL_SPEED = localHum and localHum.WalkSpeed or 16
local ORIGINAL_JUMP  = localHum and localHum.JumpPower  or 50

local function setSpeed(speed)
    local char = Players.LocalPlayer.Character
    local hum  = char and char:FindFirstChildOfClass("Humanoid")
    if hum then hum.WalkSpeed = speed end
end

local function setJump(power)
    local char = Players.LocalPlayer.Character
    local hum  = char and char:FindFirstChildOfClass("Humanoid")
    if hum then hum.JumpPower = power end
end

local function resetMovement()
    setSpeed(ORIGINAL_SPEED)
    setJump(ORIGINAL_JUMP)
end

-- Reconectar al respawn:
Players.LocalPlayer.CharacterAdded:Connect(function(char)
    char:WaitForChild("Humanoid")
    -- Aquí podrías re-aplicar si tienes un toggle activo
end)

--------------------------------------------------------------------------------

## NOCLIP — CÓMO FUNCIONA (educativo)
-- Principio: desactivar CanCollide en todas las partes del personaje cada frame.

local RunService = game:GetService("RunService")
local noclipConn = nil

local function enableNoclip()
    if noclipConn then return end  -- ya activo
    noclipConn = RunService.Stepped:Connect(function()
        local char = Players.LocalPlayer.Character
        if not char then return end
        for _, part in ipairs(char:GetDescendants()) do
            if part:IsA("BasePart") then
                part.CanCollide = false
            end
        end
    end)
end

local function disableNoclip()
    if noclipConn then
        noclipConn:Disconnect()
        noclipConn = nil
    end
    -- Restaurar colisión
    local char = Players.LocalPlayer.Character
    if char then
        for _, part in ipairs(char:GetDescendants()) do
            if part:IsA("BasePart") then
                part.CanCollide = true
            end
        end
    end
end

--------------------------------------------------------------------------------

## INFINITE JUMP (educativo)
-- Principio: detectar el estado del Humanoid y forzar el salto.

local UIS = game:GetService("UserInputService")
local ijConn = nil

local function enableInfiniteJump()
    if ijConn then return end
    ijConn = UIS.JumpRequest:Connect(function()
        local char = Players.LocalPlayer.Character
        local hum  = char and char:FindFirstChildOfClass("Humanoid")
        if hum then
            hum:ChangeState(Enum.HumanoidStateType.Jumping)
        end
    end)
end

local function disableInfiniteJump()
    if ijConn then ijConn:Disconnect() ijConn = nil end
end

--------------------------------------------------------------------------------

## HOOKFUNCTION — CÓMO FUNCIONA (educativo)
-- Principio: reemplazar una función por otra que ejecuta lógica extra
-- y luego llama a la original. Patrón "wrapper" / "decorator".

-- En Lua puro (sin executor), el mismo patrón:
local originalPrint = print
print = function(...)
    -- lógica extra antes
    io.write("[HOOK] ")
    -- llamar original
    return originalPrint(...)
end

print("hola")  -- imprime: [HOOK] hola

-- Restaurar:
print = originalPrint

-- En executor con hookfunction:
--[[
local originalFireServer
originalFireServer = hookfunction(
    game.ReplicatedStorage.SomeRemote.FireServer,
    newcclosure(function(self, ...)
        print("[Hook] FireServer args:", ...)
        return originalFireServer(self, ...)  -- no romper el juego
    end)
)
--]]
"""

# ══════════════════════════════════════════════════════════════════
# P) COBALT — ANÁLISIS REAL DEL CÓDIGO FUENTE (educativo)
#    Fuente: github.com/notpoiu/cobalt
#    Autores: deivid, upio | 12,155 líneas | WAX bundler
# ══════════════════════════════════════════════════════════════════
COBALT_CORE_KB = """
## COBALT — QUÉ ES (contexto educativo)
Cobalt es un network monitor para Roblox: intercepta y loggea todo el tráfico
de RemoteEvent, RemoteFunction, BindableEvent y BindableFunction en tiempo real.
Está escrito en Luau, usa el bundler WAX, y es la implementación Luau más
completa de hooking de red disponible públicamente como referencia educativa.


────────────────────────────────────────────────────────────────────
## MÓDULO 1 — WAX BUNDLER: SISTEMA DE DEPENDENCIAS
────────────────────────────────────────────────────────────────────

WAX es un bundler que compila múltiples ModuleScripts en un solo archivo.
Cada módulo recibe 3 parámetros inyectados automáticamente:

    function(wax, script, require)
        -- wax.shared → tabla global compartida entre todos los módulos
        -- script     → referencia al módulo actual
        -- require    → carga otros módulos del bundle
    end

PATRÓN DE INICIALIZACIÓN REAL DE COBALT:
    wax.shared.CobaltStartTime = tick()

    -- Clonar servicios con cloneref ANTES de cualquier uso
    -- Razón: cloneref() devuelve una referencia limpia del servicio
    -- que no puede ser detectada ni modificada por el juego
    for _, Service in pairs({
        "ContentProvider", "CoreGui", "TweenService", "Players",
        "RunService", "HttpService", "UserInputService",
        "TextService", "StarterGui",
    }) do
        wax.shared[Service] = cloneref(game:GetService(Service))
    end

    -- Token de verificación único por sesión (previene replay attacks)
    wax.shared.CobaltVerificationToken = wax.shared.HttpService:GenerateGUID()

POR QUÉ cloneref() ES CRÍTICO:
    -- Sin cloneref: el juego puede hookear game:GetService y detectar accesos
    -- Con cloneref: obtienes una referencia independiente del servicio
    -- Cobalt almacena TODOS los servicios en wax.shared al inicio
    -- Acceso posterior: wax.shared.Players (nunca game:GetService("Players") de nuevo)

    -- Patrón educativo equivalente en Lua estándar:
    local Players = cloneref(game:GetService("Players"))  -- referencia protegida
    -- En vez de: local Players = game:GetService("Players")  -- hookeable


────────────────────────────────────────────────────────────────────
## MÓDULO 2 — EXECUTORSUPPORT: VERIFICACIÓN DE CAPACIDADES
────────────────────────────────────────────────────────────────────

Cobalt NUNCA asume que una función del executor existe. Verifica todo antes.
Esta es la arquitectura más robusta para código cross-executor.

ESTRUCTURA DEL SISTEMA DE TESTS:

    -- Executores con bugs conocidos (hardcoded):
    local BrokenFeatures = {
        ["Volcano"]  = { "oth", "run_on_actor" },
        ["Seliware"] = { "run_on_actor" },
    }

    -- Función de test con 4 parámetros:
    -- name      → nombre de la función a testear
    -- Callback  → función de test real (o la función misma si CheckType=true)
    -- CheckType → true = solo verifica typeof == "function" (test superficial)
    --             false = ejecuta el callback como test real (test profundo)
    -- Essential → true = si falla, se agrega a FailedChecks.Essential
    --             false = fallo no bloquea funcionalidad core

    local function test(name, Callback, CheckType, Essential)
        -- Si el executor tiene este feature marcado como broken: fail directo
        if BrokenFeatures[wax.shared.ExecutorName] and
           table.find(BrokenFeatures[wax.shared.ExecutorName], name) then
            ExecutorSupport[name] = { IsWorking = false, Essential = Essential }
            return
        end
        local TestFunction = not CheckType and Callback or function()
            assert(typeof(Callback) == "function", name .. " is not a function")
        end
        local Success, Result = pcall(TestFunction)
        ExecutorSupport[name] = {
            IsWorking = Success,
            Details   = Result,
            Essential = Essential,
        }
        if not Success then
            local list = Essential and "Essential" or "NonEssential"
            table.insert(ExecutorSupport.FailedChecks[list], name)
        end
    end

TESTS REALES QUE HACE COBALT (con su lógica interna):

    -- hookfunction: verifica que REALMENTE cambia el retorno Y devuelve la original
    test("hookfunction", function()
        local function Original(a, b) return a + b end
        local ref = hookfunction(Original, function(a, b) return a * b end)
        assert(Original(2, 3) == 6, "hook debe cambiar retorno (2*3=6)")
        assert(ref(2, 3) == 5,      "debe devolver original (2+3=5)")
    end)

    -- newcclosure: verifica que debug.info retorna "[C]" (es C closure real)
    test("newcclosure", function()
        local cc = newcclosure(function() return true end)
        assert(cc() == true)
        assert(debug.info(cc, "s") == "[C]", "debe ser C closure")
    end)

    -- setstackhidden: verifica ocultación en debug.info, debug.traceback,
    --                 getfenv Y error level traceback (4 métodos distintos)
    test("setstackhidden", function()
        -- Crea función via loadstring para testear ocultación real:
        local CallerFunction = loadstring([[
            local StackCheck = ...
            local function CallerFunction()
                return StackCheck[1]()
            end
            return CallerFunction
        ]])(StackCheck)
        setstackhidden(CallerFunction, true)
        -- Test 1: debug.info no debe ver la función
        -- Test 2: debug.traceback no debe mencionar "CallerFunction"
        -- Test 3: getfenv no debe devolver el env de la función
        -- Test 4: error con level no debe incluirla en el traceback
    end, false, false)  -- non-essential

    -- oth (One-Thread Hooks): verifica thread separado Y que NO es alias de hookfunction
    test("oth", function()
        assert(oth ~= nil)
        assert(hookfunction ~= oth.hook,      "oth.hook NO debe ser alias de hookfunction")
        assert(restorefunction ~= oth.unhook, "oth.unhook NO debe ser alias de restorefunction")
        -- Test real con VirtualInputManager para verificar thread separado:
        local VIM = Instance.new("VirtualInputManager")
        local Origin = coroutine.running()
        local Working = nil
        local Old
        Old = oth.hook(VIM.SendGravityEvent, function(...)
            if Working == nil then
                Working = (Origin ~= coroutine.running()  -- thread diferente
                    and oth.is_hook_thread()               -- es hook thread
                    and oth.get_original_thread() == Origin) -- origen correcto
                return
            end
            return Old(...)
        end)
        pcall(VIM.SendGravityEvent, VIM, 0, 0, 0)
        repeat task.wait() until Working ~= nil
        oth.unhook(VIM.SendGravityEvent, Old)
        VIM:Destroy()
        assert(Working)
    end, false, false)  -- non-essential

    -- Uso posterior (patrón correcto):
    if wax.shared.ExecutorSupport["hookfunction"].IsWorking then
        -- hacer hookfunction
    end
    -- NUNCA hacer: hookfunction(...)  -- sin verificar primero


────────────────────────────────────────────────────────────────────
## MÓDULO 3 — HOOKING: SISTEMA DE HOOKS CON PRIORIDAD
────────────────────────────────────────────────────────────────────

Cobalt implementa hooking con cascada de fallbacks. Siempre intenta el método
más seguro primero y baja al menos seguro solo si no hay otra opción.

HOOKFUNCTION CON PRIORIDAD (código real):

    Hooking.HookFunction = function(Original, Replacement)
        -- PRIORIDAD 1: oth (One-Thread Hook) — más seguro, thread separado
        -- Solo si: oth disponible, Original es C closure, Replacement es L closure
        if wax.shared.ExecutorSupport["oth"].IsWorking
        and iscclosure(Original) and islclosure(Replacement) then
            return oth.hook(Original, Replacement)
        end

        -- PRIORIDAD 2: hookfunction clásico
        -- Siempre convertir Replacement a C closure antes de hookear
        if islclosure(Replacement) then
            Replacement = wax.shared.newcclosure(Replacement)
        end
        if not wax.shared.ExecutorSupport["hookfunction"].IsWorking then
            return Original  -- fallback silencioso, no crashea
        end
        return hookfunction(Original, Replacement)
    end

HOOKMETAMETHOD CON 4 NIVELES DE FALLBACK (código real):

    Hooking.HookMetaMethod = function(object, method, hook)
        local Metatable = wax.shared.getrawmetatable(object)
        local originalMethod = rawget(Metatable, method)

        -- PRIORIDAD 1: oth
        if wax.shared.ExecutorSupport["oth"].IsWorking then
            return oth.hook(originalMethod, hook)
        end

        if islclosure(hook) then hook = wax.shared.newcclosure(hook) end

        -- PRIORIDAD 2: hookmetamethod (si está disponible y no hay modo alternativo)
        -- PRIORIDAD 3: setreadonly + rawset (modo alternativo)
        if AlternativeEnabled
        or (not wax.shared.ExecutorSupport["hookmetamethod"].IsWorking
            and wax.shared.ExecutorSupport["getrawmetatable"].IsWorking) then
            setreadonly(Metatable, false)
            rawset(Metatable, method, hook)
            setreadonly(Metatable, true)
            return originalMethod
        end

        -- PRIORIDAD 4: xpcall trick — obtener metamétodo sin hookmetamethod
        -- Dispara el metamétodo intencionalmente y captura la función via debug.info
        if not wax.shared.ExecutorSupport["hookmetamethod"].IsWorking then
            if method == "__namecall" then
                local _, fn = xpcall(
                    function() object:Mustard() end,  -- método inexistente → dispara __namecall
                    function() return debug.info(2, "f") end
                )
                return fn
            elseif method == "__newindex" then
                local _, fn = xpcall(
                    function() object[tostring(math.random())] = true end,
                    function() return debug.info(2, "f") end
                )
                return fn
            end
            return nil
        end

        return hookmetamethod(object, method, hook)
    end

LECCIÓN CLAVE: xpcall trick para obtener metamétodos sin hookmetamethod:
    -- Cuando hookmetamethod no existe, puedes disparar el metamétodo
    -- intencionalmente dentro de xpcall y capturarlo con debug.info(2, "f")
    -- Este es uno de los patrones más avanzados de Lua/Luau


────────────────────────────────────────────────────────────────────
## MÓDULO 4 — REMOTE SPY: INTERCEPCIÓN DUAL DE RED
────────────────────────────────────────────────────────────────────

Cobalt usa DOS métodos simultáneos para no perder ninguna llamada:

MÉTODO 1 — __namecall hook (llama via :Método())
    -- Intercepta: remote:FireServer(), remote:InvokeServer(), etc.
    wax.shared.NamecallHook = Hooking.HookMetaMethod(game, "__namecall", function(...)
        local self = ...
        local Method = getnamecallmethod()  -- "FireServer", "InvokeServer", etc.

        if typeof(self) == "Instance"
        and AllowedClassNames[self.ClassName]     -- RemoteEvent, RemoteFunction, etc.
        and NamecallMethods[Method]               -- FireServer, InvokeServer, Fire, Invoke
        and not rawequal(self, wax.shared.Communicator)  -- no loggear el propio Cobalt
        and not wax.shared.ShouldIgnore(self, getcallingscript())
        then
            local Log = wax.shared.Logs.Outgoing[self]
            if not Log then
                Log = wax.shared.NewLog(self, "Outgoing", Method, getcallingscript())
            end
            if Log.Blocked then return end  -- bloquear la llamada
            if not Log.Ignored then
                Log:Call({
                    Arguments = table.pack(select(2, ...)),
                    Origin    = getcallingscript(),
                    Function  = getcallingfunction(),
                    Line      = getcallingline(),
                    Source    = getcallingsource(),
                    IsExecutor = checkcaller(),
                })
            end
        end
        return wax.shared.NamecallHook(...)  -- siempre llamar la original
    end)

MÉTODO 2 — hookfunction directo (llama via Event.FireServer(Event, ...))
    -- Truco para capturar las funciones: crear instancias temporales
    -- para obtener referencias a los métodos, luego destruirlas.
    -- La referencia a la función sigue siendo válida después de :Destroy()
    local FunctionsToHook
    do
        local rf = Instance.new("RemoteFunction")
        local re = Instance.new("RemoteEvent")
        FunctionsToHook = { rf.InvokeServer, re.FireServer }
        rf:Destroy()  -- destruir la instancia pero la función sigue viva
        re:Destroy()
    end
    for _, Function in next, FunctionsToHook do
        wax.shared.Hooks[Function] = Hooking.HookFunction(Function, function(...)
            -- misma lógica de logging
            return wax.shared.Hooks[Function](...)
        end)
    end

INCOMING (Server → Client) via getconnections():
    -- Para loggear llamadas entrantes, Cobalt usa getconnections()
    -- ForeignState=true identifica conexiones del executor mismo → ignorar
    local function CreateConnectionFunction(Instance, Method)
        return function(...)
            for _, conn in getconnections(Instance[Method]) do
                if conn.ForeignState then continue end  -- skip executor connections

                local Origin = nil
                -- Método confiable: getscriptfromthread
                if conn.Thread and getscriptfromthread then
                    Origin = getscriptfromthread(conn.Thread)
                end
                -- Método de respaldo (menos confiable):
                if not Origin and conn.Function then
                    local Script = rawget(getfenv(conn.Function), "script")
                    if typeof(Script) == "Instance" then Origin = Script end
                end

                LogRemote(Instance, Method, conn.Function, {
                    Arguments  = table.pack(...),
                    Origin     = Origin,
                    IsExecutor = conn.Function and isexecutorclosure(conn.Function) or false,
                })
            end
        end
    end

DETOUR PARA CALLBACKS (OnInvoke, OnClientInvoke):
    -- Para RemoteFunction/BindableFunction, Cobalt usa un detour en el callback
    local function CreateCallbackDetour(Instance, Method, Callback)
        local Detour = function(...)
            -- Obtener origen via debug.info(2, "f") → función que llamó
            local FunctionCaller = debug.info(2, "f")
            local IsExecutor = isexecutorclosure(FunctionCaller or Callback)

            if LogRemote(Instance, Method, Callback, {...}) then
                return  -- bloqueado, no llamar el callback original
            end
            return Callback(...)  -- siempre llamar el original
        end

        -- Ocultar del stack para que el juego no detecte el detour
        if wax.shared.ExecutorSupport["setstackhidden"].IsWorking then
            setstackhidden(Detour, true)
        end
        return Detour
    end

LOOKUP TABLES — OPTIMIZACIÓN DE BÚSQUEDAS:
    -- Cobalt usa lookup tables en vez de table.find para O(1) vs O(n)
    local function CreateLookupTable(t)
        local LookupTable = {}
        for _, v in next, t do
            LookupTable[v] = true
        end
        return LookupTable
    end

    -- Uso:
    local NamecallMethods = CreateLookupTable({
        "FireServer", "InvokeServer", "Fire", "Invoke",
        "fireServer", "invokeServer", "fire", "invoke",
    })
    -- Verificación O(1): if NamecallMethods[method] then ...
    -- En vez de O(n):    if table.find(NamecallMethods, method) then ...


────────────────────────────────────────────────────────────────────
## MÓDULO 5 — ACTOR VM: HOOKING CROSS-VM
────────────────────────────────────────────────────────────────────

Actors en Roblox corren en VMs Lua separadas. Los hooks del main thread
NO aplican en la VM del Actor. Cobalt resuelve esto con run_on_actor.

ARQUITECTURA DE COMUNICACIÓN ACTOR ↔ MAIN:

    -- Crear canal de comunicación que cruza VMs:
    local ChannelID, Channel = create_comm_channel()
    wax.shared.ActorCommunicator = Channel

    -- Verificar soporte completo antes de intentar:
    wax.shared.ActorsEnabled = (
        wax.shared.ExecutorSupport["run_on_actor"].IsWorking
        and wax.shared.ExecutorSupport["getactors"].IsWorking
        and wax.shared.ExecutorSupport["create_comm_channel"].IsWorking
    )

    -- Hookear cada Actor existente:
    local function HookActor(TargetActor)
        local Hooked = false
        repeat
            Hooked, _ = pcall(run_on_actor, TargetActor, CodeToRun, ChannelID)
            task.wait(0.25)
        until Hooked
        -- Retry loop porque Volcano devuelve actors no inicializados
    end

    for _, actor in getactors() do
        task.spawn(HookActor, actor)
    end

    -- Hookear Actors nuevos que se creen después:
    game.DescendantAdded:Connect(function(actor)
        if actor:IsA("Actor") then
            HookActor(actor)
        end
    end)

SERIALIZACIÓN ENTRE VMs (funciones y tablas no cruzan VMs directamente):

    -- Funciones → se convierten a metadata con dirección, nombre, upvalues
    local function FunctionToMetadata(fn)
        local meta = {
            Address  = tostring(fn),
            Name     = debug.info(fn, "n"),
            Source   = debug.info(fn, "s"),
            IsC      = iscclosure(fn),
            __Function = true,
            Validation = wax.shared.CobaltVerificationToken,  -- seguridad
        }
        if not iscclosure(fn) then
            meta.Upvalues  = debug.getupvalues(fn)
            meta.Constants = debug.getconstants(fn)
            meta.Protos    = debug.getprotos(fn)
            if getfunctionhash then
                meta.FunctionHash = getfunctionhash(fn)
            end
        end
        return meta
    end

    -- Tablas cíclicas → se resuelven con IDs únicos
    -- ReconstructTable(RawInfo, CyclicRefs) reconstruye en el lado receptor

    -- Fix para Seliware (sus Actor BindableEvents están en CoreGui):
    local identity = getthreadidentity()
    setthreadidentity(8)   -- identidad de CoreGui
    Channel.Fire(Channel, "ActorCall", instance, type, FixTable(info))
    setthreadidentity(identity)

FFLAG FIX — Alternativa cuando run_on_actor no existe:
    -- Forzar que los Actors corran en el main thread via FFlag de debug
    -- Esto hace que los hooks del main thread apliquen en todos los Actors
    if not wax.shared.ExecutorSupport["run_on_actor"].IsWorking then
        if CheckFFlagValue("DebugRunParallelLuaOnMainThread", false) then
            setfflag("DebugRunParallelLuaOnMainThread", "true")
            -- Requiere rejoin para aplicar
        end
    end


────────────────────────────────────────────────────────────────────
## MÓDULO 6 — LOGGER: SISTEMA DE LOGGING CON NIVELES
────────────────────────────────────────────────────────────────────

Cobalt implementa un Logger OOP completo con niveles y escritura a archivo.
Patrón de producción real para logging en Lua/Luau.

IMPLEMENTACIÓN COMPLETA:

    local Logger = {}
    Logger.__index = Logger

    Logger.LOG_LEVELS = { ERROR=1, WARNING=2, INFO=3, DEBUG=4 }
    local LOG_LEVEL_STRINGS = {
        [1]="ERROR", [2]="WARNING", [3]="INFO", [4]="DEBUG"
    }

    local startTime = tick()

    -- Crear directorios recursivamente (makefolder no crea padres)
    local function createDirectoryRecursive(path)
        local currentPath = ""
        for part in path:gmatch("[^\/]+") do
            currentPath = currentPath .. part
            if not isfolder(currentPath) then
                makefolder(currentPath)
            end
            currentPath = currentPath .. "/"
        end
    end

    function Logger.new(logFilePath, logLevel, overwrite)
        local self = setmetatable({}, Logger)
        self.logFilePath = logFilePath
        self.logFileDirectory = logFilePath:match("(.+)/")
        self.logLevel = logLevel or Logger.LOG_LEVELS.INFO
        self.overwrite = overwrite or false

        -- Crear directorio si no existe
        local folderPath = logFilePath:match("(.*[\/])(.*)")
        if folderPath and not isfolder(folderPath) then
            createDirectoryRecursive(folderPath)
        end

        if self.overwrite then
            pcall(writefile, self.logFilePath, "")
        end
        self:Info("Logger", "Logger initialized")
        return self
    end

    function Logger:Log(level, threadId, message)
        if level <= self.logLevel then
            local levelStr    = LOG_LEVEL_STRINGS[level]
            local timestamp   = os.date("!%Y-%m-%dT%H:%M:%S") ..
                                ("%.3f"):format(tick() % 1) .. "Z"
            local elapsedTime = ("%.6f"):format(tick() - startTime)
            local logMessage  = timestamp..","..elapsedTime..","..
                                threadId..","..levelStr.." "..message.."
"
            local ok, err = pcall(appendfile, self.logFilePath, logMessage)
            if not ok then
                warn(debug.traceback("Failed to write log: " .. err, 2))
            end
        end
    end

    function Logger:Debug(threadId, msg)   self:Log(4, threadId, msg) end
    function Logger:Info(threadId, msg)    self:Log(3, threadId, msg) end
    function Logger:Warning(threadId, msg) self:Log(2, threadId, msg) end
    function Logger:Error(threadId, msg)   self:Log(1, threadId, msg) end

    -- Nombre de archivo único por sesión de servidor:
    function Logger:GenerateFileName()
        local JobIdNumber = game.JobId:gsub("%D", "")
        local timestamp   = os.date("!%Y%m%d%H%M%S")
        return self.logFileDirectory.."/"..
               (JobIdNumber * 1.7 // 1.8).."_"..timestamp..".log"
    end

LECCIÓN: Formato de log de Cobalt:
    -- timestamp,elapsed,threadId,LEVEL mensaje
    -- Ej: 2024-12-04T15:28:31.131Z,0.131060,Main,INFO Logger initialized


────────────────────────────────────────────────────────────────────
## MÓDULO 7 — FILEHELPER: SISTEMA DE ARCHIVOS ROBUSTO
────────────────────────────────────────────────────────────────────

Abstracción OOP sobre writefile/readfile con rutas relativas y creación
recursiva de directorios. Patrón de módulo utilitario real.

    local FileHelper = {}
    FileHelper.__index = FileHelper

    function FileHelper.new(basePath)
        local self = setmetatable({
            BasePath = FileHelper.NormalizePath(basePath)
        }, FileHelper)
        self:EnsureDirectory()  -- crear si no existe
        return self
    end

    -- Normalizar separadores: \ → / en todas las plataformas
    function FileHelper.NormalizePath(path)
        if type(path) ~= "string" then return "" end
        return path:gsub("\", "/")
    end

    -- Crear directorios padres recursivamente
    function FileHelper:EnsureDirectory()
        local paths = {}
        local parts = self.BasePath:split("/")
        for idx = 1, #parts do
            paths[#paths+1] = table.concat(parts, "/", 1, idx)
        end
        for _, str in ipairs(paths) do
            if not isfolder(str) then makefolder(str) end
        end
    end

    function FileHelper:GetPath(relativePath)
        relativePath = self.NormalizePath(relativePath or "")
        if relativePath == "" then return self.BasePath end
        return self.BasePath .. "/" .. relativePath
    end

    function FileHelper:ReadFile(relativePath)
        return readfile(self:GetPath(relativePath))
    end

    function FileHelper:WriteFile(relativePath, data)
        writefile(self:GetPath(relativePath), data)
    end

    function FileHelper:EnsureFile(relativePath, default)
        if not isfile(self:GetPath(relativePath)) then
            writefile(self:GetPath(relativePath), default)
        end
    end

    function FileHelper:ListFiles(relativePath)
        local files = {}
        for _, file in listfiles(self:GetPath(relativePath or "")) do
            table.insert(files, self:GetRelativePath(file))
        end
        return files
    end

    -- Uso real en Cobalt:
    -- local PluginFiles = FileHelper.new("Cobalt/Plugins")
    -- PluginFiles:EnsureFile("config.json", "{}")
    -- local config = PluginFiles:ReadFile("config.json")


────────────────────────────────────────────────────────────────────
## MÓDULO 8 — LOG SYSTEM: OOP CON ANTI-SPAM
────────────────────────────────────────────────────────────────────

    local Log = {}
    Log.__index = Log

    local SpamCallCountThreshold = 15   -- más de 15 calls
    local SpamTimeWindowSeconds  = 1    -- en 1 segundo = spam

    function Log.new(Instance, Type, Method, Index, CallingScript)
        return setmetatable({
            Instance    = Instance,
            Type        = Type,      -- "Incoming" | "Outgoing"
            Method      = Method,    -- "FireServer", "OnClientEvent", etc.
            Index       = Index,
            Calls       = {},        -- todas las calls
            GameCalls   = {},        -- solo calls del juego (no executor)
            SpamHistory = {},        -- timestamps para anti-spam
            Ignored     = false,
            Blocked     = false,
        }, Log)
    end

    -- Anti-spam: auto-ignore si supera el threshold
    function Log:IsOverSpamThreshold()
        if not wax.shared.SaveManager:GetState("AutoIgnoreSpammyEvents", false) then
            return false
        end
        local Now = tick()
        table.insert(self.SpamHistory, Now)

        -- Limpiar entradas viejas (fuera de la ventana de tiempo)
        for i = #self.SpamHistory, 1, -1 do
            if Now - self.SpamHistory[i] > SpamTimeWindowSeconds then
                table.remove(self.SpamHistory, i)
            end
        end

        if #self.SpamHistory > SpamCallCountThreshold then
            if not self.Ignored then
                self:Ignore()  -- auto-ignore
                wax.shared.Sonner.info("Ignored " .. self.Instance.Name .. " due to spam.")
            end
            return true
        end
        return false
    end

DEEPCLONE EN COBALT (maneja Instances, userdata, functions):
    local function DeepClone(orig, copies)
        copies = copies or {}
        if typeof(orig) == "Instance" then
            return cloneref(orig)         -- clonar instancias con cloneref
        elseif typeof(orig) == "userdata" then
            return newproxy(getmetatable(orig) ~= nil)
        elseif typeof(orig) == "function" then
            return clonefunction and clonefunction(orig) or orig
        elseif type(orig) ~= "table" then
            return orig
        elseif copies[orig] then
            return copies[orig]           -- tablas cíclicas
        end
        local copy = {}
        copies[orig] = copy
        for k, v in next, orig do
            copy[DeepClone(k, copies)] = DeepClone(v, copies)
        end
        return copy
    end


────────────────────────────────────────────────────────────────────
## MÓDULO 9 — CONNECTION MANAGER: LIMPIEZA GARANTIZADA
────────────────────────────────────────────────────────────────────

    -- Cobalt trackea TODAS las conexiones para poder desconectarlas al unload
    wax.shared.Connections = {}

    wax.shared.Connect = function(Connection)
        table.insert(wax.shared.Connections, Connection)
        return Connection
    end

    wax.shared.Disconnect = function(Connection)
        Connection:Disconnect()
        local Index = table.find(wax.shared.Connections, Connection)
        if Index then
            table.remove(wax.shared.Connections, Index)
        end
        return true
    end

    -- Al unload, limpiar TODO:
    wax.shared.Unload = function()
        -- 1. Desconectar todas las conexiones
        for _, Connection in pairs(wax.shared.Connections) do
            wax.shared.Disconnect(Connection)
        end
        -- 2. Restaurar metamétodos hookeados
        local gameMetatable = wax.shared.getrawmetatable(game)
        -- (restaurar __namecall y __newindex)
        -- 3. Restaurar funciones hookeadas
        for Function, Original in pairs(wax.shared.Hooks) do
            pcall(wax.shared.Hooking.HookFunction, Function, Original)
        end
        -- 4. Notificar Actors
        if wax.shared.ActorCommunicator then
            wax.shared.ActorCommunicator:Fire("Unload")
        end
        -- 5. Destruir GUI
        wax.shared.ScreenGui:Destroy()
        wax.shared.Unloaded = true
    end

LECCIÓN: Siempre guardar referencias a conexiones para limpiarlas después.
    -- Patrón correcto:
    local connections = {}
    connections[#connections+1] = event:Connect(handler)
    -- Al limpiar:
    for _, c in ipairs(connections) do c:Disconnect() end


────────────────────────────────────────────────────────────────────
## MÓDULO 10 — CODEGEN: GENERACIÓN DE CÓDIGO LUA EN RUNTIME
────────────────────────────────────────────────────────────────────

Cobalt genera código Lua como strings para reproducir llamadas interceptadas.

CARACTERES ESPECIALES EN STRINGS — tabla de escape:
    local CleanTable = { ['"'] = '\"', ["\"] = "\\" }
    -- Agregar caracteres de control (0-31) y extendidos (127-255):
    for i = 0, 31 do
        CleanTable[string.char(i)] = "\" .. string.format("%03d", i)
    end
    for i = 127, 255 do
        CleanTable[string.char(i)] = "\" .. string.format("%03d", i)
    end

    function CodeGen.FormatLuaString(str)
        return string.gsub(str, '[\"\\\0-\31\127-\255]', CleanTable)
    end

OBTENER PATH COMPLETO DE UNA INSTANCIA (para reproducir en código):
    -- GetFullPath construye "game:GetService('Players').LocalPlayer.Character.HumanoidRootPart"
    -- Maneja: LocalPlayer, UserId en nombre, nil parent, servicio directo, hijos duplicados
    -- Configurable: Index (default) | WaitForChild | FindFirstChild

INDENTACIÓN DE CÓDIGO:
    function CodeGen:IndentCode(Code, IndentLevel)
        local Indent = string.rep("    ", IndentLevel)  -- 4 espacios
        local IndentedCode = Code:gsub("
", "
" .. Indent)
        return Indent .. IndentedCode
    end

WRAP EN ACTOR (para reproducir en VM de Actor):
    local WrapperActorCode = table.concat({
        "for _, actor in getactors() do",
        "    run_on_actor(actor, [[\n%s\n]])",
        "end",
    }, "
")


────────────────────────────────────────────────────────────────────
## MÓDULO 11 — ANTICHEAT BYPASS: ARQUITECTURA DE DETECCIÓN
────────────────────────────────────────────────────────────────────

    type Bypass = {
        Name:   string,
        Game:   string | number | { number },  -- "*" = todos los juegos
        Detect: () -> boolean,
        Bypass: () -> boolean,
    }

    -- Ejemplo real: Bypass de Adonis Anticheat
    local Adonis = { Name = "Adonis", Game = "*" }

    function Adonis.Detect()
        if not getreg or not getgc or not isfunctionhooked then
            return false
        end
        -- Buscar threads de Adonis en el registro:
        for _, thread in getreg() do
            if typeof(thread) ~= "thread" then continue end
            local Source = debug.info(thread, 1, "s")
            if Source and (Source:match(".Core.Anti") or
                           Source:match(".Plugins.Anti_Cheat")) then
                return true  -- Adonis detectado
            end
        end
        return false
    end

    function Adonis.Bypass()
        -- Paso 1: cerrar threads del anticheat
        for _, thread in AdonisAnticheatThreads do
            pcall(coroutine.close, thread)
        end
        -- Paso 2: hookear funciones de detección para que nunca disparen
        -- (usando filtergc o getgc para encontrar las tablas de Adonis)
        for _, DetectionFunc in AdonisTables do
            if typeof(DetectionFunc) ~= "function" then continue end
            if isfunctionhooked(DetectionFunc) then continue end  -- ya hookeado
            wax.shared.Hooks[DetectionFunc] = Hooking.HookFunction(
                DetectionFunc,
                function(action, info, nocrash)
                    coroutine.yield()    -- pausar indefinidamente
                    return task.wait(9e9)  -- no retornar nunca
                end
            )
        end
        return true
    end

SELECCIÓN DE BYPASS POR PLACEID:
    -- Game = "*"        → bypass general (cualquier juego)
    -- Game = 12345      → bypass dedicado para ese PlaceId específico
    -- Game = {1,2,3}    → bypass para lista de PlaceIds
    -- Si hay bypass dedicado: usarlo antes que los generales


────────────────────────────────────────────────────────────────────
## MÓDULO 12 — GETCALLINGFUNCTION/LINE/SOURCE: DEBUG INFO AVANZADO
────────────────────────────────────────────────────────────────────

    -- Cobalt implementa helpers para obtener info del caller real,
    -- saltando frames de C y frames del executor

    local function getcallingfunction()
        -- Con oth: el stack es más corto (nivel base = 2)
        -- Sin oth: el stack tiene frames extra del hook (nivel base = 4)
        local BaseLevel = wax.shared.ExecutorSupport["oth"].IsWorking and 2 or 4

        for i = BaseLevel, 10 do
            local Function, Source = debug.info(i, "fs")
            if not Function or not Source then break end
            if Source == "[C]" then continue end  -- saltar frames C
            return Function
        end
        return debug.info(BaseLevel, "f")
    end

    local function getcallingline()
        local BaseLevel = wax.shared.ExecutorSupport["oth"].IsWorking and 2 or 4
        for i = BaseLevel, 10 do
            local Source, Line = debug.info(i, "sl")
            if not Source then break end
            if Source == "[C]" then continue end
            return Line
        end
        return debug.info(BaseLevel, "l")
    end

    -- Uso en el hook de __namecall:
    Log:Call({
        Arguments  = table.pack(select(2, ...)),
        Origin     = getcallingscript(),
        Function   = getcallingfunction(),
        Line       = getcallingline(),
        Source     = getcallingsource(),
        IsExecutor = checkcaller(),
    })

LECCIÓN sobre debug.info en Luau:
    debug.info(level, "f")  → función en ese nivel del stack
    debug.info(level, "s")  → source ("[C]" para C functions)
    debug.info(level, "l")  → número de línea
    debug.info(level, "n")  → nombre de la función
    debug.info(level, "fs") → función y source juntos
    debug.info(level, "sl") → source y línea juntos
    -- "[C]" como source significa que es una función nativa de C


────────────────────────────────────────────────────────────────────
## MÓDULO 13 — PLUGIN SYSTEM: ARQUITECTURA EXTENSIBLE
────────────────────────────────────────────────────────────────────

    local Manager = {
        Registry = {
            Plugins  = {},
            Errored  = {},
            Interceptors = { Global = {}, Instance = {} },
            UIHooks = {
                RemoteInfo  = { Tabs={}, Open={}, Intercept={} },
                ContextMenus = { RemoteList={}, CallList={} },
                CodeGen     = { Call={}, Hook={}, InstancePath={} },
            },
        },
        HasInterceptors = false,
        HasCodeGenInterceptors = false,
    }

    -- Validar datos del plugin contra template:
    local function Validate(Data, Template)
        local NewData = {}
        for Key, Value in Template do
            if Data[Key] == nil or typeof(Data[Key]) ~= typeof(Value) then
                NewData[Key] = Value   -- usar default si falta o tipo incorrecto
            else
                NewData[Key] = Data[Key]
            end
        end
        return NewData
    end

    -- CodeGen interceptors permiten a plugins modificar código generado:
    local function RunInterceptors(Interceptors, Info, Log)
        for _, Callback in Interceptors do
            local Ok, Result = pcall(Callback, Info, Log.Instance, Log.Type)
            if not Ok then
                warn("[Cobalt Plugin Interceptor] Error: " .. Result)
            elseif Result == false then
                return true  -- interceptor canceló la operación
            end
        end
        return false
    end


────────────────────────────────────────────────────────────────────
## MÓDULO 14 — PAGINATION: ALGORITMO DE PAGINACIÓN
────────────────────────────────────────────────────────────────────

    -- Paginación con ellipsis estilo React (para UI de Cobalt):
    function Pagination:GetVisualInfo(Page)
        -- Retorna array como: { 1, "ellipsis", 4, 5, 6, "ellipsis", 20 }
        -- Maneja 3 casos:
        -- 1. No FakeLeft, FakeRight:   { 1,2,3,...,TotalPages }
        -- 2. FakeLeft, no FakeRight:   { 1,...,17,18,19,20 }
        -- 3. FakeLeft y FakeRight:     { 1,...,8,9,10,...,20 }
        local MaxButtons  = 5 + self.SiblingCount * 2
        local LeftSibling = math.max(Page - self.SiblingCount, 1)
        local RightSibling = math.min(Page + self.SiblingCount, TotalPages)
        local FakeLeft  = LeftSibling > 2
        local FakeRight = RightSibling < TotalPages - 1
        -- [implementación según caso]
    end


────────────────────────────────────────────────────────────────────
## LECCIONES GLOBALES DE COBALT PARA LUAGOD
────────────────────────────────────────────────────────────────────

1. NUNCA usar una función del executor sin verificar primero con test()
   → if ExecutorSupport["hookfunction"].IsWorking then ...

2. SIEMPRE usar cloneref() para servicios de Roblox en executores
   → Previene detección por hooks del juego en GetService

3. LOOKUP TABLES > table.find() para búsquedas frecuentes
   → O(1) vs O(n), especialmente en hooks que corren cada frame

4. setstackhidden() en detours para no aparecer en debug.traceback
   → El juego no puede ver que Cobalt interceptó la llamada

5. oth (One-Thread Hooks) es MEJOR que hookfunction si está disponible
   → El hook corre en coroutine separado, indetectable en callstack

6. Siempre guardar conexiones en tabla y limpiarlas en unload
   → Memory leaks si no limpias conexiones al descargar el script

7. Para RemoteFunction callback: CreateCallbackDetour + setstackhidden
   → La forma correcta de interceptar OnInvoke/OnClientInvoke

8. Actores tienen VM separada: usar run_on_actor o FFlag fix
   → Sin esto, los hooks del main thread no aplican en Actors

9. ForeignState=true en conexiones identifica al executor mismo
   → Siempre skipear estas al iterar getconnections()

10. DeepClone con cloneref para Instances, newproxy para userdata
    → La copia normal de tablas no funciona con tipos de Roblox


────────────────────────────────────────────────────────────────────
## MÓDULO 5 — ACTOR VM: HOOKING CROSS-VM
────────────────────────────────────────────────────────────────────

Actors en Roblox corren en VMs Lua separadas. Los hooks del main thread
NO aplican en la VM del Actor. Cobalt resuelve esto con run_on_actor.

ARQUITECTURA DE COMUNICACIÓN ACTOR ↔ MAIN:

    -- Crear canal de comunicación que cruza VMs:
    local ChannelID, Channel = create_comm_channel()
    wax.shared.ActorCommunicator = Channel

    -- Verificar soporte completo antes de intentar:
    wax.shared.ActorsEnabled = (
        wax.shared.ExecutorSupport["run_on_actor"].IsWorking
        and wax.shared.ExecutorSupport["getactors"].IsWorking
        and wax.shared.ExecutorSupport["create_comm_channel"].IsWorking
    )

    -- Hookear cada Actor existente:
    local function HookActor(TargetActor)
        local Hooked = false
        repeat
            Hooked, _ = pcall(run_on_actor, TargetActor, CodeToRun, ChannelID)
            task.wait(0.25)
        until Hooked
        -- Retry loop porque Volcano devuelve actors no inicializados
    end

    for _, actor in getactors() do
        task.spawn(HookActor, actor)
    end

    -- Hookear Actors nuevos que se creen después:
    game.DescendantAdded:Connect(function(actor)
        if actor:IsA("Actor") then
            HookActor(actor)
        end
    end)

SERIALIZACIÓN ENTRE VMs (funciones y tablas no cruzan VMs directamente):

    -- Funciones → se convierten a metadata con dirección, nombre, upvalues
    local function FunctionToMetadata(fn)
        local meta = {
            Address  = tostring(fn),
            Name     = debug.info(fn, "n"),
            Source   = debug.info(fn, "s"),
            IsC      = iscclosure(fn),
            __Function = true,
            Validation = wax.shared.CobaltVerificationToken,
        }
        if not iscclosure(fn) then
            meta.Upvalues  = debug.getupvalues(fn)
            meta.Constants = debug.getconstants(fn)
            meta.Protos    = debug.getprotos(fn)
            if getfunctionhash then
                meta.FunctionHash = getfunctionhash(fn)
            end
        end
        return meta
    end

    -- Tablas cíclicas → se resuelven con IDs únicos
    -- ReconstructTable(RawInfo, CyclicRefs) reconstruye en el lado receptor

    -- Fix para Seliware (sus Actor BindableEvents están en CoreGui):
    local identity = getthreadidentity()
    setthreadidentity(8)   -- identidad de CoreGui
    Channel.Fire(Channel, "ActorCall", instance, type, FixTable(info))
    setthreadidentity(identity)

FFLAG FIX — Alternativa cuando run_on_actor no existe:
    -- Forzar que los Actors corran en el main thread via FFlag de debug
    if not wax.shared.ExecutorSupport["run_on_actor"].IsWorking then
        if CheckFFlagValue("DebugRunParallelLuaOnMainThread", false) then
            setfflag("DebugRunParallelLuaOnMainThread", "true")
            -- Requiere rejoin para aplicar
        end
    end


────────────────────────────────────────────────────────────────────
## MÓDULO 6 — LOGGER: SISTEMA DE LOGGING CON NIVELES
────────────────────────────────────────────────────────────────────

Cobalt implementa un Logger OOP completo con niveles y escritura a archivo.

    local Logger = {}
    Logger.__index = Logger

    Logger.LOG_LEVELS = { ERROR=1, WARNING=2, INFO=3, DEBUG=4 }
    local LOG_LEVEL_STRINGS = {
        [1]="ERROR", [2]="WARNING", [3]="INFO", [4]="DEBUG"
    }

    local startTime = tick()

    -- Crear directorios recursivamente
    local function createDirectoryRecursive(path)
        local currentPath = ""
        for part in path:gmatch("[^/\\]+") do
            currentPath = currentPath .. part
            if not isfolder(currentPath) then
                makefolder(currentPath)
            end
            currentPath = currentPath .. "/"
        end
    end

    function Logger.new(logFilePath, logLevel, overwrite)
        local self = setmetatable({}, Logger)
        self.logFilePath = logFilePath
        self.logLevel = logLevel or Logger.LOG_LEVELS.INFO
        self.overwrite = overwrite or false

        local folderPath = logFilePath:match("(.*[/\\])(.*)")
        if folderPath and not isfolder(folderPath) then
            createDirectoryRecursive(folderPath)
        end

        if self.overwrite then
            pcall(writefile, self.logFilePath, "")
        end
        self:Info("Logger", "Logger initialized")
        return self
    end

    function Logger:Log(level, threadId, message)
        if level <= self.logLevel then
            local levelStr = LOG_LEVEL_STRINGS[level]
            local timestamp = os.date("!%Y-%m-%dT%H:%M:%S") ..
                            ("%.3f"):format(tick() % 1) .. "Z"
            local elapsedTime = ("%.6f"):format(tick() - startTime)
            local logMessage = timestamp..","..elapsedTime..","..
                             threadId..","..levelStr.." "..message.."\n"
            pcall(appendfile, self.logFilePath, logMessage)
        end
    end

    function Logger:Debug(tid, msg)   self:Log(4, tid, msg) end
    function Logger:Info(tid, msg)    self:Log(3, tid, msg) end
    function Logger:Warning(tid, msg) self:Log(2, tid, msg) end
    function Logger:Error(tid, msg)   self:Log(1, tid, msg) end


────────────────────────────────────────────────────────────────────
## MÓDULO 7 — FILEHELPER: SISTEMA DE ARCHIVOS ROBUSTO
────────────────────────────────────────────────────────────────────

    local FileHelper = {}
    FileHelper.__index = FileHelper

    function FileHelper.new(basePath)
        local self = setmetatable({
            BasePath = FileHelper.NormalizePath(basePath)
        }, FileHelper)
        self:EnsureDirectory()
        return self
    end

    function FileHelper.NormalizePath(path)
        if type(path) ~= "string" then return "" end
        return path:gsub("\\", "/")
    end

    function FileHelper:EnsureDirectory()
        local paths = {}
        local parts = self.BasePath:split("/")
        for idx = 1, #parts do
            paths[#paths+1] = table.concat(parts, "/", 1, idx)
        end
        for _, str in ipairs(paths) do
            if not isfolder(str) then makefolder(str) end
        end
    end

    function FileHelper:GetPath(relativePath)
        relativePath = self.NormalizePath(relativePath or "")
        if relativePath == "" then return self.BasePath end
        return self.BasePath .. "/" .. relativePath
    end

    function FileHelper:ReadFile(relativePath)
        return readfile(self:GetPath(relativePath))
    end

    function FileHelper:WriteFile(relativePath, data)
        writefile(self:GetPath(relativePath), data)
    end


────────────────────────────────────────────────────────────────────
## MÓDULO 8 — LOG SYSTEM: OOP CON ANTI-SPAM
────────────────────────────────────────────────────────────────────

    local Log = {}
    Log.__index = Log

    local SpamCallCountThreshold = 15
    local SpamTimeWindowSeconds = 1

    function Log.new(Instance, Type, Method, Index, CallingScript)
        return setmetatable({
            Instance = Instance,
            Type = Type,
            Method = Method,
            Index = Index,
            Calls = {},
            GameCalls = {},
            SpamHistory = {},
            Ignored = false,
            Blocked = false,
        }, Log)
    end

    function Log:IsOverSpamThreshold()
        if not wax.shared.SaveManager:GetState("AutoIgnoreSpammyEvents", false) then
            return false
        end
        local Now = tick()
        table.insert(self.SpamHistory, Now)

        for i = #self.SpamHistory, 1, -1 do
            if Now - self.SpamHistory[i] > SpamTimeWindowSeconds then
                table.remove(self.SpamHistory, i)
            end
        end

        if #self.SpamHistory > SpamCallCountThreshold then
            if not self.Ignored then
                self:Ignore()
                wax.shared.Sonner.info("Ignored " .. self.Instance.Name .. " due to spam.")
            end
            return true
        end
        return false
    end

DEEPCLONE EN COBALT:
    local function DeepClone(orig, copies)
        copies = copies or {}
        if typeof(orig) == "Instance" then
            return cloneref(orig)
        elseif typeof(orig) == "userdata" then
            return newproxy(getmetatable(orig) ~= nil)
        elseif typeof(orig) == "function" then
            return clonefunction and clonefunction(orig) or orig
        elseif type(orig) ~= "table" then
            return orig
        elseif copies[orig] then
            return copies[orig]
        end
        local copy = {}
        copies[orig] = copy
        for k, v in next, orig do
            copy[DeepClone(k, copies)] = DeepClone(v, copies)
        end
        return copy
    end


────────────────────────────────────────────────────────────────────
## MÓDULO 9 — CONNECTION MANAGER
────────────────────────────────────────────────────────────────────

    wax.shared.Connections = {}

    wax.shared.Connect = function(Connection)
        table.insert(wax.shared.Connections, Connection)
        return Connection
    end

    wax.shared.Disconnect = function(Connection)
        Connection:Disconnect()
        local Index = table.find(wax.shared.Connections, Connection)
        if Index then
            table.remove(wax.shared.Connections, Index)
        end
        return true
    end

    wax.shared.Unload = function()
        for _, Connection in pairs(wax.shared.Connections) do
            wax.shared.Disconnect(Connection)
        end
        local gameMetatable = wax.shared.getrawmetatable(game)
        for Function, Original in pairs(wax.shared.Hooks) do
            pcall(wax.shared.Hooking.HookFunction, Function, Original)
        end
        if wax.shared.ActorCommunicator then
            wax.shared.ActorCommunicator:Fire("Unload")
        end
        wax.shared.ScreenGui:Destroy()
        wax.shared.Unloaded = true
    end


────────────────────────────────────────────────────────────────────
## MÓDULO 10 — CODEGEN: GENERACIÓN DE CÓDIGO LUA
────────────────────────────────────────────────────────────────────

    local CleanTable = { ['"'] = '\\"', ["\\"] = "\\\\" }
    for i = 0, 31 do
        CleanTable[string.char(i)] = "\\" .. string.format("%03d", i)
    end
    for i = 127, 255 do
        CleanTable[string.char(i)] = "\\" .. string.format("%03d", i)
    end

    function CodeGen.FormatLuaString(str)
        return string.gsub(str, '[\"\\\\\\0-\\31\\127-\\255]', CleanTable)
    end

    function CodeGen:IndentCode(Code, IndentLevel)
        local Indent = string.rep("    ", IndentLevel)
        local IndentedCode = Code:gsub("\n", "\n" .. Indent)
        return Indent .. IndentedCode
    end


────────────────────────────────────────────────────────────────────
## MÓDULO 11 — ANTICHEAT BYPASS
────────────────────────────────────────────────────────────────────

    type Bypass = {
        Name: string,
        Game: string | number | { number },
        Detect: () -> boolean,
        Bypass: () -> boolean,
    }

    local Adonis = { Name = "Adonis", Game = "*" }

    function Adonis.Detect()
        if not getreg or not getgc or not isfunctionhooked then
            return false
        end
        for _, thread in getreg() do
            if typeof(thread) ~= "thread" then continue end
            local Source = debug.info(thread, 1, "s")
            if Source and (Source:match(".Core.Anti") or
                           Source:match(".Plugins.Anti_Cheat")) then
                return true
            end
        end
        return false
    end

    function Adonis.Bypass()
        for _, thread in AdonisAnticheatThreads do
            pcall(coroutine.close, thread)
        end
        for _, DetectionFunc in AdonisTables do
            if typeof(DetectionFunc) ~= "function" then continue end
            if isfunctionhooked(DetectionFunc) then continue end
            wax.shared.Hooks[DetectionFunc] = Hooking.HookFunction(
                DetectionFunc,
                function(action, info, nocrash)
                    coroutine.yield()
                    return task.wait(9e9)
                end
            )
        end
        return true
    end


────────────────────────────────────────────────────────────────────
## MÓDULO 12 — GETCALLING HELPERS
────────────────────────────────────────────────────────────────────

    local function getcallingfunction()
        local BaseLevel = wax.shared.ExecutorSupport["oth"].IsWorking and 2 or 4
        for i = BaseLevel, 10 do
            local Function, Source = debug.info(i, "fs")
            if not Function or not Source then break end
            if Source == "[C]" then continue end
            return Function
        end
        return debug.info(BaseLevel, "f")
    end

    local function getcallingline()
        local BaseLevel = wax.shared.ExecutorSupport["oth"].IsWorking and 2 or 4
        for i = BaseLevel, 10 do
            local Source, Line = debug.info(i, "sl")
            if not Source then break end
            if Source == "[C]" then continue end
            return Line
        end
        return debug.info(BaseLevel, "l")
    end

    local function getcallingsource()
        local BaseLevel = wax.shared.ExecutorSupport["oth"].IsWorking and 2 or 4
        for i = BaseLevel, 10 do
            local Source = debug.info(i, "s")
            if not Source then break end
            if Source == "[C]" then continue end
            return Source
        end
        return debug.info(BaseLevel, "s")
    end


────────────────────────────────────────────────────────────────────
## MÓDULO 13 — PLUGIN SYSTEM
────────────────────────────────────────────────────────────────────

    local Manager = {
        Registry = {
            Plugins = {},
            Errored = {},
            Interceptors = { Global = {}, Instance = {} },
            UIHooks = {
                RemoteInfo = { Tabs={}, Open={}, Intercept={} },
                ContextMenus = { RemoteList={}, CallList={} },
                CodeGen = { Call={}, Hook={}, InstancePath={} },
            },
        },
        HasInterceptors = false,
        HasCodeGenInterceptors = false,
    }

    local function Validate(Data, Template)
        local NewData = {}
        for Key, Value in Template do
            if Data[Key] == nil or typeof(Data[Key]) ~= typeof(Value) then
                NewData[Key] = Value
            else
                NewData[Key] = Data[Key]
            end
        end
        return NewData
    end

    local function RunInterceptors(Interceptors, Info, Log)
        for _, Callback in Interceptors do
            local Ok, Result = pcall(Callback, Info, Log.Instance, Log.Type)
            if not Ok then
                warn("[Cobalt Plugin Interceptor] Error: " .. Result)
            elseif Result == false then
                return true
            end
        end
        return false
    end


────────────────────────────────────────────────────────────────────
## LECCIONES GLOBALES DE COBALT
────────────────────────────────────────────────────────────────────

1. NUNCA usar una función del executor sin verificar primero con test()
   → if ExecutorSupport["hookfunction"].IsWorking then ...

2. SIEMPRE usar cloneref() para servicios de Roblox en executors
   → Previene detección por hooks del juego en GetService

3. LOOKUP TABLES > table.find() para búsquedas frecuentes
   → O(1) vs O(n), especialmente en hooks que corren cada frame

4. setstackhidden() en detours para no aparecer en debug.traceback
   → El juego no puede ver que Cobalt interceptó la llamada

5. oth (One-Thread Hooks) es MEJOR que hookfunction si está disponible
   → El hook corre en coroutine separado, indetectable en callstack

6. Siempre guardar conexiones en tabla y limpiarlas en unload
   → Memory leaks si no limpias conexiones al descargar el script

7. Para RemoteFunction callback: CreateCallbackDetour + setstackhidden
   → La forma correcta de interceptar OnInvoke/OnClientInvoke

8. Actores tienen VM separada: usar run_on_actor o FFlag fix
   → Sin esto, los hooks del main thread no aplican en Actors

9. ForeignState=true en conexiones identifica al executor mismo
   → Siempre skipear estas al iterar getconnections()

10. DeepClone con cloneref para Instances, newproxy para userdata
    → La copia normal de tablas no funciona con tipos de Roblox

"""

def get_context(intent: str = "generic", lua_target: str = "luau") -> str:
    """Retorna el contexto de conocimiento relevante para el intent dado."""
    from knowledge.external_repos import get_external_kb
    base = LUA_CORE + "\n" + LUA_FUNCTIONS

    sections = {
        "combat":   base + LUA_METATABLES + DESIGN_PATTERNS,
        "oop":      base + LUA_METATABLES + DESIGN_PATTERNS,
        "data":     base + LUA_METATABLES + DESIGN_PATTERNS,
        "loop":     base + LUA_CLOSURES,
        "debug":    base + DEBUG_TOOLS + COMMON_ERRORS,
        "teach":    base + LUA_METATABLES + LUA_COROUTINES + LUA_CLOSURES + LUA_PATTERNS,
        "review":   base + COMMON_ERRORS + PERFORMANCE_TIPS,
        "executor": base + LUAU_EXECUTOR_APIS + LUAU_SPECIFIC + LUAU_EDUCATIONAL_SCRIPTS + COBALT_ANALYSIS + COBALT_CORE_KB + COBALT_SOURCE_0 + COBALT_SOURCE_1 + COBALT_SOURCE_2 + COBALT_SOURCE_3 + get_external_kb("all"),
        "roblox":   base + LUAU_SPECIFIC + LUA_METATABLES + DESIGN_PATTERNS,
        "generic":  base + LUA_METATABLES + COMMON_ERRORS,
    }

    ctx = sections.get(intent, sections["generic"])

    if lua_target in ("luau", "roblox", "delta", "fluxus", "arceus"):
        ctx += "\n" + LUAU_SPECIFIC
        if lua_target in ("delta", "fluxus", "arceus"):
            ctx += "\n" + LUAU_EXECUTOR_APIS + "\n" + LUAU_EDUCATIONAL_SCRIPTS + "\n" + COBALT_ANALYSIS + "\n" + COBALT_CORE_KB + "\n" + COBALT_SOURCE_0 + "\n" + COBALT_SOURCE_1 + "\n" + COBALT_SOURCE_2 + "\n" + COBALT_SOURCE_3 + "\n" + get_external_kb("all")

    return ctx


def get_all() -> str:
    """Retorna TODO el conocimiento (para modelos pequeños).

────────────────────────────────────────────────────────────────────
## SECCIÓN AVANZADA — IMPLEMENTACIONES COMPLETAS DE COBALT
────────────────────────────────────────────────────────────────────

### IMPLEMENTACIÓN COMPLETA: EXECUTOR SUPPORT TESTS

Cobalt ejecuta más de 50 tests diferentes para verificar capacidades del executor.
Aquí están TODOS los tests reales con su lógica completa:

TEST DE HOOKFUNCTION (verificación profunda):
    test("hookfunction", function()
        assert(typeof(hookfunction) == "function", "hookfunction is not a function")
        
        local function Original(a, b)
            return a + b
        end
        
        local ref = hookfunction(Original, function(a, b)
            return a * b
        end)
        
        assert(Original(2, 3) == 6, "Failed to hook a function and change the return value")
        assert(ref(2, 3) == 5, "Did not return the original function")
    end)

TEST DE ISFUNCTIONHOOKED:
    test("isfunctionhooked", function()
        assert(typeof(isfunctionhooked) == "function", "isfunctionhooked is not a function")
        assert(typeof(hookfunction) == "function", "hookfunction is required for this test")
        
        local function Original(a, b)
            return a + b
        end
        
        assert(isfunctionhooked(Original) == false, "isfunctionhooked returned true for an unhooked function")
        
        hookfunction(Original, function(a, b)
            return a * b
        end)
        
        assert(isfunctionhooked(Original) == true, "isfunctionhooked returned false for a hooked function")
    end)

TEST DE RESTOREFUNCTION:
    test("restorefunction", function()
        assert(typeof(restorefunction) == "function", "restorefunction is not a function")
        assert(typeof(hookfunction) == "function", "hookfunction is required for this test")
        
        local function Original(a, b)
            return a + b
        end
        
        hookfunction(Original, function(a, b)
            return a * b
        end)
        
        assert(Original(2, 3) == 6, "Failed to hook a function and change the return value")
        
        restorefunction(Original)
        
        assert(Original(2, 3) == 5, "restorefunction did not restore the original function")
    end)

TEST DE NEWCCLOSURE (verifica que sea REALMENTE C closure):
    test("newcclosure", function()
        assert(typeof(newcclosure) == "function", "newcclosure is not a function")
        
        local CClosure = newcclosure(function()
            return true
        end)
        
        assert(typeof(CClosure) == "function", "newcclosure did not return a function")
        assert(CClosure() == true, "Failed to create a new closure")
        assert(debug.info(CClosure, "s") == "[C]", "newcclosure did not create a C closure")
    end, true)

TEST DE SETSTACKHIDDEN (el más complejo - 4 métodos de verificación):
    test("setstackhidden", function()
        assert(typeof(setstackhidden) == "function", "setstackhidden is not a function")
        
        local StackCheck = {}
        
        local CallerFunctionSource = [[
            local StackCheck = ...
            local function CallerFunction()
                return StackCheck[1]()
            end
            return CallerFunction
        ]]
        
        local CallerFunction = (loadstring(CallerFunctionSource, "=CallerFunction") :: (...any) -> ...any)(StackCheck)
        
        setstackhidden(CallerFunction, true)
        
        -- Test 1: debug.info no debe ver la función
        StackCheck[1] = function()
            local Level = 1
            while true do
                local info = debug.info(Level, "f")
                if info == nil then
                    break
                end
                if info == CallerFunction then
                    return false
                end
                Level += 1
            end
            return true
        end
        assert(CallerFunction(), "setstackhidden did not hide the function from debug.info")
        
        -- Test 2: debug.traceback no debe mencionar "CallerFunction"
        StackCheck[1] = function()
            local traceback = debug.traceback()
            return not traceback:find("CallerFunction")
        end
        assert(CallerFunction(), "setstackhidden did not hide the function from debug.traceback")
        
        -- Test 3: getfenv no debe devolver el env de la función
        StackCheck[1] = function()
            local env = getfenv(2)
            return env ~= getfenv(CallerFunction)
        end
        assert(CallerFunction(), "setstackhidden did not hide the function from getfenv")
        
        -- Test 4: error con level no debe incluirla en el traceback
        StackCheck[1] = function()
            local success, err = pcall(function()
                error("Test error", 2)
            end)
            return not err:find("CallerFunction")
        end
        assert(CallerFunction(), "setstackhidden did not hide the function from error traceback")
    end, false, false)

TEST DE OTH (One-Thread Hooks - el más avanzado):
    test("oth", function()
        assert(oth ~= nil, "oth is not available")
        assert(hookfunction ~= oth.hook, "oth.hook should not be an alias of hookfunction")
        assert(restorefunction ~= oth.unhook, "oth.unhook should not be an alias of restorefunction")
        
        -- Test real con VirtualInputManager para verificar thread separado
        local VIM = Instance.new("VirtualInputManager")
        local Origin = coroutine.running()
        local Working = nil
        local Old
        
        Old = oth.hook(VIM.SendGravityEvent, function(...)
            if Working == nil then
                Working = (Origin ~= coroutine.running()  -- thread diferente
                    and oth.is_hook_thread()               -- es hook thread
                    and oth.get_original_thread() == Origin) -- origen correcto
                return
            end
            return Old(...)
        end)
        
        pcall(VIM.SendGravityEvent, VIM, 0, 0, 0)
        repeat task.wait() until Working ~= nil
        
        oth.unhook(VIM.SendGravityEvent, Old)
        VIM:Destroy()
        
        assert(Working, "oth did not create a separate thread for the hook")
    end, false, false)

TEST DE GETACTORS:
    test("getactors", function()
        assert(typeof(getactors) == "function", "getactors is not a function")
        local actors = getactors()
        assert(typeof(actors) == "table", "getactors did not return a table")
    end, true)

TEST DE RUN_ON_ACTOR:
    test("run_on_actor", function()
        assert(typeof(run_on_actor) == "function", "run_on_actor is not a function")
        assert(typeof(getactors) == "function", "getactors is required for this test")
        
        local actors = getactors()
        if #actors == 0 then
            return "No actors available to test"
        end
        
        local success = pcall(run_on_actor, actors[1], [[print("test")]])
        assert(success, "run_on_actor failed to execute code on actor")
    end, true)

TEST DE CREATE_COMM_CHANNEL:
    test("create_comm_channel", function()
        assert(typeof(create_comm_channel) == "function", "create_comm_channel is not a function")
        
        local channelId, channel = create_comm_channel()
        assert(typeof(channelId) == "string", "create_comm_channel did not return a channel ID")
        assert(typeof(channel) == "Instance", "create_comm_channel did not return a channel instance")
        assert(channel:IsA("BindableEvent"), "Channel is not a BindableEvent")
    end, true)

TEST DE GETRAWMETATABLE:
    test("getrawmetatable", function()
        local mt = getrawmetatable(game)
        assert(typeof(mt) == "table", "getrawmetatable did not return a table")
        assert(mt.__index ~= nil, "Metatable does not have __index")
    end, true)

TEST DE HOOKMETAMETHOD:
    test("hookmetamethod", function()
        assert(typeof(hookmetamethod) == "function", "hookmetamethod is not a function")
        
        local object = setmetatable({}, {
            __index = newcclosure(function()
                return "original"
            end),
            __metatable = "Locked!",
        })
        
        local ref = hookmetamethod(object, "__index", function()
            return "hooked"
        end)
        
        assert(object.test == "hooked", "hookmetamethod did not hook the metamethod")
        assert(typeof(ref) == "function", "hookmetamethod did not return the original metamethod")
    end)

TEST DE GETNAMECALLMETHOD:
    test("getnamecallmethod", function()
        assert(typeof(getnamecallmethod) == "function", "getnamecallmethod is not a function")
        
        local method
        local object = setmetatable({}, {
            __namecall = function(self, ...)
                method = getnamecallmethod()
            end,
        })
        
        pcall(function()
            object:TestMethod()
        end)
        
        assert(method == "TestMethod", "getnamecallmethod did not return the correct method name")
    end, true)

TEST DE CHECKCALLER:
    test("checkcaller", function()
        assert(typeof(checkcaller) == "function", "checkcaller is not a function")
        assert(checkcaller() == true, "checkcaller should return true when called from executor")
    end, true)

TEST DE GETCALLINGSCRIPT:
    test("getcallingscript", function()
        assert(typeof(getcallingscript) == "function", "getcallingscript is not a function")
        local script = getcallingscript()
        assert(script == nil or typeof(script) == "Instance", "getcallingscript did not return nil or an Instance")
    end, true)

TEST DE ISEXECUTORCLOSURE:
    test("isexecutorclosure", function()
        assert(typeof(isexecutorclosure) == "function", "isexecutorclosure is not a function")
        
        local executorFunc = function() end
        assert(isexecutorclosure(executorFunc) == true, "isexecutorclosure should return true for executor closures")
        
        local gameFunc = game.GetService
        assert(isexecutorclosure(gameFunc) == false, "isexecutorclosure should return false for game functions")
    end, true)

TEST DE GETCONNECTIONS:
    test("getconnections", function()
        assert(typeof(getconnections) == "function", "getconnections is not a function")
        
        local event = Instance.new("BindableEvent")
        local connection = event.Event:Connect(function() end)
        
        local connections = getconnections(event.Event)
        assert(typeof(connections) == "table", "getconnections did not return a table")
        assert(#connections > 0, "getconnections did not return any connections")
        
        connection:Disconnect()
        event:Destroy()
    end, true)

TEST DE GETCALLBACKVALUE:
    test("getcallbackvalue", function()
        assert(typeof(getcallbackvalue) == "function", "getcallbackvalue is not a function")
        
        local bindable = Instance.new("BindableFunction")
        local callback = function() return "test" end
        bindable.OnInvoke = callback
        
        local success, result = pcall(getcallbackvalue, bindable, "OnInvoke")
        assert(success, "getcallbackvalue failed")
        assert(result == callback, "getcallbackvalue did not return the correct callback")
        
        bindable:Destroy()
    end, true)

TEST DE CLONEREF:
    test("cloneref", function()
        assert(typeof(cloneref) == "function", "cloneref is not a function")
        
        local original = game:GetService("Players")
        local cloned = cloneref(original)
        
        assert(typeof(cloned) == "Instance", "cloneref did not return an Instance")
        assert(cloned.ClassName == "Players", "cloneref did not clone the correct service")
        assert(cloned ~= original, "cloneref returned the same reference")
    end, true)

TEST DE COMPAREINSTANCES:
    test("compareinstances", function()
        assert(typeof(compareinstances) == "function", "compareinstances is not a function")
        
        local original = game:GetService("Players")
        local cloned = cloneref(original)
        
        assert(compareinstances(original, cloned) == true, "compareinstances should return true for cloned instances")
        assert(compareinstances(original, game:GetService("Workspace")) == false, "compareinstances should return false for different instances")
    end, true)


────────────────────────────────────────────────────────────────────
### IMPLEMENTACIÓN COMPLETA: SISTEMA DE HOOKING CON TODOS LOS FALLBACKS
────────────────────────────────────────────────────────────────────

El módulo Hooking de Cobalt es el más sofisticado. Aquí está la implementación
COMPLETA con todos los niveles de fallback:

    local Hooking = {}
    
    -- Variable global para modo alternativo (setreadonly + rawset)
    local AlternativeEnabled = false

    -- HookFunction con prioridad de métodos
    Hooking.HookFunction = function(Original, Replacement)
        -- PRIORIDAD 1: oth (One-Thread Hook)
        -- Solo si: oth disponible, Original es C closure, Replacement es L closure
        if wax.shared.ExecutorSupport["oth"].IsWorking
        and iscclosure(Original) and islclosure(Replacement) then
            return oth.hook(Original, Replacement)
        end

        -- PRIORIDAD 2: hookfunction clásico
        -- Siempre convertir Replacement a C closure antes de hookear
        if islclosure(Replacement) then
            Replacement = wax.shared.newcclosure(Replacement)
        end
        
        if not wax.shared.ExecutorSupport["hookfunction"].IsWorking then
            return Original  -- fallback silencioso, no crashea
        end
        
        return hookfunction(Original, Replacement)
    end

    -- HookMetaMethod con 4 niveles de fallback
    Hooking.HookMetaMethod = function(object, method, hook)
        local Metatable = wax.shared.getrawmetatable(object)
        local originalMethod = rawget(Metatable, method)

        -- PRIORIDAD 1: oth (más seguro)
        if wax.shared.ExecutorSupport["oth"].IsWorking then
            return oth.hook(originalMethod, hook)
        end

        -- Convertir hook a C closure si es L closure
        if islclosure(hook) then 
            hook = wax.shared.newcclosure(hook) 
        end

        -- PRIORIDAD 2: hookmetamethod nativo (si está disponible y no hay modo alternativo)
        -- PRIORIDAD 3: setreadonly + rawset (modo alternativo)
        if AlternativeEnabled
        or (not wax.shared.ExecutorSupport["hookmetamethod"].IsWorking
            and wax.shared.ExecutorSupport["getrawmetatable"].IsWorking) then
            
            setreadonly(Metatable, false)
            rawset(Metatable, method, hook)
            setreadonly(Metatable, true)
            return originalMethod
        end

        -- PRIORIDAD 4: xpcall trick — obtener metamétodo sin hookmetamethod
        -- Este es el método más avanzado: dispara el metamétodo intencionalmente
        -- y captura la función via debug.info
        if not wax.shared.ExecutorSupport["hookmetamethod"].IsWorking then
            if method == "__namecall" then
                local _, fn = xpcall(
                    function() 
                        -- Llamar método inexistente → dispara __namecall
                        object:Mustard() 
                    end,
                    function() 
                        -- Capturar la función del metamétodo
                        return debug.info(2, "f") 
                    end
                )
                return fn
            elseif method == "__newindex" then
                local _, fn = xpcall(
                    function() 
                        -- Asignar key random → dispara __newindex
                        object[tostring(math.random())] = true 
                    end,
                    function() 
                        return debug.info(2, "f") 
                    end
                )
                return fn
            elseif method == "__index" then
                local _, fn = xpcall(
                    function() 
                        -- Acceder key inexistente → dispara __index
                        local _ = object[tostring(math.random())] 
                    end,
                    function() 
                        return debug.info(2, "f") 
                    end
                )
                return fn
            end
            return nil
        end

        -- Si hookmetamethod está disponible, usarlo
        return hookmetamethod(object, method, hook)
    end

    return Hooking

LECCIÓN CLAVE sobre xpcall trick:
    -- xpcall(func, errorHandler) ejecuta func y si hay error, llama errorHandler
    -- En el errorHandler, debug.info(2, "f") retorna la función que causó el error
    -- Al disparar intencionalmente un metamétodo (ej: __namecall con método inexistente),
    -- el error handler captura la función del metamétodo
    -- Este es uno de los patrones más avanzados de Lua/Luau para introspección


────────────────────────────────────────────────────────────────────
### IMPLEMENTACIÓN COMPLETA: REMOTE SPY CON DUAL INTERCEPTION
────────────────────────────────────────────────────────────────────

Cobalt usa DOS sistemas simultáneos para interceptar TODAS las llamadas de red.
Aquí está la implementación completa de ambos:

SISTEMA 1 — METAMETHOD HOOKS (__namecall y __newindex):

    -- Lookup tables para optimización O(1)
    local function CreateLookupTable(t)
        local LookupTable = {}
        for _, v in next, t do
            LookupTable[v] = true
        end
        return LookupTable
    end

    local NamecallMethods = CreateLookupTable({
        "FireServer", "InvokeServer", "Fire", "Invoke",
        "fireServer", "invokeServer", "fire", "invoke",
    })

    local AllowedClassNames = CreateLookupTable({
        "RemoteEvent", "RemoteFunction", "UnreliableRemoteEvent",
        "BindableEvent", "BindableFunction"
    })

    -- Hook de __namecall para interceptar remote:FireServer(), etc.
    wax.shared.NamecallHook = wax.shared.Hooking.HookMetaMethod(game, "__namecall", function(...)
        local self = ...
        local Method = getnamecallmethod()

        if typeof(self) == "Instance"
        and AllowedClassNames[self.ClassName]
        and NamecallMethods[Method]
        and not rawequal(self, wax.shared.Communicator)
        and not rawequal(self, wax.shared.ActorCommunicator)
        and not wax.shared.ShouldIgnore(self, getcallingscript())
        then
            local Log = wax.shared.Logs.Outgoing[self]
            if not Log then
                Log = wax.shared.NewLog(self, "Outgoing", Method, getcallingscript())
            end

            if Log.Blocked then
                return  -- Bloquear la llamada completamente
            elseif not Log.Ignored then
                local Info = {
                    Arguments = table.pack(select(2, ...)),
                    Origin = getcallingscript(),
                    Function = getcallingfunction(),
                    Line = getcallingline(),
                    Source = getcallingsource(),
                    IsExecutor = checkcaller(),
                }
                Log:Call(Info)
                
                -- Para RemoteFunction, también loggear el return value
                if self.ClassName == "RemoteFunction" and (Method == "InvokeServer" or Method == "invokeServer") then
                    Log = wax.shared.Logs.Incoming[self]
                    if not Log then
                        Log = wax.shared.NewLog(self, "Incoming", Method, getcallingscript())
                    end

                    if Log.Blocked then
                        return
                    end

                    local Result = table.pack(wax.shared.NamecallHook(...))
                    if not Log.Ignored then
                        local RFResultInfo = {
                            Arguments = Result,
                            Origin = getcallingscript(),
                            Function = getcallingfunction(),
                            Line = getcallingline(),
                            Source = getcallingsource(),
                            IsExecutor = checkcaller(),
                            OriginalInvokeArgs = table.pack(select(2, ...)),
                        }
                        Log:Call(RFResultInfo)
                    end

                    return table.unpack(Result, 1, Result.n)
                end
            end
        end

        return wax.shared.NamecallHook(...)
    end)

    -- Hook de __newindex para interceptar asignaciones de callbacks
    wax.shared.NewIndexHook = wax.shared.Hooking.HookMetaMethod(game, "__newindex", function(...)
        local self, key, value = ...

        if typeof(self) ~= "Instance" or not AllowedClassNames[self.ClassName] then
            return wax.shared.NewIndexHook(...)
        end

        if self.ClassName == "RemoteFunction" or self.ClassName == "BindableFunction" then
            local Method = ClassesToHook[self.ClassName]

            local IsCallable = (
                typeof(value) == "function"
                or wax.shared.getrawmetatable(value) ~= nil and typeof(wax.shared.getrawmetatable(value)["__call"]) == "function"
                or false
            )

            if key == Method and IsCallable then
                return wax.shared.NewIndexHook(self, key, CreateCallbackDetour(self, Method, value))
            end
        end

        return wax.shared.NewIndexHook(...)
    end)

SISTEMA 2 — HOOKFUNCTION DIRECTO (para llamadas via Event.FireServer(Event, ...)):

    -- Truco: crear instancias temporales para obtener referencias a los métodos
    local FunctionsToHook
    do
        local BindableFunction = Instance.new("BindableFunction")
        local BindableEvent = Instance.new("BindableEvent")
        local RemoteFunction = Instance.new("RemoteFunction")
        local RemoteEvent = Instance.new("RemoteEvent")
        local UnreliableRemoteEvent = Instance.new("UnreliableRemoteEvent")

        FunctionsToHook = {
            BindableFunction.Invoke,
            BindableEvent.Fire,
            RemoteFunction.InvokeServer,
            RemoteEvent.FireServer,
            UnreliableRemoteEvent.FireServer,
        }

        -- Destruir las instancias pero las referencias a las funciones siguen vivas
        BindableFunction:Destroy()
        BindableEvent:Destroy()
        RemoteFunction:Destroy()
        RemoteEvent:Destroy()
        UnreliableRemoteEvent:Destroy()
    end

    for _, Function in next, FunctionsToHook do
        local Method = debug.info(Function, "n")

        wax.shared.Hooks[Function] = wax.shared.Hooking.HookFunction(Function, function(...)
            local self = ...

            if typeof(self) == "Instance"
            and AllowedClassNames[self.ClassName]
            and not rawequal(self, wax.shared.Communicator)
            and not wax.shared.ShouldIgnore(self, getcallingscript())
            then
                local Log = wax.shared.Logs.Outgoing[self]
                if not Log then
                    Log = wax.shared.NewLog(self, "Outgoing", Method, getcallingscript())
                end

                if Log.Blocked then
                    return
                elseif not Log.Ignored then
                    local Info = {
                        Arguments = table.pack(select(2, ...)),
                        Origin = getcallingscript(),
                        Function = getcallingfunction(),
                        Line = getcallingline(),
                        Source = getcallingsource(),
                        IsExecutor = checkcaller(),
                    }
                    Log:Call(Info)
                    
                    -- Para RemoteFunction, también loggear el return value
                    if self.ClassName == "RemoteFunction" and (Method == "InvokeServer" or Method == "invokeServer") then
                        Log = wax.shared.Logs.Incoming[self]
                        if not Log then
                            Log = wax.shared.NewLog(self, "Incoming", Method, getcallingscript())
                        end

                        if Log.Blocked then
                            return
                        end

                        local Result = table.pack(wax.shared.Hooks[Function](...))
                        if not Log.Ignored then
                            local RFResultInfo = {
                                Arguments = Result,
                                Origin = getcallingscript(),
                                Function = getcallingfunction(),
                                Line = getcallingline(),
                                Source = getcallingsource(),
                                IsExecutor = checkcaller(),
                                OriginalInvokeArgs = table.pack(select(2, ...)),
                            }
                            Log:Call(RFResultInfo)
                        end

                        return table.unpack(Result, 1, Result.n)
                    end
                end
            end

            return wax.shared.Hooks[Function](...)
        end)
    end

LECCIÓN: ¿Por qué DOS sistemas?
    -- Método 1 (__namecall): captura remote:FireServer()
    -- Método 2 (hookfunction): captura RemoteEvent.FireServer(remote)
    -- Algunos scripts usan uno, otros usan el otro
    -- Cobalt usa ambos para no perder NINGUNA llamada


────────────────────────────────────────────────────────────────────
## PATRONES AVANZADOS DE COBALT — PARTE $i
────────────────────────────────────────────────────────────────────

### PATRÓN: DETECCIÓN Y MANEJO DE INCOMING REMOTES

Cobalt intercepta llamadas entrantes (Server → Client) usando getconnections():

    local ClassesToHook = {
        RemoteEvent = "OnClientEvent",
        RemoteFunction = "OnClientInvoke",
        UnreliableRemoteEvent = "OnClientEvent",
        BindableEvent = "Event",
        BindableFunction = "OnInvoke",
    }

    local LogConnectionFunctions = {}
    local SignalMapping = setmetatable({}, { __mode = "kv" })

    local function CreateConnectionFunction(Instance, Method)
        local ConnectionFunction = function(...)
            for _, Connection in getconnections((Instance :: any)[Method]) do
                if Connection.ForeignState then
                    continue  -- Skip executor connections
                end

                local Function = typeof(Connection.Function) == "function" and Connection.Function or nil
                local Thread = Connection.Thread

                local Origin = nil

                -- Método confiable: getscriptfromthread
                if Thread and getscriptfromthread then
                    Origin = getscriptfromthread(Thread)
                end

                -- Método de respaldo (menos confiable):
                if not Origin and Function then
                    local Script = rawget(getfenv(Function), "script")
                    if typeof(Script) == "Instance" then
                        Origin = Script
                    end
                end

                LogRemote(Instance, Method, Function, {
                    Arguments = table.pack(...),
                    Origin = Origin,
                    Function = Function,
                    Line = nil,
                    IsExecutor = Function and isexecutorclosure(Function) or false,
                })
            end
        end

        LogConnectionFunctions[ConnectionFunction] = true
        return ConnectionFunction
    end

    local function CreateCallbackDetour(Instance, Method, Callback)
        local Detour = function(...)
            local Origin = nil

            if getscriptfromthread then
                Origin = getscriptfromthread(coroutine.running())
            end

            if not Origin then
                local Script = rawget(getfenv(Callback), "script")
                if typeof(Script) == "Instance" then
                    Origin = Script
                end
            end

            local FunctionCaller = debug.info(2, "f")
            local IsExecutor = if typeof(FunctionCaller) == "function"
                then isexecutorclosure(FunctionCaller)
                else isexecutorclosure(Callback)

            if LogRemote(Instance, Method, Callback, {
                Arguments = table.pack(...),
                Origin = Origin,
                Function = Callback,
                Line = nil,
                IsExecutor = IsExecutor,
            }) then
                return  -- Bloqueado
            end

            return Callback(...)
        end

        if wax.shared.ExecutorSupport["setstackhidden"].IsWorking then
            setstackhidden(Detour, true)
        end

        return Detour
    end

    local function HandleInstance(Instance)
        if not ClassesToHook[Instance.ClassName]
        or Instance == wax.shared.Communicator
        or Instance == wax.shared.ActorCommunicator
        then
            return
        end

        local Method = ClassesToHook[Instance.ClassName]

        if Instance.ClassName == "RemoteEvent" or Instance.ClassName == "UnreliableRemoteEvent" then
            wax.shared.Connect(Instance.OnClientEvent:Connect(CreateConnectionFunction(Instance, Method)))
            SignalMapping[Instance.OnClientEvent] = Instance
        elseif Instance.ClassName == "BindableEvent" then
            wax.shared.Connect(Instance.Event:Connect(CreateConnectionFunction(Instance, Method)))
            SignalMapping[Instance.Event] = Instance
        elseif Instance.ClassName == "RemoteFunction" or Instance.ClassName == "BindableFunction" then
            local Success, Callback = pcall(getcallbackvalue, Instance, Method)
            local IsCallable = (
                typeof(Callback) == "function"
                or wax.shared.getrawmetatable(Callback) ~= nil and typeof(wax.shared.getrawmetatable(Callback)["__call"]) == "function"
                or false
            )

            if not Success or not IsCallable then
                return
            end

            Instance[Method] = CreateCallbackDetour(Instance, Method, Callback)
        end
    end

    -- Hookear todas las instancias existentes
    wax.shared.Connect(game.DescendantAdded:Connect(HandleInstance))

    local CategoryToSearch = { game:QueryDescendants("RemoteEvent, RemoteFunction, UnreliableRemoteEvent, BindableEvent, BindableFunction") }
    if wax.shared.ExecutorSupport["getnilinstances"].IsWorking then
        table.insert(CategoryToSearch, getnilinstances())
    end

    for _, Category in CategoryToSearch do
        for _, Instance in next, Category do
            HandleInstance(Instance)
        end
    end


### PATRÓN: HOOK DE SIGNAL CONNECT

Cobalt también hookea el método Connect de signals para detectar cuando se bloquea:

    local ConnectionKeys = CreateLookupTable({
        "Connect",
        "ConnectParallel",
        "connect",
        "connectParallel",
        "Once",
    })

    local SignalMetatable = wax.shared.getrawmetatable(Instance.new("Part").Touched)
    
    wax.shared.Hooks[SignalMetatable.__index] = wax.shared.Hooking.HookFunction(SignalMetatable.__index, function(...)
        local self, key = ...

        if not wax.shared.Unloaded and ConnectionKeys[key] then
            local Instance = SignalMapping[self]
            local Connect = wax.shared.Hooks[SignalMetatable.__index](...)

            if not Instance then
                return Connect
            end

            local Method = ClassesToHook[Instance.ClassName]
            return wax.shared.newcclosure(function(...)
                local _self, callback = ...

                local Result = table.pack(Connect(...))
                local Log = wax.shared.Logs.Incoming[Instance]

                if Log and Log.Blocked then
                    for _, Connection in getconnections(Instance[Method]) do
                        if not Connection.ForeignState and Connection.Function ~= callback then
                            continue
                        end

                        Connection:Disable()
                    end
                end

                return table.unpack(Result, 1, Result.n)
            end, debug.info(Connect, "n"))
        end

        return wax.shared.Hooks[SignalMetatable.__index](...)
    end)


### PATRÓN: UTILIDADES HELPER DE COBALT

    wax.shared.IsPlayerModule = function(Origin, Instance)
        if Instance and Instance.ClassName ~= "BindableEvent" then
            return false
        end

        if not Origin or typeof(Origin) ~= "Instance" or not Origin.IsA(Origin, "LuaSourceContainer") then
            return false
        end

        local PlayerModule = Origin and Origin.FindFirstAncestor(Origin, "PlayerModule") or nil
        if not PlayerModule then
            return false
        end

        if PlayerModule.Parent == nil then
            return true
        end

        return compareinstances(PlayerModule.Parent, wax.shared.PlayerScripts)
    end

    wax.shared.ShouldIgnore = function(Instance, Origin)
        return wax.shared.Settings.IgnoredRemotesDropdown.Value[Instance.ClassName] == true
            or (wax.shared.Settings.IgnorePlayerModule.Value and wax.shared.IsPlayerModule(Origin, Instance))
    end

    wax.shared.GetTableLength = function(Table)
        if Table["n"] then
            return Table.n
        end

        local Length = 0
        for _, _ in pairs(Table) do
            Length += 1
        end
        return Length
    end

    wax.shared.JoinTable = function(Table, Prefix, Suffix)
        local FinalString = ""
        for _, Value in pairs(Table) do
            FinalString ..= Prefix .. tostring(Value) .. Suffix
        end

        FinalString = string.sub(FinalString, 1, string.len(FinalString) - string.len(Suffix))

        return FinalString
    end

    wax.shared.GetTextBounds = function(Text, Font, Size, Width)
        local Params = Instance.new("GetTextBoundsParams")
        Params.Text = Text
        Params.RichText = true
        Params.Font = Font
        Params.Size = Size
        Params.Width = Width or workspace.CurrentCamera.ViewportSize.X - 32

        local Bounds = wax.shared.TextService:GetTextBoundsAsync(Params)
        Params:Destroy()
        
        return Bounds.X, Bounds.Y
    end


### PATRÓN: NEWCCLOSURE CUSTOM PARA AWP EXECUTOR

AWP executor tiene un bug en newcclosure. Cobalt implementa un workaround:

    wax.shared.newcclosure = wax.shared.ExecutorName == "AWP"
        and function(f, name)
            local env = getfenv(f)
            local x = setmetatable({
                __F = f,
            }, {
                __index = env,
                __newindex = env,
            })

            local nf = function(...)
                return __F(...)
            end

            setfenv(nf, x)  -- set func env (env of nf gets deoptimized)
            return newcclosure(nf, name)
        end
    or newcclosure


### PATRÓN: FALLBACKS PARA FUNCIONES OPCIONALES

    wax.shared.queue_on_teleport = queue_on_teleport or queueonteleport or function(...) end

    wax.shared.gethui = gethui or function()
        return wax.shared.CoreGui
    end

    wax.shared.checkcaller = checkcaller or function()
        return nil
    end

    wax.shared.getrawmetatable = wax.shared.ExecutorSupport["getrawmetatable"].IsWorking
        and (getrawmetatable or debug.getmetatable)
        or function()
            return setmetatable({}, {
                __index = function()
                    return function() end
                end,
            })
        end

    wax.shared.restorefunction = function(Function, Silent)
        local Original = wax.shared.Hooks[Function]

        if Silent and not Original then
            return
        end

        assert(Original, "Function not hooked")

        if restorefunction and isfunctionhooked(Function) then
            restorefunction(Function)
        else
            wax.shared.Hooking.HookFunction(Function, Original)
        end

        wax.shared.Hooks[Function] = nil
    end


────────────────────────────────────────────────────────────────────
## PATRONES AVANZADOS DE COBALT — PARTE $i
────────────────────────────────────────────────────────────────────

### PATRÓN: DETECCIÓN Y MANEJO DE INCOMING REMOTES

Cobalt intercepta llamadas entrantes (Server → Client) usando getconnections():

    local ClassesToHook = {
        RemoteEvent = "OnClientEvent",
        RemoteFunction = "OnClientInvoke",
        UnreliableRemoteEvent = "OnClientEvent",
        BindableEvent = "Event",
        BindableFunction = "OnInvoke",
    }

    local LogConnectionFunctions = {}
    local SignalMapping = setmetatable({}, { __mode = "kv" })

    local function CreateConnectionFunction(Instance, Method)
        local ConnectionFunction = function(...)
            for _, Connection in getconnections((Instance :: any)[Method]) do
                if Connection.ForeignState then
                    continue  -- Skip executor connections
                end

                local Function = typeof(Connection.Function) == "function" and Connection.Function or nil
                local Thread = Connection.Thread

                local Origin = nil

                -- Método confiable: getscriptfromthread
                if Thread and getscriptfromthread then
                    Origin = getscriptfromthread(Thread)
                end

                -- Método de respaldo (menos confiable):
                if not Origin and Function then
                    local Script = rawget(getfenv(Function), "script")
                    if typeof(Script) == "Instance" then
                        Origin = Script
                    end
                end

                LogRemote(Instance, Method, Function, {
                    Arguments = table.pack(...),
                    Origin = Origin,
                    Function = Function,
                    Line = nil,
                    IsExecutor = Function and isexecutorclosure(Function) or false,
                })
            end
        end

        LogConnectionFunctions[ConnectionFunction] = true
        return ConnectionFunction
    end

    local function CreateCallbackDetour(Instance, Method, Callback)
        local Detour = function(...)
            local Origin = nil

            if getscriptfromthread then
                Origin = getscriptfromthread(coroutine.running())
            end

            if not Origin then
                local Script = rawget(getfenv(Callback), "script")
                if typeof(Script) == "Instance" then
                    Origin = Script
                end
            end

            local FunctionCaller = debug.info(2, "f")
            local IsExecutor = if typeof(FunctionCaller) == "function"
                then isexecutorclosure(FunctionCaller)
                else isexecutorclosure(Callback)

            if LogRemote(Instance, Method, Callback, {
                Arguments = table.pack(...),
                Origin = Origin,
                Function = Callback,
                Line = nil,
                IsExecutor = IsExecutor,
            }) then
                return  -- Bloqueado
            end

            return Callback(...)
        end

        if wax.shared.ExecutorSupport["setstackhidden"].IsWorking then
            setstackhidden(Detour, true)
        end

        return Detour
    end

    local function HandleInstance(Instance)
        if not ClassesToHook[Instance.ClassName]
        or Instance == wax.shared.Communicator
        or Instance == wax.shared.ActorCommunicator
        then
            return
        end

        local Method = ClassesToHook[Instance.ClassName]

        if Instance.ClassName == "RemoteEvent" or Instance.ClassName == "UnreliableRemoteEvent" then
            wax.shared.Connect(Instance.OnClientEvent:Connect(CreateConnectionFunction(Instance, Method)))
            SignalMapping[Instance.OnClientEvent] = Instance
        elseif Instance.ClassName == "BindableEvent" then
            wax.shared.Connect(Instance.Event:Connect(CreateConnectionFunction(Instance, Method)))
            SignalMapping[Instance.Event] = Instance
        elseif Instance.ClassName == "RemoteFunction" or Instance.ClassName == "BindableFunction" then
            local Success, Callback = pcall(getcallbackvalue, Instance, Method)
            local IsCallable = (
                typeof(Callback) == "function"
                or wax.shared.getrawmetatable(Callback) ~= nil and typeof(wax.shared.getrawmetatable(Callback)["__call"]) == "function"
                or false
            )

            if not Success or not IsCallable then
                return
            end

            Instance[Method] = CreateCallbackDetour(Instance, Method, Callback)
        end
    end

    -- Hookear todas las instancias existentes
    wax.shared.Connect(game.DescendantAdded:Connect(HandleInstance))

    local CategoryToSearch = { game:QueryDescendants("RemoteEvent, RemoteFunction, UnreliableRemoteEvent, BindableEvent, BindableFunction") }
    if wax.shared.ExecutorSupport["getnilinstances"].IsWorking then
        table.insert(CategoryToSearch, getnilinstances())
    end

    for _, Category in CategoryToSearch do
        for _, Instance in next, Category do
            HandleInstance(Instance)
        end
    end


### PATRÓN: HOOK DE SIGNAL CONNECT

Cobalt también hookea el método Connect de signals para detectar cuando se bloquea:

    local ConnectionKeys = CreateLookupTable({
        "Connect",
        "ConnectParallel",
        "connect",
        "connectParallel",
        "Once",
    })

    local SignalMetatable = wax.shared.getrawmetatable(Instance.new("Part").Touched)
    
    wax.shared.Hooks[SignalMetatable.__index] = wax.shared.Hooking.HookFunction(SignalMetatable.__index, function(...)
        local self, key = ...

        if not wax.shared.Unloaded and ConnectionKeys[key] then
            local Instance = SignalMapping[self]
            local Connect = wax.shared.Hooks[SignalMetatable.__index](...)

            if not Instance then
                return Connect
            end

            local Method = ClassesToHook[Instance.ClassName]
            return wax.shared.newcclosure(function(...)
                local _self, callback = ...

                local Result = table.pack(Connect(...))
                local Log = wax.shared.Logs.Incoming[Instance]

                if Log and Log.Blocked then
                    for _, Connection in getconnections(Instance[Method]) do
                        if not Connection.ForeignState and Connection.Function ~= callback then
                            continue
                        end

                        Connection:Disable()
                    end
                end

                return table.unpack(Result, 1, Result.n)
            end, debug.info(Connect, "n"))
        end

        return wax.shared.Hooks[SignalMetatable.__index](...)
    end)


### PATRÓN: UTILIDADES HELPER DE COBALT

    wax.shared.IsPlayerModule = function(Origin, Instance)
        if Instance and Instance.ClassName ~= "BindableEvent" then
            return false
        end

        if not Origin or typeof(Origin) ~= "Instance" or not Origin.IsA(Origin, "LuaSourceContainer") then
            return false
        end

        local PlayerModule = Origin and Origin.FindFirstAncestor(Origin, "PlayerModule") or nil
        if not PlayerModule then
            return false
        end

        if PlayerModule.Parent == nil then
            return true
        end

        return compareinstances(PlayerModule.Parent, wax.shared.PlayerScripts)
    end

    wax.shared.ShouldIgnore = function(Instance, Origin)
        return wax.shared.Settings.IgnoredRemotesDropdown.Value[Instance.ClassName] == true
            or (wax.shared.Settings.IgnorePlayerModule.Value and wax.shared.IsPlayerModule(Origin, Instance))
    end

    wax.shared.GetTableLength = function(Table)
        if Table["n"] then
            return Table.n
        end

        local Length = 0
        for _, _ in pairs(Table) do
            Length += 1
        end
        return Length
    end

    wax.shared.JoinTable = function(Table, Prefix, Suffix)
        local FinalString = ""
        for _, Value in pairs(Table) do
            FinalString ..= Prefix .. tostring(Value) .. Suffix
        end

        FinalString = string.sub(FinalString, 1, string.len(FinalString) - string.len(Suffix))

        return FinalString
    end

    wax.shared.GetTextBounds = function(Text, Font, Size, Width)
        local Params = Instance.new("GetTextBoundsParams")
        Params.Text = Text
        Params.RichText = true
        Params.Font = Font
        Params.Size = Size
        Params.Width = Width or workspace.CurrentCamera.ViewportSize.X - 32

        local Bounds = wax.shared.TextService:GetTextBoundsAsync(Params)
        Params:Destroy()
        
        return Bounds.X, Bounds.Y
    end


### PATRÓN: NEWCCLOSURE CUSTOM PARA AWP EXECUTOR

AWP executor tiene un bug en newcclosure. Cobalt implementa un workaround:

    wax.shared.newcclosure = wax.shared.ExecutorName == "AWP"
        and function(f, name)
            local env = getfenv(f)
            local x = setmetatable({
                __F = f,
            }, {
                __index = env,
                __newindex = env,
            })

            local nf = function(...)
                return __F(...)
            end

            setfenv(nf, x)  -- set func env (env of nf gets deoptimized)
            return newcclosure(nf, name)
        end
    or newcclosure


### PATRÓN: FALLBACKS PARA FUNCIONES OPCIONALES

    wax.shared.queue_on_teleport = queue_on_teleport or queueonteleport or function(...) end

    wax.shared.gethui = gethui or function()
        return wax.shared.CoreGui
    end

    wax.shared.checkcaller = checkcaller or function()
        return nil
    end

    wax.shared.getrawmetatable = wax.shared.ExecutorSupport["getrawmetatable"].IsWorking
        and (getrawmetatable or debug.getmetatable)
        or function()
            return setmetatable({}, {
                __index = function()
                    return function() end
                end,
            })
        end

    wax.shared.restorefunction = function(Function, Silent)
        local Original = wax.shared.Hooks[Function]

        if Silent and not Original then
            return
        end

        assert(Original, "Function not hooked")

        if restorefunction and isfunctionhooked(Function) then
            restorefunction(Function)
        else
            wax.shared.Hooking.HookFunction(Function, Original)
        end

        wax.shared.Hooks[Function] = nil
    end


────────────────────────────────────────────────────────────────────
## PATRONES AVANZADOS DE COBALT — PARTE $i
────────────────────────────────────────────────────────────────────

### PATRÓN: DETECCIÓN Y MANEJO DE INCOMING REMOTES

Cobalt intercepta llamadas entrantes (Server → Client) usando getconnections():

    local ClassesToHook = {
        RemoteEvent = "OnClientEvent",
        RemoteFunction = "OnClientInvoke",
        UnreliableRemoteEvent = "OnClientEvent",
        BindableEvent = "Event",
        BindableFunction = "OnInvoke",
    }

    local LogConnectionFunctions = {}
    local SignalMapping = setmetatable({}, { __mode = "kv" })

    local function CreateConnectionFunction(Instance, Method)
        local ConnectionFunction = function(...)
            for _, Connection in getconnections((Instance :: any)[Method]) do
                if Connection.ForeignState then
                    continue  -- Skip executor connections
                end

                local Function = typeof(Connection.Function) == "function" and Connection.Function or nil
                local Thread = Connection.Thread

                local Origin = nil

                -- Método confiable: getscriptfromthread
                if Thread and getscriptfromthread then
                    Origin = getscriptfromthread(Thread)
                end

                -- Método de respaldo (menos confiable):
                if not Origin and Function then
                    local Script = rawget(getfenv(Function), "script")
                    if typeof(Script) == "Instance" then
                        Origin = Script
                    end
                end

                LogRemote(Instance, Method, Function, {
                    Arguments = table.pack(...),
                    Origin = Origin,
                    Function = Function,
                    Line = nil,
                    IsExecutor = Function and isexecutorclosure(Function) or false,
                })
            end
        end

        LogConnectionFunctions[ConnectionFunction] = true
        return ConnectionFunction
    end

    local function CreateCallbackDetour(Instance, Method, Callback)
        local Detour = function(...)
            local Origin = nil

            if getscriptfromthread then
                Origin = getscriptfromthread(coroutine.running())
            end

            if not Origin then
                local Script = rawget(getfenv(Callback), "script")
                if typeof(Script) == "Instance" then
                    Origin = Script
                end
            end

            local FunctionCaller = debug.info(2, "f")
            local IsExecutor = if typeof(FunctionCaller) == "function"
                then isexecutorclosure(FunctionCaller)
                else isexecutorclosure(Callback)

            if LogRemote(Instance, Method, Callback, {
                Arguments = table.pack(...),
                Origin = Origin,
                Function = Callback,
                Line = nil,
                IsExecutor = IsExecutor,
            }) then
                return  -- Bloqueado
            end

            return Callback(...)
        end

        if wax.shared.ExecutorSupport["setstackhidden"].IsWorking then
            setstackhidden(Detour, true)
        end

        return Detour
    end

    local function HandleInstance(Instance)
        if not ClassesToHook[Instance.ClassName]
        or Instance == wax.shared.Communicator
        or Instance == wax.shared.ActorCommunicator
        then
            return
        end

        local Method = ClassesToHook[Instance.ClassName]

        if Instance.ClassName == "RemoteEvent" or Instance.ClassName == "UnreliableRemoteEvent" then
            wax.shared.Connect(Instance.OnClientEvent:Connect(CreateConnectionFunction(Instance, Method)))
            SignalMapping[Instance.OnClientEvent] = Instance
        elseif Instance.ClassName == "BindableEvent" then
            wax.shared.Connect(Instance.Event:Connect(CreateConnectionFunction(Instance, Method)))
            SignalMapping[Instance.Event] = Instance
        elseif Instance.ClassName == "RemoteFunction" or Instance.ClassName == "BindableFunction" then
            local Success, Callback = pcall(getcallbackvalue, Instance, Method)
            local IsCallable = (
                typeof(Callback) == "function"
                or wax.shared.getrawmetatable(Callback) ~= nil and typeof(wax.shared.getrawmetatable(Callback)["__call"]) == "function"
                or false
            )

            if not Success or not IsCallable then
                return
            end

            Instance[Method] = CreateCallbackDetour(Instance, Method, Callback)
        end
    end

    -- Hookear todas las instancias existentes
    wax.shared.Connect(game.DescendantAdded:Connect(HandleInstance))

    local CategoryToSearch = { game:QueryDescendants("RemoteEvent, RemoteFunction, UnreliableRemoteEvent, BindableEvent, BindableFunction") }
    if wax.shared.ExecutorSupport["getnilinstances"].IsWorking then
        table.insert(CategoryToSearch, getnilinstances())
    end

    for _, Category in CategoryToSearch do
        for _, Instance in next, Category do
            HandleInstance(Instance)
        end
    end


### PATRÓN: HOOK DE SIGNAL CONNECT

Cobalt también hookea el método Connect de signals para detectar cuando se bloquea:

    local ConnectionKeys = CreateLookupTable({
        "Connect",
        "ConnectParallel",
        "connect",
        "connectParallel",
        "Once",
    })

    local SignalMetatable = wax.shared.getrawmetatable(Instance.new("Part").Touched)
    
    wax.shared.Hooks[SignalMetatable.__index] = wax.shared.Hooking.HookFunction(SignalMetatable.__index, function(...)
        local self, key = ...

        if not wax.shared.Unloaded and ConnectionKeys[key] then
            local Instance = SignalMapping[self]
            local Connect = wax.shared.Hooks[SignalMetatable.__index](...)

            if not Instance then
                return Connect
            end

            local Method = ClassesToHook[Instance.ClassName]
            return wax.shared.newcclosure(function(...)
                local _self, callback = ...

                local Result = table.pack(Connect(...))
                local Log = wax.shared.Logs.Incoming[Instance]

                if Log and Log.Blocked then
                    for _, Connection in getconnections(Instance[Method]) do
                        if not Connection.ForeignState and Connection.Function ~= callback then
                            continue
                        end

                        Connection:Disable()
                    end
                end

                return table.unpack(Result, 1, Result.n)
            end, debug.info(Connect, "n"))
        end

        return wax.shared.Hooks[SignalMetatable.__index](...)
    end)


### PATRÓN: UTILIDADES HELPER DE COBALT

    wax.shared.IsPlayerModule = function(Origin, Instance)
        if Instance and Instance.ClassName ~= "BindableEvent" then
            return false
        end

        if not Origin or typeof(Origin) ~= "Instance" or not Origin.IsA(Origin, "LuaSourceContainer") then
            return false
        end

        local PlayerModule = Origin and Origin.FindFirstAncestor(Origin, "PlayerModule") or nil
        if not PlayerModule then
            return false
        end

        if PlayerModule.Parent == nil then
            return true
        end

        return compareinstances(PlayerModule.Parent, wax.shared.PlayerScripts)
    end

    wax.shared.ShouldIgnore = function(Instance, Origin)
        return wax.shared.Settings.IgnoredRemotesDropdown.Value[Instance.ClassName] == true
            or (wax.shared.Settings.IgnorePlayerModule.Value and wax.shared.IsPlayerModule(Origin, Instance))
    end

    wax.shared.GetTableLength = function(Table)
        if Table["n"] then
            return Table.n
        end

        local Length = 0
        for _, _ in pairs(Table) do
            Length += 1
        end
        return Length
    end

    wax.shared.JoinTable = function(Table, Prefix, Suffix)
        local FinalString = ""
        for _, Value in pairs(Table) do
            FinalString ..= Prefix .. tostring(Value) .. Suffix
        end

        FinalString = string.sub(FinalString, 1, string.len(FinalString) - string.len(Suffix))

        return FinalString
    end

    wax.shared.GetTextBounds = function(Text, Font, Size, Width)
        local Params = Instance.new("GetTextBoundsParams")
        Params.Text = Text
        Params.RichText = true
        Params.Font = Font
        Params.Size = Size
        Params.Width = Width or workspace.CurrentCamera.ViewportSize.X - 32

        local Bounds = wax.shared.TextService:GetTextBoundsAsync(Params)
        Params:Destroy()
        
        return Bounds.X, Bounds.Y
    end


### PATRÓN: NEWCCLOSURE CUSTOM PARA AWP EXECUTOR

AWP executor tiene un bug en newcclosure. Cobalt implementa un workaround:

    wax.shared.newcclosure = wax.shared.ExecutorName == "AWP"
        and function(f, name)
            local env = getfenv(f)
            local x = setmetatable({
                __F = f,
            }, {
                __index = env,
                __newindex = env,
            })

            local nf = function(...)
                return __F(...)
            end

            setfenv(nf, x)  -- set func env (env of nf gets deoptimized)
            return newcclosure(nf, name)
        end
    or newcclosure


### PATRÓN: FALLBACKS PARA FUNCIONES OPCIONALES

    wax.shared.queue_on_teleport = queue_on_teleport or queueonteleport or function(...) end

    wax.shared.gethui = gethui or function()
        return wax.shared.CoreGui
    end

    wax.shared.checkcaller = checkcaller or function()
        return nil
    end

    wax.shared.getrawmetatable = wax.shared.ExecutorSupport["getrawmetatable"].IsWorking
        and (getrawmetatable or debug.getmetatable)
        or function()
            return setmetatable({}, {
                __index = function()
                    return function() end
                end,
            })
        end

    wax.shared.restorefunction = function(Function, Silent)
        local Original = wax.shared.Hooks[Function]

        if Silent and not Original then
            return
        end

        assert(Original, "Function not hooked")

        if restorefunction and isfunctionhooked(Function) then
            restorefunction(Function)
        else
            wax.shared.Hooking.HookFunction(Function, Original)
        end

        wax.shared.Hooks[Function] = nil
    end


────────────────────────────────────────────────────────────────────
## PATRONES AVANZADOS DE COBALT — PARTE $i
────────────────────────────────────────────────────────────────────

### PATRÓN: DETECCIÓN Y MANEJO DE INCOMING REMOTES

Cobalt intercepta llamadas entrantes (Server → Client) usando getconnections():

    local ClassesToHook = {
        RemoteEvent = "OnClientEvent",
        RemoteFunction = "OnClientInvoke",
        UnreliableRemoteEvent = "OnClientEvent",
        BindableEvent = "Event",
        BindableFunction = "OnInvoke",
    }

    local LogConnectionFunctions = {}
    local SignalMapping = setmetatable({}, { __mode = "kv" })

    local function CreateConnectionFunction(Instance, Method)
        local ConnectionFunction = function(...)
            for _, Connection in getconnections((Instance :: any)[Method]) do
                if Connection.ForeignState then
                    continue  -- Skip executor connections
                end

                local Function = typeof(Connection.Function) == "function" and Connection.Function or nil
                local Thread = Connection.Thread

                local Origin = nil

                -- Método confiable: getscriptfromthread
                if Thread and getscriptfromthread then
                    Origin = getscriptfromthread(Thread)
                end

                -- Método de respaldo (menos confiable):
                if not Origin and Function then
                    local Script = rawget(getfenv(Function), "script")
                    if typeof(Script) == "Instance" then
                        Origin = Script
                    end
                end

                LogRemote(Instance, Method, Function, {
                    Arguments = table.pack(...),
                    Origin = Origin,
                    Function = Function,
                    Line = nil,
                    IsExecutor = Function and isexecutorclosure(Function) or false,
                })
            end
        end

        LogConnectionFunctions[ConnectionFunction] = true
        return ConnectionFunction
    end

    local function CreateCallbackDetour(Instance, Method, Callback)
        local Detour = function(...)
            local Origin = nil

            if getscriptfromthread then
                Origin = getscriptfromthread(coroutine.running())
            end

            if not Origin then
                local Script = rawget(getfenv(Callback), "script")
                if typeof(Script) == "Instance" then
                    Origin = Script
                end
            end

            local FunctionCaller = debug.info(2, "f")
            local IsExecutor = if typeof(FunctionCaller) == "function"
                then isexecutorclosure(FunctionCaller)
                else isexecutorclosure(Callback)

            if LogRemote(Instance, Method, Callback, {
                Arguments = table.pack(...),
                Origin = Origin,
                Function = Callback,
                Line = nil,
                IsExecutor = IsExecutor,
            }) then
                return  -- Bloqueado
            end

            return Callback(...)
        end

        if wax.shared.ExecutorSupport["setstackhidden"].IsWorking then
            setstackhidden(Detour, true)
        end

        return Detour
    end

    local function HandleInstance(Instance)
        if not ClassesToHook[Instance.ClassName]
        or Instance == wax.shared.Communicator
        or Instance == wax.shared.ActorCommunicator
        then
            return
        end

        local Method = ClassesToHook[Instance.ClassName]

        if Instance.ClassName == "RemoteEvent" or Instance.ClassName == "UnreliableRemoteEvent" then
            wax.shared.Connect(Instance.OnClientEvent:Connect(CreateConnectionFunction(Instance, Method)))
            SignalMapping[Instance.OnClientEvent] = Instance
        elseif Instance.ClassName == "BindableEvent" then
            wax.shared.Connect(Instance.Event:Connect(CreateConnectionFunction(Instance, Method)))
            SignalMapping[Instance.Event] = Instance
        elseif Instance.ClassName == "RemoteFunction" or Instance.ClassName == "BindableFunction" then
            local Success, Callback = pcall(getcallbackvalue, Instance, Method)
            local IsCallable = (
                typeof(Callback) == "function"
                or wax.shared.getrawmetatable(Callback) ~= nil and typeof(wax.shared.getrawmetatable(Callback)["__call"]) == "function"
                or false
            )

            if not Success or not IsCallable then
                return
            end

            Instance[Method] = CreateCallbackDetour(Instance, Method, Callback)
        end
    end

    -- Hookear todas las instancias existentes
    wax.shared.Connect(game.DescendantAdded:Connect(HandleInstance))

    local CategoryToSearch = { game:QueryDescendants("RemoteEvent, RemoteFunction, UnreliableRemoteEvent, BindableEvent, BindableFunction") }
    if wax.shared.ExecutorSupport["getnilinstances"].IsWorking then
        table.insert(CategoryToSearch, getnilinstances())
    end

    for _, Category in CategoryToSearch do
        for _, Instance in next, Category do
            HandleInstance(Instance)
        end
    end


### PATRÓN: HOOK DE SIGNAL CONNECT

Cobalt también hookea el método Connect de signals para detectar cuando se bloquea:

    local ConnectionKeys = CreateLookupTable({
        "Connect",
        "ConnectParallel",
        "connect",
        "connectParallel",
        "Once",
    })

    local SignalMetatable = wax.shared.getrawmetatable(Instance.new("Part").Touched)
    
    wax.shared.Hooks[SignalMetatable.__index] = wax.shared.Hooking.HookFunction(SignalMetatable.__index, function(...)
        local self, key = ...

        if not wax.shared.Unloaded and ConnectionKeys[key] then
            local Instance = SignalMapping[self]
            local Connect = wax.shared.Hooks[SignalMetatable.__index](...)

            if not Instance then
                return Connect
            end

            local Method = ClassesToHook[Instance.ClassName]
            return wax.shared.newcclosure(function(...)
                local _self, callback = ...

                local Result = table.pack(Connect(...))
                local Log = wax.shared.Logs.Incoming[Instance]

                if Log and Log.Blocked then
                    for _, Connection in getconnections(Instance[Method]) do
                        if not Connection.ForeignState and Connection.Function ~= callback then
                            continue
                        end

                        Connection:Disable()
                    end
                end

                return table.unpack(Result, 1, Result.n)
            end, debug.info(Connect, "n"))
        end

        return wax.shared.Hooks[SignalMetatable.__index](...)
    end)


### PATRÓN: UTILIDADES HELPER DE COBALT

    wax.shared.IsPlayerModule = function(Origin, Instance)
        if Instance and Instance.ClassName ~= "BindableEvent" then
            return false
        end

        if not Origin or typeof(Origin) ~= "Instance" or not Origin.IsA(Origin, "LuaSourceContainer") then
            return false
        end

        local PlayerModule = Origin and Origin.FindFirstAncestor(Origin, "PlayerModule") or nil
        if not PlayerModule then
            return false
        end

        if PlayerModule.Parent == nil then
            return true
        end

        return compareinstances(PlayerModule.Parent, wax.shared.PlayerScripts)
    end

    wax.shared.ShouldIgnore = function(Instance, Origin)
        return wax.shared.Settings.IgnoredRemotesDropdown.Value[Instance.ClassName] == true
            or (wax.shared.Settings.IgnorePlayerModule.Value and wax.shared.IsPlayerModule(Origin, Instance))
    end

    wax.shared.GetTableLength = function(Table)
        if Table["n"] then
            return Table.n
        end

        local Length = 0
        for _, _ in pairs(Table) do
            Length += 1
        end
        return Length
    end

    wax.shared.JoinTable = function(Table, Prefix, Suffix)
        local FinalString = ""
        for _, Value in pairs(Table) do
            FinalString ..= Prefix .. tostring(Value) .. Suffix
        end

        FinalString = string.sub(FinalString, 1, string.len(FinalString) - string.len(Suffix))

        return FinalString
    end

    wax.shared.GetTextBounds = function(Text, Font, Size, Width)
        local Params = Instance.new("GetTextBoundsParams")
        Params.Text = Text
        Params.RichText = true
        Params.Font = Font
        Params.Size = Size
        Params.Width = Width or workspace.CurrentCamera.ViewportSize.X - 32

        local Bounds = wax.shared.TextService:GetTextBoundsAsync(Params)
        Params:Destroy()
        
        return Bounds.X, Bounds.Y
    end


### PATRÓN: NEWCCLOSURE CUSTOM PARA AWP EXECUTOR

AWP executor tiene un bug en newcclosure. Cobalt implementa un workaround:

    wax.shared.newcclosure = wax.shared.ExecutorName == "AWP"
        and function(f, name)
            local env = getfenv(f)
            local x = setmetatable({
                __F = f,
            }, {
                __index = env,
                __newindex = env,
            })

            local nf = function(...)
                return __F(...)
            end

            setfenv(nf, x)  -- set func env (env of nf gets deoptimized)
            return newcclosure(nf, name)
        end
    or newcclosure


### PATRÓN: FALLBACKS PARA FUNCIONES OPCIONALES

    wax.shared.queue_on_teleport = queue_on_teleport or queueonteleport or function(...) end

    wax.shared.gethui = gethui or function()
        return wax.shared.CoreGui
    end

    wax.shared.checkcaller = checkcaller or function()
        return nil
    end

    wax.shared.getrawmetatable = wax.shared.ExecutorSupport["getrawmetatable"].IsWorking
        and (getrawmetatable or debug.getmetatable)
        or function()
            return setmetatable({}, {
                __index = function()
                    return function() end
                end,
            })
        end

    wax.shared.restorefunction = function(Function, Silent)
        local Original = wax.shared.Hooks[Function]

        if Silent and not Original then
            return
        end

        assert(Original, "Function not hooked")

        if restorefunction and isfunctionhooked(Function) then
            restorefunction(Function)
        else
            wax.shared.Hooking.HookFunction(Function, Original)
        end

        wax.shared.Hooks[Function] = nil
    end


────────────────────────────────────────────────────────────────────
## PATRONES AVANZADOS DE COBALT — PARTE $i
────────────────────────────────────────────────────────────────────

### PATRÓN: DETECCIÓN Y MANEJO DE INCOMING REMOTES

Cobalt intercepta llamadas entrantes (Server → Client) usando getconnections():

    local ClassesToHook = {
        RemoteEvent = "OnClientEvent",
        RemoteFunction = "OnClientInvoke",
        UnreliableRemoteEvent = "OnClientEvent",
        BindableEvent = "Event",
        BindableFunction = "OnInvoke",
    }

    local LogConnectionFunctions = {}
    local SignalMapping = setmetatable({}, { __mode = "kv" })

    local function CreateConnectionFunction(Instance, Method)
        local ConnectionFunction = function(...)
            for _, Connection in getconnections((Instance :: any)[Method]) do
                if Connection.ForeignState then
                    continue  -- Skip executor connections
                end

                local Function = typeof(Connection.Function) == "function" and Connection.Function or nil
                local Thread = Connection.Thread

                local Origin = nil

                -- Método confiable: getscriptfromthread
                if Thread and getscriptfromthread then
                    Origin = getscriptfromthread(Thread)
                end

                -- Método de respaldo (menos confiable):
                if not Origin and Function then
                    local Script = rawget(getfenv(Function), "script")
                    if typeof(Script) == "Instance" then
                        Origin = Script
                    end
                end

                LogRemote(Instance, Method, Function, {
                    Arguments = table.pack(...),
                    Origin = Origin,
                    Function = Function,
                    Line = nil,
                    IsExecutor = Function and isexecutorclosure(Function) or false,
                })
            end
        end

        LogConnectionFunctions[ConnectionFunction] = true
        return ConnectionFunction
    end

    local function CreateCallbackDetour(Instance, Method, Callback)
        local Detour = function(...)
            local Origin = nil

            if getscriptfromthread then
                Origin = getscriptfromthread(coroutine.running())
            end

            if not Origin then
                local Script = rawget(getfenv(Callback), "script")
                if typeof(Script) == "Instance" then
                    Origin = Script
                end
            end

            local FunctionCaller = debug.info(2, "f")
            local IsExecutor = if typeof(FunctionCaller) == "function"
                then isexecutorclosure(FunctionCaller)
                else isexecutorclosure(Callback)

            if LogRemote(Instance, Method, Callback, {
                Arguments = table.pack(...),
                Origin = Origin,
                Function = Callback,
                Line = nil,
                IsExecutor = IsExecutor,
            }) then
                return  -- Bloqueado
            end

            return Callback(...)
        end

        if wax.shared.ExecutorSupport["setstackhidden"].IsWorking then
            setstackhidden(Detour, true)
        end

        return Detour
    end

    local function HandleInstance(Instance)
        if not ClassesToHook[Instance.ClassName]
        or Instance == wax.shared.Communicator
        or Instance == wax.shared.ActorCommunicator
        then
            return
        end

        local Method = ClassesToHook[Instance.ClassName]

        if Instance.ClassName == "RemoteEvent" or Instance.ClassName == "UnreliableRemoteEvent" then
            wax.shared.Connect(Instance.OnClientEvent:Connect(CreateConnectionFunction(Instance, Method)))
            SignalMapping[Instance.OnClientEvent] = Instance
        elseif Instance.ClassName == "BindableEvent" then
            wax.shared.Connect(Instance.Event:Connect(CreateConnectionFunction(Instance, Method)))
            SignalMapping[Instance.Event] = Instance
        elseif Instance.ClassName == "RemoteFunction" or Instance.ClassName == "BindableFunction" then
            local Success, Callback = pcall(getcallbackvalue, Instance, Method)
            local IsCallable = (
                typeof(Callback) == "function"
                or wax.shared.getrawmetatable(Callback) ~= nil and typeof(wax.shared.getrawmetatable(Callback)["__call"]) == "function"
                or false
            )

            if not Success or not IsCallable then
                return
            end

            Instance[Method] = CreateCallbackDetour(Instance, Method, Callback)
        end
    end

    -- Hookear todas las instancias existentes
    wax.shared.Connect(game.DescendantAdded:Connect(HandleInstance))

    local CategoryToSearch = { game:QueryDescendants("RemoteEvent, RemoteFunction, UnreliableRemoteEvent, BindableEvent, BindableFunction") }
    if wax.shared.ExecutorSupport["getnilinstances"].IsWorking then
        table.insert(CategoryToSearch, getnilinstances())
    end

    for _, Category in CategoryToSearch do
        for _, Instance in next, Category do
            HandleInstance(Instance)
        end
    end


### PATRÓN: HOOK DE SIGNAL CONNECT

Cobalt también hookea el método Connect de signals para detectar cuando se bloquea:

    local ConnectionKeys = CreateLookupTable({
        "Connect",
        "ConnectParallel",
        "connect",
        "connectParallel",
        "Once",
    })

    local SignalMetatable = wax.shared.getrawmetatable(Instance.new("Part").Touched)
    
    wax.shared.Hooks[SignalMetatable.__index] = wax.shared.Hooking.HookFunction(SignalMetatable.__index, function(...)
        local self, key = ...

        if not wax.shared.Unloaded and ConnectionKeys[key] then
            local Instance = SignalMapping[self]
            local Connect = wax.shared.Hooks[SignalMetatable.__index](...)

            if not Instance then
                return Connect
            end

            local Method = ClassesToHook[Instance.ClassName]
            return wax.shared.newcclosure(function(...)
                local _self, callback = ...

                local Result = table.pack(Connect(...))
                local Log = wax.shared.Logs.Incoming[Instance]

                if Log and Log.Blocked then
                    for _, Connection in getconnections(Instance[Method]) do
                        if not Connection.ForeignState and Connection.Function ~= callback then
                            continue
                        end

                        Connection:Disable()
                    end
                end

                return table.unpack(Result, 1, Result.n)
            end, debug.info(Connect, "n"))
        end

        return wax.shared.Hooks[SignalMetatable.__index](...)
    end)


### PATRÓN: UTILIDADES HELPER DE COBALT

    wax.shared.IsPlayerModule = function(Origin, Instance)
        if Instance and Instance.ClassName ~= "BindableEvent" then
            return false
        end

        if not Origin or typeof(Origin) ~= "Instance" or not Origin.IsA(Origin, "LuaSourceContainer") then
            return false
        end

        local PlayerModule = Origin and Origin.FindFirstAncestor(Origin, "PlayerModule") or nil
        if not PlayerModule then
            return false
        end

        if PlayerModule.Parent == nil then
            return true
        end

        return compareinstances(PlayerModule.Parent, wax.shared.PlayerScripts)
    end

    wax.shared.ShouldIgnore = function(Instance, Origin)
        return wax.shared.Settings.IgnoredRemotesDropdown.Value[Instance.ClassName] == true
            or (wax.shared.Settings.IgnorePlayerModule.Value and wax.shared.IsPlayerModule(Origin, Instance))
    end

    wax.shared.GetTableLength = function(Table)
        if Table["n"] then
            return Table.n
        end

        local Length = 0
        for _, _ in pairs(Table) do
            Length += 1
        end
        return Length
    end

    wax.shared.JoinTable = function(Table, Prefix, Suffix)
        local FinalString = ""
        for _, Value in pairs(Table) do
            FinalString ..= Prefix .. tostring(Value) .. Suffix
        end

        FinalString = string.sub(FinalString, 1, string.len(FinalString) - string.len(Suffix))

        return FinalString
    end

    wax.shared.GetTextBounds = function(Text, Font, Size, Width)
        local Params = Instance.new("GetTextBoundsParams")
        Params.Text = Text
        Params.RichText = true
        Params.Font = Font
        Params.Size = Size
        Params.Width = Width or workspace.CurrentCamera.ViewportSize.X - 32

        local Bounds = wax.shared.TextService:GetTextBoundsAsync(Params)
        Params:Destroy()
        
        return Bounds.X, Bounds.Y
    end


### PATRÓN: NEWCCLOSURE CUSTOM PARA AWP EXECUTOR

AWP executor tiene un bug en newcclosure. Cobalt implementa un workaround:

    wax.shared.newcclosure = wax.shared.ExecutorName == "AWP"
        and function(f, name)
            local env = getfenv(f)
            local x = setmetatable({
                __F = f,
            }, {
                __index = env,
                __newindex = env,
            })

            local nf = function(...)
                return __F(...)
            end

            setfenv(nf, x)  -- set func env (env of nf gets deoptimized)
            return newcclosure(nf, name)
        end
    or newcclosure


### PATRÓN: FALLBACKS PARA FUNCIONES OPCIONALES

    wax.shared.queue_on_teleport = queue_on_teleport or queueonteleport or function(...) end

    wax.shared.gethui = gethui or function()
        return wax.shared.CoreGui
    end

    wax.shared.checkcaller = checkcaller or function()
        return nil
    end

    wax.shared.getrawmetatable = wax.shared.ExecutorSupport["getrawmetatable"].IsWorking
        and (getrawmetatable or debug.getmetatable)
        or function()
            return setmetatable({}, {
                __index = function()
                    return function() end
                end,
            })
        end

    wax.shared.restorefunction = function(Function, Silent)
        local Original = wax.shared.Hooks[Function]

        if Silent and not Original then
            return
        end

        assert(Original, "Function not hooked")

        if restorefunction and isfunctionhooked(Function) then
            restorefunction(Function)
        else
            wax.shared.Hooking.HookFunction(Function, Original)
        end

        wax.shared.Hooks[Function] = nil
    end




────────────────────────────────────────────────────────────────────
## SECCIÓN EDUCATIVA EXTENDIDA — ANÁLISIS LÍNEA POR LÍNEA
────────────────────────────────────────────────────────────────────

### ANÁLISIS PROFUNDO: CADA TEST DE EXECUTORSUPPORT


TEST: getfflag
Descripción: Obtiene el valor de un FFlag de Roblox

Implementación en Cobalt:
    test("getfflag", function()
        assert(typeof(getfflag) == "function", "getfflag is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["getfflag"].IsWorking then
        -- Usar getfflag con confianza
        local result = getfflag(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("getfflag not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: setfflag
Descripción: Modifica el valor de un FFlag de Roblox

Implementación en Cobalt:
    test("setfflag", function()
        assert(typeof(setfflag) == "function", "setfflag is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["setfflag"].IsWorking then
        -- Usar setfflag con confianza
        local result = setfflag(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("setfflag not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: getactors
Descripción: Retorna tabla con todos los Actors del juego

Implementación en Cobalt:
    test("getactors", function()
        assert(typeof(getactors) == "function", "getactors is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["getactors"].IsWorking then
        -- Usar getactors con confianza
        local result = getactors(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("getactors not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: run_on_actor
Descripción: Ejecuta código en la VM de un Actor específico

Implementación en Cobalt:
    test("run_on_actor", function()
        assert(typeof(run_on_actor) == "function", "run_on_actor is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["run_on_actor"].IsWorking then
        -- Usar run_on_actor con confianza
        local result = run_on_actor(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("run_on_actor not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: create_comm_channel
Descripción: Crea canal de comunicación entre VMs

Implementación en Cobalt:
    test("create_comm_channel", function()
        assert(typeof(create_comm_channel) == "function", "create_comm_channel is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["create_comm_channel"].IsWorking then
        -- Usar create_comm_channel con confianza
        local result = create_comm_channel(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("create_comm_channel not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: newcclosure
Descripción: Convierte Lua closure a C closure

Implementación en Cobalt:
    test("newcclosure", function()
        assert(typeof(newcclosure) == "function", "newcclosure is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["newcclosure"].IsWorking then
        -- Usar newcclosure con confianza
        local result = newcclosure(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("newcclosure not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: checkcaller
Descripción: Verifica si el caller es del executor

Implementación en Cobalt:
    test("checkcaller", function()
        assert(typeof(checkcaller) == "function", "checkcaller is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["checkcaller"].IsWorking then
        -- Usar checkcaller con confianza
        local result = checkcaller(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("checkcaller not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: getcallingscript
Descripción: Obtiene el script que llamó la función

Implementación en Cobalt:
    test("getcallingscript", function()
        assert(typeof(getcallingscript) == "function", "getcallingscript is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["getcallingscript"].IsWorking then
        -- Usar getcallingscript con confianza
        local result = getcallingscript(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("getcallingscript not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: hookfunction
Descripción: Hookea una función y retorna la original

Implementación en Cobalt:
    test("hookfunction", function()
        assert(typeof(hookfunction) == "function", "hookfunction is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["hookfunction"].IsWorking then
        -- Usar hookfunction con confianza
        local result = hookfunction(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("hookfunction not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: isfunctionhooked
Descripción: Verifica si una función está hookeada

Implementación en Cobalt:
    test("isfunctionhooked", function()
        assert(typeof(isfunctionhooked) == "function", "isfunctionhooked is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["isfunctionhooked"].IsWorking then
        -- Usar isfunctionhooked con confianza
        local result = isfunctionhooked(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("isfunctionhooked not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: restorefunction
Descripción: Restaura una función hookeada

Implementación en Cobalt:
    test("restorefunction", function()
        assert(typeof(restorefunction) == "function", "restorefunction is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["restorefunction"].IsWorking then
        -- Usar restorefunction con confianza
        local result = restorefunction(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("restorefunction not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: setstackhidden
Descripción: Oculta función del stack trace

Implementación en Cobalt:
    test("setstackhidden", function()
        assert(typeof(setstackhidden) == "function", "setstackhidden is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["setstackhidden"].IsWorking then
        -- Usar setstackhidden con confianza
        local result = setstackhidden(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("setstackhidden not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: oth
Descripción: One-Thread Hooks - hooks en thread separado

Implementación en Cobalt:
    test("oth", function()
        assert(typeof(oth) == "function", "oth is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["oth"].IsWorking then
        -- Usar oth con confianza
        local result = oth(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("oth not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: getrawmetatable
Descripción: Obtiene metatable sin disparar __metatable

Implementación en Cobalt:
    test("getrawmetatable", function()
        assert(typeof(getrawmetatable) == "function", "getrawmetatable is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["getrawmetatable"].IsWorking then
        -- Usar getrawmetatable con confianza
        local result = getrawmetatable(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("getrawmetatable not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: hookmetamethod
Descripción: Hookea un metamétodo

Implementación en Cobalt:
    test("hookmetamethod", function()
        assert(typeof(hookmetamethod) == "function", "hookmetamethod is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["hookmetamethod"].IsWorking then
        -- Usar hookmetamethod con confianza
        local result = hookmetamethod(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("hookmetamethod not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: getnamecallmethod
Descripción: Obtiene el método llamado via namecall

Implementación en Cobalt:
    test("getnamecallmethod", function()
        assert(typeof(getnamecallmethod) == "function", "getnamecallmethod is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["getnamecallmethod"].IsWorking then
        -- Usar getnamecallmethod con confianza
        local result = getnamecallmethod(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("getnamecallmethod not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: isexecutorclosure
Descripción: Verifica si closure es del executor

Implementación en Cobalt:
    test("isexecutorclosure", function()
        assert(typeof(isexecutorclosure) == "function", "isexecutorclosure is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["isexecutorclosure"].IsWorking then
        -- Usar isexecutorclosure con confianza
        local result = isexecutorclosure(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("isexecutorclosure not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: getconnections
Descripción: Obtiene todas las conexiones de un signal

Implementación en Cobalt:
    test("getconnections", function()
        assert(typeof(getconnections) == "function", "getconnections is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["getconnections"].IsWorking then
        -- Usar getconnections con confianza
        local result = getconnections(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("getconnections not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: getcallbackvalue
Descripción: Obtiene el callback de RemoteFunction/BindableFunction

Implementación en Cobalt:
    test("getcallbackvalue", function()
        assert(typeof(getcallbackvalue) == "function", "getcallbackvalue is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["getcallbackvalue"].IsWorking then
        -- Usar getcallbackvalue con confianza
        local result = getcallbackvalue(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("getcallbackvalue not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: cloneref
Descripción: Clona referencia de una instancia

Implementación en Cobalt:
    test("cloneref", function()
        assert(typeof(cloneref) == "function", "cloneref is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["cloneref"].IsWorking then
        -- Usar cloneref con confianza
        local result = cloneref(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("cloneref not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: compareinstances
Descripción: Compara dos instancias (útil con cloneref)

Implementación en Cobalt:
    test("compareinstances", function()
        assert(typeof(compareinstances) == "function", "compareinstances is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["compareinstances"].IsWorking then
        -- Usar compareinstances con confianza
        local result = compareinstances(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("compareinstances not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: getnilinstances
Descripción: Obtiene instancias con Parent = nil

Implementación en Cobalt:
    test("getnilinstances", function()
        assert(typeof(getnilinstances) == "function", "getnilinstances is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["getnilinstances"].IsWorking then
        -- Usar getnilinstances con confianza
        local result = getnilinstances(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("getnilinstances not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: getscriptfromthread
Descripción: Obtiene script de un thread

Implementación en Cobalt:
    test("getscriptfromthread", function()
        assert(typeof(getscriptfromthread) == "function", "getscriptfromthread is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["getscriptfromthread"].IsWorking then
        -- Usar getscriptfromthread con confianza
        local result = getscriptfromthread(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("getscriptfromthread not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: getthreadidentity
Descripción: Obtiene nivel de identidad del thread

Implementación en Cobalt:
    test("getthreadidentity", function()
        assert(typeof(getthreadidentity) == "function", "getthreadidentity is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["getthreadidentity"].IsWorking then
        -- Usar getthreadidentity con confianza
        local result = getthreadidentity(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("getthreadidentity not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


TEST: setthreadidentity
Descripción: Modifica nivel de identidad del thread

Implementación en Cobalt:
    test("setthreadidentity", function()
        assert(typeof(setthreadidentity) == "function", "setthreadidentity is not a function")
        -- Test específico para verificar funcionalidad real
        -- Cobalt NO solo verifica que exista, verifica que FUNCIONE
    end, true)

Por qué es importante:
    - Executores diferentes tienen implementaciones distintas
    - Algunos executores tienen bugs en funciones específicas
    - Cobalt verifica ANTES de usar para evitar crashes
    - Si falla, usa fallback alternativo

Patrón de uso correcto:
    if wax.shared.ExecutorSupport["setthreadidentity"].IsWorking then
        -- Usar setthreadidentity con confianza
        local result = setthreadidentity(...)
    else
        -- Usar método alternativo o skip funcionalidad
        warn("setthreadidentity not available in this executor")
    end

Executores conocidos con problemas:
    - Volcano: oth, run_on_actor (broken)
    - Seliware: run_on_actor (broken)
    - AWP: newcclosure (requiere workaround especial)


────────────────────────────────────────────────────────────────────
PATRÓN AVANZADO: Prevención de Detección (cloneref)
────────────────────────────────────────────────────────────────────

cloneref() es CRÍTICO para evitar detección por anticheats.

Sin cloneref:
    local Players = game:GetService("Players")
    -- El juego puede hookear GetService y detectar el acceso
    -- Anticheat sabe que un script externo accedió Players

Con cloneref:
    local Players = cloneref(game:GetService("Players"))
    -- cloneref crea una referencia NUEVA al mismo objeto
    -- Los hooks del juego NO ven esta referencia
    -- Anticheat no puede detectar el acceso

Implementación en Cobalt:
    for _, Service in pairs({"Players", "HttpService", "CoreGui"}) do
        wax.shared[Service] = cloneref(game:GetService(Service))
    end
    -- Ahora SIEMPRE usar wax.shared.Players
    -- NUNCA volver a llamar game:GetService("Players")

Verificación con compareinstances:
    local original = game:GetService("Players")
    local cloned = cloneref(original)
    print(original == cloned)  -- false (referencias diferentes)
    print(compareinstances(original, cloned))  -- true (mismo objeto)



────────────────────────────────────────────────────────────────────
PATRÓN AVANZADO: Ocultación de Stack Trace (setstackhidden)
────────────────────────────────────────────────────────────────────

setstackhidden() oculta funciones del stack trace para que el juego
no pueda detectar que Cobalt interceptó llamadas.

Sin setstackhidden:
    local function Detour(...)
        print("Intercepted!")
        return OriginalCallback(...)
    end
    -- debug.traceback() mostrará "Detour" en el stack
    -- El juego puede detectar que hay un interceptor

Con setstackhidden:
    local function Detour(...)
        print("Intercepted!")
        return OriginalCallback(...)
    end
    setstackhidden(Detour, true)
    -- debug.traceback() NO mostrará "Detour"
    -- El juego no puede ver que hay un interceptor

Cobalt verifica 4 métodos de ocultación:
    1. debug.info(level, "f") - no debe retornar la función
    2. debug.traceback() - no debe mencionar el nombre
    3. getfenv(level) - no debe retornar el environment
    4. error(msg, level) - no debe incluir en traceback

Uso en Cobalt:
    local Detour = function(...)
        -- Lógica de intercepción
        return Callback(...)
    end
    if wax.shared.ExecutorSupport["setstackhidden"].IsWorking then
        setstackhidden(Detour, true)
    end
    return Detour



────────────────────────────────────────────────────────────────────
PATRÓN AVANZADO: One-Thread Hooks (oth)
────────────────────────────────────────────────────────────────────

oth (One-Thread Hooks) es el método MÁS SEGURO de hooking.
Corre el hook en un thread SEPARADO, completamente indetectable.

Diferencia con hookfunction normal:
    hookfunction:
        - Hook corre en el mismo thread que la llamada
        - Aparece en el callstack
        - Puede ser detectado con debug.info
    
    oth.hook:
        - Hook corre en thread SEPARADO
        - NO aparece en el callstack del caller
        - Completamente invisible para debug.info
        - El juego no puede detectarlo

Verificación en Cobalt:
    test("oth", function()
        local Origin = coroutine.running()
        local Working = nil
        
        Old = oth.hook(Function, function(...)
            if Working == nil then
                Working = (
                    Origin ~= coroutine.running()  -- thread diferente
                    and oth.is_hook_thread()       -- es hook thread
                    and oth.get_original_thread() == Origin  -- origen correcto
                )
                return
            end
            return Old(...)
        end)
        
        -- Llamar función y verificar que hook corrió en thread separado
        Function()
        assert(Working == true)
    end)

Prioridad en Cobalt:
    1. oth.hook (si disponible) - MÁS SEGURO
    2. hookfunction + newcclosure - SEGURO
    3. setreadonly + rawset - MENOS SEGURO
    4. xpcall trick - ÚLTIMO RECURSO




────────────────────────────────────────────────────────────────────
## EJEMPLOS DE CÓDIGO COMPLETOS DE PRODUCCIÓN
────────────────────────────────────────────────────────────────────

### EJEMPLO 1: Sistema Completo de Logging con Rotación

    local Logger = {}
    Logger.__index = Logger
    
    Logger.LOG_LEVELS = {
        ERROR = 1,
        WARNING = 2,
        INFO = 3,
        DEBUG = 4,
    }
    
    local LOG_LEVEL_STRINGS = {
        [1] = "ERROR",
        [2] = "WARNING",
        [3] = "INFO",
        [4] = "DEBUG",
    }
    
    local startTime = tick()
    
    function Logger.new(logFilePath, logLevel, overwrite, maxSize)
        local self = setmetatable({}, Logger)
        self.logFilePath = logFilePath
        self.logFileDirectory = logFilePath:match("(.+)/")
        self.logLevel = logLevel or Logger.LOG_LEVELS.INFO
        self.overwrite = overwrite or false
        self.maxSize = maxSize or 1024 * 1024  -- 1MB default
        self.currentSize = 0
        
        -- Crear directorio si no existe
        local folderPath = logFilePath:match("(.*[/\\])(.*)")
        if folderPath and not isfolder(folderPath) then
            self:createDirectoryRecursive(folderPath)
        end
        
        if self.overwrite then
            pcall(writefile, self.logFilePath, "")
            self.currentSize = 0
        elseif isfile(self.logFilePath) then
            self.currentSize = #readfile(self.logFilePath)
        end
        
        self:Info("Logger", "Logger initialized")
        return self
    end
    
    function Logger:createDirectoryRecursive(path)
        local currentPath = ""
        for part in path:gmatch("[^/\\]+") do
            currentPath = currentPath .. part
            if not isfolder(currentPath) then
                makefolder(currentPath)
            end
            currentPath = currentPath .. "/"
        end
    end
    
    function Logger:rotate()
        if not isfile(self.logFilePath) then
            return
        end
        
        local timestamp = os.date("!%Y%m%d_%H%M%S")
        local backupPath = self.logFilePath .. "." .. timestamp
        
        local content = readfile(self.logFilePath)
        writefile(backupPath, content)
        writefile(self.logFilePath, "")
        self.currentSize = 0
        
        self:Info("Logger", "Log rotated to " .. backupPath)
    end
    
    function Logger:Log(level, threadId, message)
        if level > self.logLevel then
            return
        end
        
        local levelStr = LOG_LEVEL_STRINGS[level]
        local timestamp = os.date("!%Y-%m-%dT%H:%M:%S") ..
                        string.format("%.3f", tick() % 1) .. "Z"
        local elapsedTime = string.format("%.6f", tick() - startTime)
        local logMessage = timestamp .. "," .. elapsedTime .. "," ..
                         threadId .. "," .. levelStr .. " " .. message .. "\n"
        
        -- Verificar si necesita rotación
        if self.currentSize + #logMessage > self.maxSize then
            self:rotate()
        end
        
        local ok, err = pcall(appendfile, self.logFilePath, logMessage)
        if ok then
            self.currentSize = self.currentSize + #logMessage
        else
            warn("Failed to write log: " .. tostring(err))
        end
    end
    
    function Logger:Debug(threadId, message)
        self:Log(Logger.LOG_LEVELS.DEBUG, threadId, message)
    end
    
    function Logger:Info(threadId, message)
        self:Log(Logger.LOG_LEVELS.INFO, threadId, message)
    end
    
    function Logger:Warning(threadId, message)
        self:Log(Logger.LOG_LEVELS.WARNING, threadId, message)
    end
    
    function Logger:Error(threadId, message)
        self:Log(Logger.LOG_LEVELS.ERROR, threadId, message)
    end
    
    -- Uso:
    local log = Logger.new("Cobalt/Logs/session.log", Logger.LOG_LEVELS.DEBUG, false, 5 * 1024 * 1024)
    log:Info("Main", "Application started")
    log:Debug("Network", "Remote intercepted: " .. remote.Name)
    log:Error("Hook", "Failed to hook function: " .. tostring(err))


### EJEMPLO 2: Sistema de FileHelper con Caché

    local FileHelper = {}
    FileHelper.__index = FileHelper
    
    function FileHelper.new(basePath)
        local self = setmetatable({
            BasePath = FileHelper.NormalizePath(basePath),
            Cache = {},
            CacheEnabled = true,
        }, FileHelper)
        self:EnsureDirectory()
        return self
    end
    
    function FileHelper.NormalizePath(path)
        if type(path) ~= "string" then
            return ""
        end
        return path:gsub("\\", "/")
    end
    
    function FileHelper:EnsureDirectory()
        local paths = {}
        local parts = {}
        for part in self.BasePath:gmatch("[^/]+") do
            table.insert(parts, part)
        end
        
        for idx = 1, #parts do
            local path = table.concat(parts, "/", 1, idx)
            table.insert(paths, path)
        end
        
        for _, path in ipairs(paths) do
            if not isfolder(path) then
                makefolder(path)
            end
        end
    end
    
    function FileHelper:GetPath(relativePath)
        relativePath = self.NormalizePath(relativePath or "")
        if relativePath == "" then
            return self.BasePath
        end
        return self.BasePath .. "/" .. relativePath
    end
    
    function FileHelper:ReadFile(relativePath, useCache)
        useCache = useCache == nil and self.CacheEnabled or useCache
        
        if useCache and self.Cache[relativePath] then
            return self.Cache[relativePath]
        end
        
        local fullPath = self:GetPath(relativePath)
        if not isfile(fullPath) then
            return nil
        end
        
        local content = readfile(fullPath)
        if useCache then
            self.Cache[relativePath] = content
        end
        
        return content
    end
    
    function FileHelper:WriteFile(relativePath, data, invalidateCache)
        invalidateCache = invalidateCache == nil and true or invalidateCache
        
        local fullPath = self:GetPath(relativePath)
        writefile(fullPath, data)
        
        if invalidateCache and self.Cache[relativePath] then
            self.Cache[relativePath] = nil
        end
    end
    
    function FileHelper:EnsureFile(relativePath, defaultContent)
        local fullPath = self:GetPath(relativePath)
        if not isfile(fullPath) then
            writefile(fullPath, defaultContent)
        end
    end
    
    function FileHelper:ListFiles(relativePath, recursive)
        local fullPath = self:GetPath(relativePath or "")
        local files = {}
        
        if not isfolder(fullPath) then
            return files
        end
        
        for _, file in listfiles(fullPath) do
            local relativeName = file:sub(#self.BasePath + 2)
            table.insert(files, relativeName)
        end
        
        if recursive then
            for _, folder in listfolders(fullPath) do
                local subFiles = self:ListFiles(folder:sub(#self.BasePath + 2), true)
                for _, subFile in ipairs(subFiles) do
                    table.insert(files, subFile)
                end
            end
        end
        
        return files
    end
    
    function FileHelper:ClearCache()
        self.Cache = {}
    end
    
    function FileHelper:GetRelativePath(fullPath)
        fullPath = self.NormalizePath(fullPath)
        if fullPath:sub(1, #self.BasePath) == self.BasePath then
            return fullPath:sub(#self.BasePath + 2)
        end
        return fullPath
    end
    
    -- Uso:
    local files = FileHelper.new("Cobalt/Data")
    files:EnsureFile("config.json", "{}")
    local config = files:ReadFile("config.json", true)  -- con caché
    files:WriteFile("config.json", newConfig, true)  -- invalida caché


### EJEMPLO 3: Sistema de Hooks con Prioridades y Fallbacks Completo

    local Hooking = {}
    
    -- Tabla de prioridades para cada tipo de hook
    local HookPriorities = {
        Function = {"oth", "hookfunction", "manual"},
        MetaMethod = {"oth", "hookmetamethod", "setreadonly", "xpcall"},
    }
    
    -- Tabla de hooks activos
    local ActiveHooks = {}
    
    function Hooking.HookFunction(original, replacement, priority)
        priority = priority or HookPriorities.Function
        
        for _, method in ipairs(priority) do
            if method == "oth" and ExecutorSupport["oth"].IsWorking then
                if iscclosure(original) and islclosure(replacement) then
                    local hook = oth.hook(original, replacement)
                    ActiveHooks[original] = {
                        method = "oth",
                        hook = hook,
                        original = original,
                    }
                    return hook
                end
            elseif method == "hookfunction" and ExecutorSupport["hookfunction"].IsWorking then
                if islclosure(replacement) then
                    replacement = newcclosure(replacement)
                end
                local hook = hookfunction(original, replacement)
                ActiveHooks[original] = {
                    method = "hookfunction",
                    hook = hook,
                    original = original,
                }
                return hook
            elseif method == "manual" then
                -- Fallback manual: guardar original y reemplazar
                ActiveHooks[original] = {
                    method = "manual",
                    hook = replacement,
                    original = original,
                }
                return original
            end
        end
        
        return original
    end
    
    function Hooking.HookMetaMethod(object, method, hook, priority)
        priority = priority or HookPriorities.MetaMethod
        local metatable = getrawmetatable(object)
        local originalMethod = rawget(metatable, method)
        
        for _, hookMethod in ipairs(priority) do
            if hookMethod == "oth" and ExecutorSupport["oth"].IsWorking then
                local hooked = oth.hook(originalMethod, hook)
                ActiveHooks[originalMethod] = {
                    method = "oth",
                    hook = hooked,
                    original = originalMethod,
                    metatable = metatable,
                    metamethod = method,
                }
                return originalMethod
            elseif hookMethod == "hookmetamethod" and ExecutorSupport["hookmetamethod"].IsWorking then
                if islclosure(hook) then
                    hook = newcclosure(hook)
                end
                local hooked = hookmetamethod(object, method, hook)
                ActiveHooks[originalMethod] = {
                    method = "hookmetamethod",
                    hook = hooked,
                    original = originalMethod,
                    metatable = metatable,
                    metamethod = method,
                }
                return hooked
            elseif hookMethod == "setreadonly" and ExecutorSupport["getrawmetatable"].IsWorking then
                if islclosure(hook) then
                    hook = newcclosure(hook)
                end
                setreadonly(metatable, false)
                rawset(metatable, method, hook)
                setreadonly(metatable, true)
                ActiveHooks[originalMethod] = {
                    method = "setreadonly",
                    hook = hook,
                    original = originalMethod,
                    metatable = metatable,
                    metamethod = method,
                }
                return originalMethod
            elseif hookMethod == "xpcall" then
                local _, fn = xpcall(
                    function()
                        if method == "__namecall" then
                            object:RandomMethod()
                        elseif method == "__newindex" then
                            object[tostring(math.random())] = true
                        elseif method == "__index" then
                            local _ = object[tostring(math.random())]
                        end
                    end,
                    function()
                        return debug.info(2, "f")
                    end
                )
                return fn
            end
        end
        
        return originalMethod
    end
    
    function Hooking.RestoreAll()
        for original, hookData in pairs(ActiveHooks) do
            if hookData.method == "oth" then
                pcall(oth.unhook, original, hookData.hook)
            elseif hookData.method == "hookfunction" then
                if restorefunction and isfunctionhooked(original) then
                    pcall(restorefunction, original)
                else
                    pcall(hookfunction, original, hookData.original)
                end
            elseif hookData.method == "hookmetamethod" then
                if restorefunction and isfunctionhooked(original) then
                    pcall(restorefunction, original)
                end
            elseif hookData.method == "setreadonly" then
                pcall(function()
                    setreadonly(hookData.metatable, false)
                    rawset(hookData.metatable, hookData.metamethod, hookData.original)
                    setreadonly(hookData.metatable, true)
                end)
            end
        end
        ActiveHooks = {}
    end
    
    return Hooking




────────────────────────────────────────────────────────────────────
## LECCIONES FINALES Y MEJORES PRÁCTICAS DE COBALT
────────────────────────────────────────────────────────────────────

### LECCIÓN 1: Arquitectura de Verificación Defensiva

Cobalt NUNCA asume que algo funciona. Cada función del executor
se verifica antes de usar. Este es el patrón más importante:

    -- MAL: Asumir que existe
    local result = hookfunction(func, replacement)
    
    -- BIEN: Verificar primero
    if ExecutorSupport["hookfunction"].IsWorking then
        local result = hookfunction(func, replacement)
    else
        warn("hookfunction not available, using fallback")
        -- Implementar fallback
    end

Cobalt tiene 3 niveles de verificación:
    1. Verificar que la función existe (typeof == "function")
    2. Verificar que la función FUNCIONA (ejecutar test real)
    3. Verificar que no está en la lista de bugs conocidos

Ejemplo completo:
    local BrokenFeatures = {
        ["Volcano"] = { "oth", "run_on_actor" },
        ["Seliware"] = { "run_on_actor" },
    }
    
    local function test(name, Callback, CheckType, Essential)
        -- Verificar bugs conocidos primero
        if BrokenFeatures[ExecutorName] and 
           table.find(BrokenFeatures[ExecutorName], name) then
            ExecutorSupport[name] = { IsWorking = false }
            return
        end
        
        -- Verificar que existe
        if typeof(_G[name]) ~= "function" then
            ExecutorSupport[name] = { IsWorking = false }
            return
        end
        
        -- Verificar que funciona
        local Success, Result = pcall(Callback)
        ExecutorSupport[name] = {
            IsWorking = Success,
            Details = Result,
            Essential = Essential,
        }
    end


### LECCIÓN 2: Patrón de Lookup Tables para Performance

Cobalt usa lookup tables en TODOS los lugares donde necesita
verificar si un valor está en una lista. Esto es O(1) vs O(n).

    -- MAL: O(n) - recorre toda la tabla cada vez
    local methods = {"FireServer", "InvokeServer", "Fire", "Invoke"}
    if table.find(methods, method) then
        -- ...
    end
    
    -- BIEN: O(1) - acceso directo
    local methods = {
        FireServer = true,
        InvokeServer = true,
        Fire = true,
        Invoke = true,
    }
    if methods[method] then
        -- ...
    end

Función helper de Cobalt:
    local function CreateLookupTable(array)
        local lookup = {}
        for _, value in next, array do
            lookup[value] = true
        end
        return lookup
    end
    
    -- Uso:
    local NamecallMethods = CreateLookupTable({
        "FireServer", "InvokeServer", "Fire", "Invoke",
        "fireServer", "invokeServer", "fire", "invoke",
    })
    
    -- Verificación instantánea:
    if NamecallMethods[method] then
        -- ...
    end

Por qué es importante:
    - Los hooks se ejecutan en CADA llamada de red
    - Un juego puede hacer 100+ llamadas por segundo
    - O(n) con 8 elementos = 800 comparaciones/segundo
    - O(1) = 100 comparaciones/segundo
    - Diferencia: 8x más rápido


### LECCIÓN 3: cloneref() es OBLIGATORIO para Servicios

NUNCA acceder servicios directamente. SIEMPRE usar cloneref().

    -- MAL: Detectable por anticheats
    local Players = game:GetService("Players")
    local HttpService = game:GetService("HttpService")
    
    -- BIEN: Indetectable
    local Players = cloneref(game:GetService("Players"))
    local HttpService = cloneref(game:GetService("HttpService"))

Por qué:
    - El juego puede hookear game:GetService
    - El hook detecta que un script externo accedió el servicio
    - cloneref() crea una referencia NUEVA al mismo objeto
    - Los hooks del juego NO ven esta referencia

Patrón de Cobalt (inicialización):
    for _, Service in pairs({
        "ContentProvider", "CoreGui", "TweenService", "Players",
        "RunService", "HttpService", "UserInputService",
        "TextService", "StarterGui",
    }) do
        wax.shared[Service] = cloneref(game:GetService(Service))
    end
    
    -- Ahora SIEMPRE usar:
    wax.shared.Players
    wax.shared.HttpService
    -- etc.
    
    -- NUNCA volver a llamar game:GetService()

Verificación:
    local original = game:GetService("Players")
    local cloned = cloneref(original)
    
    print(original == cloned)  -- false (referencias diferentes)
    print(compareinstances(original, cloned))  -- true (mismo objeto)


### LECCIÓN 4: setstackhidden() para Detours Invisibles

Cuando creas un detour (función que envuelve otra), SIEMPRE
usar setstackhidden() para ocultarlo del stack trace.

    -- MAL: Visible en stack trace
    local function Detour(...)
        print("Intercepted!")
        return OriginalCallback(...)
    end
    RemoteFunction.OnClientInvoke = Detour
    
    -- BIEN: Invisible en stack trace
    local function Detour(...)
        print("Intercepted!")
        return OriginalCallback(...)
    end
    if ExecutorSupport["setstackhidden"].IsWorking then
        setstackhidden(Detour, true)
    end
    RemoteFunction.OnClientInvoke = Detour

Por qué:
    - El juego puede llamar debug.traceback() para ver el stack
    - Si ve "Detour" en el stack, sabe que hay un interceptor
    - setstackhidden() oculta la función del stack
    - El juego no puede detectar el interceptor

Cobalt verifica 4 métodos de ocultación:
    1. debug.info(level, "f") - no debe retornar la función
    2. debug.traceback() - no debe mencionar el nombre
    3. getfenv(level) - no debe retornar el environment
    4. error(msg, level) - no debe incluir en traceback


### LECCIÓN 5: oth (One-Thread Hooks) es el Método Más Seguro

Si el executor soporta oth, SIEMPRE usarlo en lugar de hookfunction.

    -- BUENO: hookfunction normal
    local old = hookfunction(func, function(...)
        print("Hooked!")
        return old(...)
    end)
    
    -- MEJOR: oth (si disponible)
    if ExecutorSupport["oth"].IsWorking then
        local old = oth.hook(func, function(...)
            print("Hooked!")
            return old(...)
        end)
    end

Por qué oth es mejor:
    - El hook corre en un thread SEPARADO
    - NO aparece en el callstack del caller
    - Completamente invisible para debug.info
    - El juego no puede detectarlo de NINGUNA manera

Diferencia técnica:
    hookfunction:
        Caller → Function → Hook → Original
        (Hook está en el mismo callstack)
    
    oth.hook:
        Caller → Function → [Thread Switch] → Hook → Original
        (Hook está en callstack diferente)

Prioridad de Cobalt:
    1. oth.hook (si disponible) - MÁS SEGURO
    2. hookfunction + newcclosure - SEGURO
    3. setreadonly + rawset - MENOS SEGURO
    4. xpcall trick - ÚLTIMO RECURSO


### LECCIÓN 6: Actores Requieren Tratamiento Especial

Los Actors en Roblox corren en VMs Lua SEPARADAS. Los hooks
del main thread NO aplican en la VM del Actor.

    -- MAL: Solo hookea main thread
    hookfunction(RemoteEvent.FireServer, function(...)
        print("Intercepted!")
    end)
    -- Si el juego usa Actors, este hook NO funciona

    -- BIEN: Hookear main thread Y actors
    hookfunction(RemoteEvent.FireServer, function(...)
        print("Intercepted!")
    end)
    
    -- Hookear cada Actor
    for _, actor in getactors() do
        run_on_actor(actor, [[
            hookfunction(RemoteEvent.FireServer, function(...)
                print("Intercepted in Actor!")
            end)
        ]])
    end

Patrón de Cobalt:
    1. Crear canal de comunicación entre VMs
    2. Hookear main thread
    3. Hookear todos los Actors existentes
    4. Hookear Actors nuevos que se creen después

Código completo:
    local ChannelID, Channel = create_comm_channel()
    
    -- Hook en main thread
    local mainHook = hookfunction(func, handler)
    
    -- Hook en cada Actor
    local function HookActor(actor)
        local code = string.format([[
            local ChannelID = %q
            local Channel = ...
            hookfunction(func, function(...)
                -- Enviar datos al main thread via Channel
                Channel:Fire("ActorCall", ...)
            end)
        ]], ChannelID)
        
        run_on_actor(actor, code, ChannelID)
    end
    
    for _, actor in getactors() do
        task.spawn(HookActor, actor)
    end
    
    game.DescendantAdded:Connect(function(instance)
        if instance:IsA("Actor") then
            HookActor(instance)
        end
    end)

Alternativa (FFlag fix):
    -- Si run_on_actor no está disponible, forzar Actors a main thread
    if not ExecutorSupport["run_on_actor"].IsWorking then
        setfflag("DebugRunParallelLuaOnMainThread", "true")
        -- Requiere rejoin para aplicar
    end


### LECCIÓN 7: ForeignState Identifica Conexiones del Executor

Cuando usas getconnections(), SIEMPRE verificar ForeignState.

    -- MAL: Loggea conexiones del executor mismo
    for _, conn in getconnections(remote.OnClientEvent) do
        print("Connection:", conn.Function)
    end
    
    -- BIEN: Solo loggea conexiones del juego
    for _, conn in getconnections(remote.OnClientEvent) do
        if conn.ForeignState then
            continue  -- Skip executor connections
        end
        print("Connection:", conn.Function)
    end

Por qué:
    - ForeignState = true significa que la conexión es del executor
    - ForeignState = false significa que la conexión es del juego
    - Si loggeas conexiones del executor, creas loop infinito
    - Cobalt se loggearía a sí mismo interceptando sus propios logs

Patrón completo de Cobalt:
    local function CreateConnectionFunction(Instance, Method)
        return function(...)
            for _, conn in getconnections(Instance[Method]) do
                if conn.ForeignState then
                    continue  -- Skip executor
                end
                
                local Function = conn.Function
                local Thread = conn.Thread
                local Origin = nil
                
                -- Obtener script de origen
                if Thread and getscriptfromthread then
                    Origin = getscriptfromthread(Thread)
                end
                
                -- Fallback: buscar en environment
                if not Origin and Function then
                    local Script = rawget(getfenv(Function), "script")
                    if typeof(Script) == "Instance" then
                        Origin = Script
                    end
                end
                
                -- Loggear la llamada
                LogRemote(Instance, Method, Function, {
                    Arguments = table.pack(...),
                    Origin = Origin,
                    IsExecutor = isexecutorclosure(Function),
                })
            end
        end
    end


### LECCIÓN 8: Dual Interception para No Perder Llamadas

Hay DOS formas de llamar un RemoteEvent:
    1. remote:FireServer(args)  -- namecall
    2. RemoteEvent.FireServer(remote, args)  -- función directa

Cobalt intercepta AMBAS para no perder ninguna llamada.

    -- Método 1: Hook de __namecall
    local NamecallHook = hookmetamethod(game, "__namecall", function(...)
        local self = ...
        local method = getnamecallmethod()
        
        if typeof(self) == "Instance" and self:IsA("RemoteEvent") then
            if method == "FireServer" then
                print("Intercepted via namecall:", self.Name)
            end
        end
        
        return NamecallHook(...)
    end)
    
    -- Método 2: Hook de función directa
    local RemoteEvent = Instance.new("RemoteEvent")
    local FireServerFunc = RemoteEvent.FireServer
    RemoteEvent:Destroy()
    
    local old = hookfunction(FireServerFunc, function(...)
        local self = ...
        if typeof(self) == "Instance" and self:IsA("RemoteEvent") then
            print("Intercepted via function:", self.Name)
        end
        return old(...)
    end)

Por qué ambos:
    - Algunos scripts usan remote:FireServer()
    - Otros scripts usan RemoteEvent.FireServer(remote)
    - Sin ambos hooks, pierdes ~50% de las llamadas
    - Cobalt usa ambos para 100% de cobertura


### LECCIÓN 9: xpcall Trick para Obtener Metamétodos

Cuando hookmetamethod no está disponible, puedes obtener el
metamétodo disparándolo intencionalmente con xpcall.

    -- Obtener __namecall sin hookmetamethod:
    local _, namecallFunc = xpcall(
        function()
            game:RandomMethodThatDoesntExist()
        end,
        function()
            return debug.info(2, "f")
        end
    )
    
    -- Obtener __newindex sin hookmetamethod:
    local _, newindexFunc = xpcall(
        function()
            game[tostring(math.random())] = true
        end,
        function()
            return debug.info(2, "f")
        end
    )
    
    -- Obtener __index sin hookmetamethod:
    local _, indexFunc = xpcall(
        function()
            local _ = game[tostring(math.random())]
        end,
        function()
            return debug.info(2, "f")
        end
    )

Cómo funciona:
    1. xpcall(func, errorHandler) ejecuta func
    2. Si hay error, llama errorHandler
    3. En errorHandler, debug.info(2, "f") retorna la función que causó el error
    4. Al disparar __namecall con método inexistente, causa error
    5. El error handler captura la función __namecall

Este es uno de los patrones más avanzados de Lua/Luau.


### LECCIÓN 10: Limpieza Completa en Unload

SIEMPRE implementar función de unload que restaure TODO.

    local Connections = {}
    local Hooks = {}
    
    function Unload()
        -- 1. Desconectar todas las conexiones
        for _, conn in pairs(Connections) do
            conn:Disconnect()
        end
        Connections = {}
        
        -- 2. Restaurar metamétodos
        local mt = getrawmetatable(game)
        if ExecutorSupport["oth"].IsWorking then
            pcall(oth.unhook, mt.__namecall)
            pcall(oth.unhook, mt.__newindex)
        elseif ExecutorSupport["restorefunction"].IsWorking then
            pcall(restorefunction, mt.__namecall)
            pcall(restorefunction, mt.__newindex)
        else
            -- Fallback: re-hookear con originales
            pcall(hookmetamethod, game, "__namecall", Hooks.__namecall)
            pcall(hookmetamethod, game, "__newindex", Hooks.__newindex)
        end
        
        -- 3. Restaurar funciones hookeadas
        for func, original in pairs(Hooks) do
            if ExecutorSupport["oth"].IsWorking then
                pcall(oth.unhook, func)
            elseif ExecutorSupport["restorefunction"].IsWorking then
                pcall(restorefunction, func)
            else
                pcall(hookfunction, func, original)
            end
        end
        Hooks = {}
        
        -- 4. Notificar Actors
        if ActorCommunicator then
            ActorCommunicator:Fire("Unload")
        end
        
        -- 5. Destruir GUI
        if ScreenGui then
            ScreenGui:Destroy()
        end
        
        -- 6. Marcar como unloaded
        Unloaded = true
    end

Por qué es importante:
    - Memory leaks si no limpias conexiones
    - El juego puede detectar hooks que no se restauran
    - Otros scripts pueden fallar si dejas hooks activos
    - Profesionalismo: siempre limpiar después de ti


────────────────────────────────────────────────────────────────────
## RESUMEN FINAL: LOS 10 MANDAMIENTOS DE COBALT
────────────────────────────────────────────────────────────────────

1. NUNCA asumir que una función existe - SIEMPRE verificar primero
2. SIEMPRE usar cloneref() para servicios de Roblox
3. SIEMPRE usar lookup tables para verificaciones frecuentes
4. SIEMPRE usar setstackhidden() en detours
5. SIEMPRE preferir oth sobre hookfunction si está disponible
6. SIEMPRE hookear Actors además del main thread
7. SIEMPRE verificar ForeignState en getconnections()
8. SIEMPRE usar dual interception (namecall + función directa)
9. SIEMPRE tener fallbacks para cada método de hooking
10. SIEMPRE implementar unload completo que restaure todo

Estos patrones hacen que Cobalt sea la implementación más robusta
y profesional de remote spy disponible públicamente. Estudia el
código fuente completo en: github.com/notpoiu/cobalt

"""
    return "\n\n".join([
        LUA_CORE, LUA_FUNCTIONS, LUA_METATABLES, LUA_COROUTINES,
        LUA_CLOSURES, LUA_PATTERNS, PERFORMANCE_TIPS, DEBUG_TOOLS,
        COMMON_ERRORS, LUAU_SPECIFIC, LUAU_EXECUTOR_APIS,
        DESIGN_PATTERNS, LUAU_EDUCATIONAL_SCRIPTS, COBALT_ANALYSIS, COBALT_CORE_KB,
        COBALT_SOURCE_0, COBALT_SOURCE_1, COBALT_SOURCE_2, COBALT_SOURCE_3,
    ])
