# CHANGELOG — LuaGOD Agent v4

## [4.0.0] — 2026-04-19

### NUEVO: agent/api.py
- Llamadas reales a Groq, OpenRouter y Gemini (antes no existía)
- Fallback automático: Groq → OpenRouter → Gemini
- Retry con backoff exponencial (1s, 2s, 4s) en rate limits
- Caché de respuestas en `.api_cache.json` para prompts repetidos
- Timeout adaptativo: 60s para DeepSeek R1, 45s para el resto
- Modelos actualizados: Llama 3.3 70B, Qwen 2.5 Coder 32B, DeepSeek R1
- dotenv opcional (carga .env manualmente si no está instalado)

### NUEVO: knowledge/luau_kb.py (940+ líneas)
- LUA_CORE: tipos, operadores, scope, coerción, control de flujo
- LUA_FUNCTIONS: string, math, table, io/os, globales completas
- LUA_METATABLES: todos los metamétodos + OOP completo (clase, herencia, proxy, mixin)
- LUA_COROUTINES: API completa + producer-consumer + iteradores + async simulado
- LUA_CLOSURES: fábricas, memoización, currying, map/filter/reduce
- LUA_PATTERNS: sistema de patrones Lua completo (no regex)
- PERFORMANCE_TIPS: 10 técnicas de optimización + profiling Luau
- DEBUG_TOOLS: debug library completa + patrones de error
- COMMON_ERRORS: 20 errores frecuentes con causa y fix
- LUAU_SPECIFIC: tipos Luau, servicios Roblox, CFrame, Vector3, raycasting, DataStore, task.*
- LUAU_EXECUTOR_APIS: APIs de Delta/Fluxus/Arceus (educativo)
- DESIGN_PATTERNS: Singleton, Observer, StateMachine, deepcopy, serialización, Promise, Pool, Logger
- get_context(intent, target): retorna conocimiento relevante por modo
- get_all(): retorna todo el conocimiento para modelos pequeños

### NUEVO: lua_runner/runner.py
- Clase LuaRunner con timeout configurable y modo sandbox
- run(code, args): ejecuta Lua, retorna {output, error, exit_code, time_ms, timedout}
- validate_syntax(code): usa luac -p para validar sin ejecutar
- lua_available(): detecta si Lua está instalado
- hint_from_error(error): sugiere fix basado en el mensaje de error
- Detección automática de binario: lua, lua5.4, lua5.3

### REESCRITO: agents/core.py
- detect_intent(): detecta debug/teach/review/fix/executor/combat/oop/data/loop/coroutine
- detect_lua_target(): detecta versión de Lua mencionada en el prompt
- build_system_prompt(): inyecta conocimiento relevante de luau_kb en el system prompt
- Modos debug/teach/review usan 1 llamada directa (no 3 versiones)
- Modos de generación usan 3 versiones con variaciones de estilo

### REESCRITO: agents/coder.py
- Usa IA real (call_ai) en lugar de templates hardcodeados
- 3 variaciones: simple, robusta, avanzada
- _extract_code(): extrae bloque ```lua``` de la respuesta

### MEJORADO: memory/memory.py
- Campo lua_target en cada entrada
- Campo intent en cada entrada
- Campo hash para deduplicación automática
- toggle_favorite(index): marcar/desmarcar favoritos
- get_favorites(): listar favoritos
- save_named(name, code): guardar con nombre personalizado
- get_by_name(name): cargar por nombre
- export_lua(path): exportar snippets con score >= 7 a archivo .lua

### REESCRITO: main.py
- Comandos nuevos: /ejecutar, /guardar, /cargar, /lista, /fav, /favoritos,
  /buscar, /aprender, /version, /exportar, /memoria, /limpiar, /ayuda
- UI con colores ANSI completos (compatible Termux)
- Banner ASCII al inicio
- Barra de progreso visual con █░
- check_deps(): avisa si falta requests
- check_apis(): avisa si no hay keys configuradas
- Prompt muestra target actual: 🔥 LuaGOD [luau] ›

### MEJORADO: .env.example
- Documentación de cada key con URL de registro
- Todos los parámetros de configuración documentados
