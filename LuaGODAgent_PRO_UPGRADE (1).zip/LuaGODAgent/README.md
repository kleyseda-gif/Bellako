# 🔥 LuaGODAgent

Agente de Lua/Luau para terminal, pensado para Termux y flujos de práctica.

## Qué hace

- Genera código Lua/Luau
- Revisa y mejora snippets
- Lee archivos grandes desde rutas comunes de Android/Termux
- Guarda memoria local de prompts y resultados
- Exporta snippets útiles a un archivo `.lua`
- Ejecuta y valida código localmente

## Estructura

```text
LuaGODAgent/
├── main.py              ← Punto de entrada
├── agents/
│   ├── core.py          ← Orquestador
│   ├── coder.py         ← Genera 3 versiones Lua
│   ├── reviewer.py      ← Puntúa calidad
│   └── judge.py         ← Elige la mejor
├── memory/
│   └── memory.py        ← Guarda historial
└── memory.jsonl         ← Historial (se crea solo)
```

## Setup en Termux

```bash
bash setup.sh
python main.py
```

## Comandos útiles

```text
/leer archivo.lua
/guardar nombre
/cargar nombre
/lista
/ejecutar
/validar
/memoria
/estado
/ayuda
```

## Ideas de prompts

```text
haz una función que calcule daño crítico
crea una lista de inventario
haz un loop que imprima números impares
crea una clase Player con herencia
```

## Notas

Este proyecto está orientado a aprendizaje y automatización de Lua/Luau. Si quieres extenderlo, lo más útil suele ser añadir nuevas reglas de análisis, más memoria y plantillas de proyecto.
