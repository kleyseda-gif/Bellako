"""
agents/coder.py — Genera 3 versiones de código Lua usando IA real.
"""
from __future__ import annotations

from agent.api import call_ai

VARIATION_PROMPTS = [
    "Genera una solución SIMPLE y directa. Mínimo código, máxima claridad.",
    "Genera una solución ROBUSTA con manejo de errores, validaciones y comentarios.",
    "Genera una solución AVANZADA usando OOP, patrones de diseño o técnicas avanzadas de Lua.",
]


def generate_versions(prompt: str, system: str, lua_target: str = "luau") -> list:
    versions = []
    for i, variation in enumerate(VARIATION_PROMPTS):
        user_msg = (
            f"{variation}\n\n"
            f"Tarea: {prompt}\n\n"
            f"Target: {lua_target}\n\n"
            "Responde SOLO con el código Lua, sin explicaciones extra."
        )
        code = call_ai(system, user_msg, prefer_coder=True)
        code = _extract_code(code)
        versions.append({"ia": f"IA-{i+1}", "code": code, "intent": "generate", "target": lua_target})
    return versions


def _extract_code(text: str) -> str:
    txt = (text or "").strip()
    if "```lua" in txt:
        start = txt.find("```lua") + 6
        end = txt.find("```", start)
        return txt[start:end].strip() if end != -1 else txt[start:].strip()
    if "```" in txt:
        start = txt.find("```") + 3
        end = txt.find("```", start)
        return txt[start:end].strip() if end != -1 else txt[start:].strip()
    return txt
