"""
agent/api.py — Llamadas reales a APIs de IA con fallback automático.
Soporta: Groq → OpenRouter → Gemini
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

import requests

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
except Exception:
    pass

GROQ_KEY = os.getenv("GROQ_API_KEY", "")
OR_KEY = os.getenv("OPENROUTER_API_KEY", "")
GEMINI_KEY = os.getenv("GEMINI_API_KEY", "")
TIMEOUT = int(os.getenv("API_TIMEOUT", "45"))

GROQ_MODELS = [
    "llama-3.3-70b-versatile",
    "llama-3.1-8b-instant",
    "mixtral-8x7b-32768",
]

OR_MODELS_GENERAL = [
    "qwen/qwen-2.5-coder-32b-instruct:free",
    "deepseek/deepseek-chat-v3-0324:free",
    "meta-llama/llama-3.3-70b-instruct:free",
    "google/gemma-3-27b-it:free",
    "microsoft/phi-4:free",
]

OR_MODELS_CHAT = [
    "meta-llama/llama-3.3-70b-instruct:free",
    "google/gemma-3-27b-it:free",
    "microsoft/phi-4:free",
    "qwen/qwen-2.5-coder-32b-instruct:free",
    "deepseek/deepseek-chat-v3-0324:free",
]

CACHE_FILE = Path(__file__).resolve().parent.parent / ".api_cache.json"


def _load_cache() -> dict:
    if CACHE_FILE.exists():
        try:
            return json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _save_cache(cache: dict) -> None:
    try:
        CACHE_FILE.write_text(json.dumps(cache, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def _cache_key(system: str, user: str, prefer_coder: bool) -> str:
    raw = f"{prefer_coder}|{system[:300]}|{user[:1200]}"
    return hashlib.md5(raw.encode("utf-8", errors="ignore")) .hexdigest()


def _extract_text(payload: dict) -> str | None:
    try:
        return payload["choices"][0]["message"]["content"]
    except Exception:
        return None


def _strip_code_fences(text: str) -> str:
    txt = (text or "").strip()
    if "```" not in txt:
        return txt
    if "```lua" in txt:
        start = txt.find("```lua") + 6
        end = txt.find("```", start)
        return txt[start:end].strip() if end != -1 else txt[start:].strip()
    start = txt.find("```") + 3
    end = txt.find("```", start)
    return txt[start:end].strip() if end != -1 else txt[start:].strip()


def _request_json(url: str, headers: dict, body: dict, timeout: int) -> dict | None:
    for attempt in range(3):
        try:
            resp = requests.post(url, headers=headers, json=body, timeout=timeout)
            if resp.status_code == 429:
                time.sleep(2 ** attempt)
                continue
            if resp.ok:
                return resp.json()
        except requests.RequestException:
            time.sleep(2 ** attempt)
    return None


def _call_groq(system: str, user: str, model: str) -> str | None:
    if not GROQ_KEY:
        return None
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": 0.3,
        "max_tokens": 2048,
    }
    headers = {"Authorization": f"Bearer {GROQ_KEY}", "Content-Type": "application/json"}
    payload = _request_json("https://api.groq.com/openai/v1/chat/completions", headers, body, TIMEOUT)
    return _extract_text(payload) if payload else None


def _call_openrouter(system: str, user: str, model: str) -> str | None:
    if not OR_KEY:
        return None
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": 0.3,
        "max_tokens": 2048,
    }
    headers = {
        "Authorization": f"Bearer {OR_KEY}",
        "Content-Type": "application/json",
        "X-Title": "LuaGODAgent",
    }
    timeout = 60 if "deepseek" in model else TIMEOUT
    payload = _request_json("https://openrouter.ai/api/v1/chat/completions", headers, body, timeout)
    return _extract_text(payload) if payload else None


def _call_gemini(system: str, user: str) -> str | None:
    if not GEMINI_KEY:
        return None
    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"gemini-1.5-flash:generateContent?key={GEMINI_KEY}"
    )
    body = {
        "contents": [{"parts": [{"text": system + "\n\n" + user}]}],
        "generationConfig": {"temperature": 0.3, "maxOutputTokens": 2048},
    }
    for attempt in range(3):
        try:
            resp = requests.post(url, json=body, timeout=TIMEOUT)
            if resp.status_code == 429:
                time.sleep(2 ** attempt)
                continue
            if resp.ok:
                data = resp.json()
                return data["candidates"][0]["content"]["parts"][0]["text"]
        except requests.RequestException:
            time.sleep(2 ** attempt)
    return None


def _no_keys_message() -> str:
    return (
        "-- Error: no hay API key configurada. Revisa tu .env\n"
        "print('Configura GROQ_API_KEY, OPENROUTER_API_KEY o GEMINI_API_KEY')"
    )


def call_ai(system: str, user: str, prefer_coder: bool = False) -> str:
    """Llama a la IA con fallback automático y caché local."""
    key = _cache_key(system, user, prefer_coder)
    cache = _load_cache()
    if key in cache:
        return cache[key]

    result = None

    if GROQ_KEY:
        for model in GROQ_MODELS:
            result = _call_groq(system, user, model)
            if result:
                break

    if not result and OR_KEY:
        models = OR_MODELS_GENERAL if prefer_coder else OR_MODELS_CHAT
        for model in models:
            result = _call_openrouter(system, user, model)
            if result:
                break

    if not result and GEMINI_KEY:
        result = _call_gemini(system, user)

    if not result:
        result = _no_keys_message()

    result = _strip_code_fences(result)
    cache[key] = result
    _save_cache(cache)
    return result
