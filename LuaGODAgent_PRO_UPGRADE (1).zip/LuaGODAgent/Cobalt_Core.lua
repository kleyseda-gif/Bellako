--[[
    Cobalt Core - Analizable por Kiro
    Runtime: Roblox Network Monitor
]]
local function Initialize(wax, script, require)
    wax.shared.CobaltStartTime = tick()
    for _, Service in pairs({"ContentProvider", "CoreGui", "HttpService", "Players"}) do
        wax.shared[Service] = cloneref(game:GetService(Service))
    end
    print("Cobalt Cargado en LuaGODAgent")
end
