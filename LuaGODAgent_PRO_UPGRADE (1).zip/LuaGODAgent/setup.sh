#!/bin/bash
# setup.sh — instala todo lo necesario en Termux

echo "═══════════════════════════════════"
echo "   🔧 LuaGODAgent Setup (Termux)"
echo "═══════════════════════════════════"

echo ""
echo "📦 [1/3] Actualizando paquetes..."
pkg update -y && pkg upgrade -y

echo ""
echo "📦 [2/3] Instalando dependencias del sistema..."
pkg install -y python lua

echo ""
echo "📦 [3/3] Instalando librerías Python..."
pip install requests

echo ""
echo "═══════════════════════════════════"
echo "✅ Setup completo. Para ejecutar:"
echo "   python main.py"
echo "═══════════════════════════════════"
