"""
agents/core.py — Orquestador principal del agente LuaGOD.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass

from agent.api import call_ai
from agents.coder import generate_versions
from agents.judge import choose_best
from agents.reviewer import review
from knowledge.luau_kb import get_context
from memory.memory import save

LUA_TARGET = os.getenv("LUA_TARGET", "luau")

BASE_PERSONA = """Eres LuaGOD, un asistente experto en Lua y Luau.
Dominas Lua 5.1, 5.2, 5.3, 5.4, LuaJIT y Luau.
Respondes SIEMPRE en español.
No inventas funciones inexistentes: si algo depende de un entorno, lo indicas.
Cuando generas código, priorizas claridad, compatibilidad, robustez y ejemplos útiles.
"""

MODE_INSTRUCTIONS = {
    "generate": "Genera código Lua limpio, funcional y comentado que resuelva exactamente lo pedido. Incluye validaciones y manejo de errores cuando aplique.",
    "fix": "Analiza el error o código con problemas. Explica la causa raíz y proporciona el código corregido listo para usar.",
    "improve": "Mejora el código dado: optimiza rendimiento, legibilidad y robustez. Explica los cambios clave.",
    "debug": "Analiza el stack trace o error. Identifica la causa exacta y da el fix.",
    "teach": "Explica el concepto con ejemplos progresivos (básico → intermedio → avanzado). Usa el formato: concepto → ejemplo → práctica.",
    "review": "Revisa el código como un senior. Detecta bugs, anti-patrones, problemas de rendimiento y sugiere mejoras concretas.",
    "executor": "Genera código para un entorno Luau/executor solo cuando el usuario lo pida explícitamente y con advertencias claras sobre el entorno.",
    "combat": "Genera sistemas de combate Lua/Luau con estructuras limpias, balance y manejo de estados.",
    "oop": "Genera código OOP en Lua usando metatables, con herencia y encapsulación correctas.",
    "coroutine": "Explica o genera código con coroutines Lua. Incluye ejemplos útiles y reales.",
    "chat": "Si el usuario saluda o hace preguntas generales, responde de forma amigable y natural en español.",
}

_DEBUG_PATTERNS = [
    r"attempt to \w+",
    r"stack traceback",
    r"\.lua:\d+:",
    r"stdin:\d+",
    r"error:",
    r"nil value",
    r"expected.*got",
]

CONVERSATIONAL_PATTERNS = [
    r"^(hola|hello|hey|buenas|qué tal|que tal|cómo estás|como estas)[\s!?]*$",
    r"^(gracias|thanks|perfecto|genial|bien|ok|okay|listo|entendido)[\s!?]*$",
    r"^(quién eres|quien eres|qué eres|que eres|qué puedes|que puedes hacer)[\s?]*$",
    r"^(ayuda|help|auxilio)[\s!?]*$",
]

_EXECUTOR_KEYWORDS = {
    "delta", "fluxus", "arceus", "codex", "synapse", "krnl", "hydrogen",
    "executor", "exploit", "getgenv", "getrenv", "hookfunction", "hookmetamethod",
    "getrawmetatable", "newcclosure", "cloneref", "getnilinstances",
    "getconnections", "firesignal", "checkcaller", "getcallingscript",
    "run_on_actor", "oth", "setstackhidden", "getfunctionhash",
    "remote spy", "remotespy", "namecall", "fireserver", "invokeserver",
}

_VERSION_MAP = {
    "lua51": "5.1", "lua 5.1": "5.1",
    "lua52": "5.2", "lua 5.2": "5.2",
    "lua53": "5.3", "lua 5.3": "5.3",
    "lua54": "5.4", "lua 5.4": "5.4",
    "luajit": "LuaJIT",
    "luau": "Luau", "roblox": "Luau",
}


def detect_intent(prompt: str) -> str:
    p = prompt.lower()
    for pat in CONVERSATIONAL_PATTERNS:
        if re.match(pat, p):
            return "chat"
    for pat in _DEBUG_PATTERNS:
        if re.search(pat, p):
            return "debug"
    if re.search(r"\b(cómo|como|qué es|que es|explica|enseña|tutorial|diferencia entre|para qué|para que)\b", p):
        return "teach"
    if re.search(r"\b(revisa|review|analiza|qué falla|que falla|está bien|esta bien|feedback)\b", p):
        return "review"
    if re.search(r"\b(arregla|fix|corrige|no funciona|falla|bug|error en|problema con)\b", p):
        return "fix"
    if any(kw in p for kw in _EXECUTOR_KEYWORDS):
        return "executor"
    if re.search(r"\b(coroutine|corutina|yield|async|await|producer|consumer)\b", p):
        return "coroutine"
    if re.search(r"\b(clase|class|objeto|oop|herencia|metatable|__index|setmetatable)\b", p):
        return "oop"
    if re.search(r"\b(daño|damage|crítico|critico|ataque|attack|combate|combat|arma|weapon|hp|health)\b", p):
        return "combat"
    if re.search(r"\b(lista|array|tabla|inventario|inventory|diccionario|queue|stack|heap)\b", p):
        return "generate"
    if re.search(r"\b(loop|bucle|ciclo|for|while|repeat|iterar|iterate)\b", p):
        return "generate"
    if re.search(r"\b(input|usuario|user|leer|read|menú|menu|prompt)\b", p):
        return "generate"
    return "generate"


def detect_lua_target(prompt: str) -> str:
    p = prompt.lower()
    for kw, ver in _VERSION_MAP.items():
        if kw in p:
            return ver.lower() if ver in ("5.1", "5.2", "5.3", "5.4") else kw
    for kw in _EXECUTOR_KEYWORDS:
        if kw in p:
            for name in ("delta", "fluxus", "arceus", "synapse", "krnl"):
                if name in p:
                    return name
            return "delta"
    return LUA_TARGET


def build_system_prompt(intent: str, lua_target: str, prompt: str) -> str:
    mode_instr = MODE_INSTRUCTIONS.get(intent, MODE_INSTRUCTIONS["generate"])
    kb_context = get_context(intent, lua_target)
    kb_trimmed = kb_context[:6000]
    if len(prompt) > 1800:
        prompt_note = "El usuario envió mucho texto; responde con precisión y evita repetir el input completo."
    else:
        prompt_note = ""
    return f"""{BASE_PERSONA}

Target: {lua_target.upper()}
Modo actual: {intent.upper()}
{mode_instr}
{prompt_note}

=== CONOCIMIENTO DE REFERENCIA ===
{kb_trimmed}
=== FIN DEL CONOCIMIENTO ===

Formato de respuesta para código:
1. Breve explicación (1-2 líneas)
2. Código en bloque ```lua ... ```
3. Notas importantes (si aplica)
"""


def run_agent(prompt: str) -> dict:
    intent = detect_intent(prompt)
    lua_target = detect_lua_target(prompt)
    system = build_system_prompt(intent, lua_target, prompt)

    print(f"  [modo: {intent} | target: {lua_target}]")

    if intent in ("debug", "teach", "review", "chat"):
        print("  [1/1] Consultando IA...")
        response = call_ai(system, prompt, prefer_coder=False)
        result = {"code": response, "score": 9, "ia": "IA-1", "intent": intent, "target": lua_target}
        save(prompt, response, 9, intent, lua_target)
        return result

    print("  [1/3] Generando 3 versiones con IA...")
    versions = generate_versions(prompt, system, lua_target)
    print("  [2/3] Revisando calidad...")
    reviewed = [review(v, prompt) for v in versions]
    print("  [3/3] Eligiendo mejor versión...")
    best = choose_best(reviewed)
    print("  [4/4] Guardando en memoria...")
    save(prompt, best["code"], best["score"], intent, lua_target)
    return best
